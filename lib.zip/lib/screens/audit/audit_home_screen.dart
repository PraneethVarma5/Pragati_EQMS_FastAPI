// // // import 'package:flutter/material.dart';
// // //
// // // import '../../models/audit/audit.dart';
// // // import '../../services/audit/audit_service.dart';
// // // import 'audit_details_screen.dart';
// // //
// // // class AuditHomeScreen extends StatefulWidget {
// // //   const AuditHomeScreen({super.key});
// // //
// // //   @override
// // //   State<AuditHomeScreen> createState() =>
// // //       _AuditHomeScreenState();
// // // }
// // //
// // // class _AuditHomeScreenState
// // //     extends State<AuditHomeScreen> {
// // //   bool loading = true;
// // //   List<Map<String, dynamic>> audits = [];
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //     _loadAudits();
// // //   }
// // //
// // //   Future<void> _loadAudits() async {
// // //     try {
// // //       audits =
// // //       await AuditService.getAuditPlan();
// // //     } finally {
// // //       if (mounted) {
// // //         setState(() {
// // //           loading = false;
// // //         });
// // //       }
// // //     }
// // //   }
// // //
// // //   Future<void> _startNewAudit() async {
// // //     await Navigator.push(
// // //       context,
// // //       MaterialPageRoute(
// // //         builder: (_) => const AuditDetailsScreen(),
// // //       ),
// // //     );
// // //
// // //     _loadAudits();
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Scaffold(
// // //       backgroundColor:
// // //       const Color(0xFFF5F7FB),
// // //       appBar: AppBar(
// // //         title: const Text(
// // //           'Audit Management',
// // //           style: TextStyle(
// // //             fontWeight: FontWeight.w800,
// // //           ),
// // //         ),
// // //         backgroundColor: Colors.white,
// // //         foregroundColor:
// // //         const Color(0xFF172033),
// // //         elevation: 0,
// // //       ),
// // //       body: Padding(
// // //         padding: const EdgeInsets.all(28),
// // //         child: Column(
// // //           crossAxisAlignment:
// // //           CrossAxisAlignment.start,
// // //           children: [
// // //             Row(
// // //               children: [
// // //                 const Expanded(
// // //                   child: Column(
// // //                     crossAxisAlignment:
// // //                     CrossAxisAlignment.start,
// // //                     children: [
// // //                       Text(
// // //                         'Audit Plan',
// // //                         style: TextStyle(
// // //                           fontSize: 28,
// // //                           fontWeight:
// // //                           FontWeight.w800,
// // //                         ),
// // //                       ),
// // //                       SizedBox(height: 5),
// // //                       Text(
// // //                         'Plan, perform and track audits',
// // //                         style: TextStyle(
// // //                           color:
// // //                           Color(0xFF6B7280),
// // //                         ),
// // //                       ),
// // //                     ],
// // //                   ),
// // //                 ),
// // //                 ElevatedButton.icon(
// // //                   onPressed: _startNewAudit,
// // //                   icon:
// // //                   const Icon(Icons.add),
// // //                   label: const Text(
// // //                     'Start New Audit',
// // //                   ),
// // //                   style:
// // //                   ElevatedButton.styleFrom(
// // //                     padding:
// // //                     const EdgeInsets.symmetric(
// // //                       horizontal: 20,
// // //                       vertical: 16,
// // //                     ),
// // //                   ),
// // //                 ),
// // //               ],
// // //             ),
// // //             const SizedBox(height: 25),
// // //             Expanded(
// // //               child: loading
// // //                   ? const Center(
// // //                 child:
// // //                 CircularProgressIndicator(),
// // //               )
// // //                   : _buildPlan(),
// // //             ),
// // //           ],
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _buildPlan() {
// // //     if (audits.isEmpty) {
// // //       return const Center(
// // //         child: Text(
// // //           'No audits found.',
// // //           style: TextStyle(
// // //             color: Colors.grey,
// // //           ),
// // //         ),
// // //       );
// // //     }
// // //
// // //     return Card(
// // //       elevation: 0,
// // //       shape: RoundedRectangleBorder(
// // //         borderRadius:
// // //         BorderRadius.circular(18),
// // //         side: const BorderSide(
// // //           color: Color(0xFFE4E8F0),
// // //         ),
// // //       ),
// // //       child: SingleChildScrollView(
// // //         scrollDirection: Axis.horizontal,
// // //         child: DataTable(
// // //           columns: const [
// // //             DataColumn(label: Text('MIL')),
// // //             DataColumn(label: Text('Audit Type')),
// // //             DataColumn(label: Text('Date')),
// // //             DataColumn(label: Text('Vendor')),
// // //             DataColumn(label: Text('Site')),
// // //             DataColumn(label: Text('Auditor')),
// // //             DataColumn(label: Text('Status')),
// // //             DataColumn(label: Text('Action')),
// // //           ],
// // //           rows: audits.map((map) {
// // //             final audit =
// // //             Audit.fromMap(map);
// // //
// // //             return DataRow(
// // //               cells: [
// // //                 DataCell(
// // //                   Text(
// // //                     audit.milNumber ?? '-',
// // //                   ),
// // //                 ),
// // //                 DataCell(
// // //                   Text(audit.auditType),
// // //                 ),
// // //                 DataCell(
// // //                   Text(
// // //                     '${audit.auditDate.day.toString().padLeft(2, '0')}/'
// // //                         '${audit.auditDate.month.toString().padLeft(2, '0')}/'
// // //                         '${audit.auditDate.year}',
// // //                   ),
// // //                 ),
// // //                 DataCell(
// // //                   Text(audit.vendor),
// // //                 ),
// // //                 DataCell(
// // //                   Text(audit.site),
// // //                 ),
// // //                 DataCell(
// // //                   Text(audit.auditorName),
// // //                 ),
// // //                 DataCell(
// // //                   _statusChip(audit.status),
// // //                 ),
// // //                 DataCell(
// // //                   TextButton(
// // //                     onPressed: () {
// // //                       // Resume screen will be connected
// // //                       // to the audit ID.
// // //                     },
// // //                     child: Text(
// // //                       audit.status ==
// // //                           'Completed'
// // //                           ? 'View'
// // //                           : 'Continue',
// // //                     ),
// // //                   ),
// // //                 ),
// // //               ],
// // //             );
// // //           }).toList(),
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _statusChip(String status) {
// // //     final completed =
// // //         status == 'Completed';
// // //
// // //     return Container(
// // //       padding:
// // //       const EdgeInsets.symmetric(
// // //         horizontal: 10,
// // //         vertical: 5,
// // //       ),
// // //       decoration: BoxDecoration(
// // //         color: completed
// // //             ? Colors.green.shade50
// // //             : Colors.orange.shade50,
// // //         borderRadius:
// // //         BorderRadius.circular(20),
// // //       ),
// // //       child: Text(
// // //         status,
// // //         style: TextStyle(
// // //           fontWeight: FontWeight.w700,
// // //           color: completed
// // //               ? Colors.green.shade700
// // //               : Colors.orange.shade700,
// // //         ),
// // //       ),
// // //     );
// // //   }
// // // }
// // import 'package:flutter/material.dart';
// //
// // import '../../models/audit/audit.dart';
// // import '../../services/audit/audit_service.dart';
// // import 'audit_checklist_screen.dart';
// // import 'audit_details_screen.dart';
// // import 'audit_process_selection_screen.dart';
// // import 'audit_summary_screen.dart';
// //
// // class AuditHomeScreen extends StatefulWidget {
// //   const AuditHomeScreen({
// //     super.key,
// //   });
// //
// //   @override
// //   State<AuditHomeScreen> createState() =>
// //       _AuditHomeScreenState();
// // }
// //
// // class _AuditHomeScreenState
// //     extends State<AuditHomeScreen> {
// //   bool loading = true;
// //   List<Map<String, dynamic>> audits = [];
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _loadAudits();
// //   }
// //
// //   Future<void> _loadAudits() async {
// //     try {
// //       final result =
// //       await AuditService.getAuditPlan();
// //
// //       if (!mounted) return;
// //
// //       setState(() {
// //         audits = result;
// //         loading = false;
// //       });
// //     } catch (e) {
// //       if (!mounted) return;
// //
// //       setState(() {
// //         loading = false;
// //       });
// //
// //       _showError(
// //         'Unable to load Audit Plan.\n$e',
// //       );
// //     }
// //   }
// //
// //   Future<void> _startNewAudit() async {
// //     await Navigator.push(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) =>
// //         const AuditDetailsScreen(),
// //       ),
// //     );
// //
// //     if (!mounted) return;
// //
// //     setState(() {
// //       loading = true;
// //     });
// //
// //     await _loadAudits();
// //   }
// //
// //   Future<void> _continueAudit(
// //       Audit audit) async {
// //     if (audit.status == 'Completed') {
// //       await _viewCompletedAudit(audit);
// //       return;
// //     }
// //
// //     await Navigator.push(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) =>
// //             AuditProcessSelectionScreen(
// //               audit: audit,
// //             ),
// //       ),
// //     );
// //
// //     if (!mounted) return;
// //
// //     setState(() {
// //       loading = true;
// //     });
// //
// //     await _loadAudits();
// //   }
// //   // Future<List<String>>
// //   // _loadSelectedProcessSections(
// //   //     Audit audit,
// //   //     ) async {
// //   //   final answers =
// //   //   await AuditService.getAnswers(
// //   //     audit.auditId,
// //   //   );
// //   //
// //   //   final sections = <String>{};
// //   //
// //   //   for (final answer in answers) {
// //   //     final section =
// //   //     answer['section']?.toString();
// //   //
// //   //     if (section != null &&
// //   //         section.trim().isNotEmpty) {
// //   //       sections.add(section);
// //   //     }
// //   //   }
// //   //
// //   //   if (sections.isNotEmpty) {
// //   //     return sections.toList();
// //   //   }
// //   //
// //   //   return [];
// //   // }
// //
// //   Future<void> _viewCompletedAudit(
// //       Audit audit) async {
// //     try {
// //       final findings =
// //       await AuditService.getFindings(
// //         audit.auditId,
// //       );
// //
// //       if (!mounted) return;
// //
// //       Navigator.push(
// //         context,
// //         MaterialPageRoute(
// //           builder: (_) =>
// //               AuditSummaryScreen(
// //                 audit: audit,
// //                 findings: findings,
// //                 milNumber:
// //                 audit.milNumber ?? '-',
// //               ),
// //         ),
// //       );
// //     } catch (e) {
// //       if (!mounted) return;
// //
// //       _showError(
// //         'Unable to open completed audit.\n$e',
// //       );
// //     }
// //   }
// //
// //   void _showError(String message) {
// //     ScaffoldMessenger.of(context)
// //         .showSnackBar(
// //       SnackBar(
// //         content: Text(message),
// //         behavior:
// //         SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// //
// //   String _date(DateTime date) {
// //     return '${date.day.toString().padLeft(2, '0')}/'
// //         '${date.month.toString().padLeft(2, '0')}/'
// //         '${date.year}';
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor:
// //       const Color(0xFFF5F7FB),
// //
// //       appBar: AppBar(
// //         title: const Text(
// //           'Audit Management',
// //           style: TextStyle(
// //             fontWeight: FontWeight.w800,
// //           ),
// //         ),
// //         backgroundColor: Colors.white,
// //         foregroundColor:
// //         const Color(0xFF172033),
// //         elevation: 0,
// //       ),
// //
// //       body: Padding(
// //         padding: const EdgeInsets.all(28),
// //
// //         child: Column(
// //           crossAxisAlignment:
// //           CrossAxisAlignment.start,
// //
// //           children: [
// //             Row(
// //               crossAxisAlignment:
// //               CrossAxisAlignment.start,
// //
// //               children: [
// //                 const Expanded(
// //                   child: Column(
// //                     crossAxisAlignment:
// //                     CrossAxisAlignment.start,
// //
// //                     children: [
// //                       Text(
// //                         'Audit Plan',
// //                         style: TextStyle(
// //                           fontSize: 30,
// //                           fontWeight:
// //                           FontWeight.w800,
// //                         ),
// //                       ),
// //
// //                       SizedBox(height: 6),
// //
// //                       Text(
// //                         'Plan, perform and track audits',
// //                         style: TextStyle(
// //                           color:
// //                           Color(0xFF6B7280),
// //                           fontSize: 15,
// //                         ),
// //                       ),
// //                     ],
// //                   ),
// //                 ),
// //
// //                 ElevatedButton.icon(
// //                   onPressed:
// //                   _startNewAudit,
// //
// //                   icon: const Icon(
// //                     Icons.add,
// //                   ),
// //
// //                   label: const Text(
// //                     'Start New Audit',
// //                   ),
// //
// //                   style:
// //                   ElevatedButton.styleFrom(
// //                     padding:
// //                     const EdgeInsets.symmetric(
// //                       horizontal: 22,
// //                       vertical: 16,
// //                     ),
// //                     shape:
// //                     RoundedRectangleBorder(
// //                       borderRadius:
// //                       BorderRadius.circular(
// //                         12,
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             const SizedBox(height: 25),
// //
// //             Expanded(
// //               child: loading
// //                   ? const Center(
// //                 child:
// //                 CircularProgressIndicator(),
// //               )
// //                   : _buildPlan(),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _buildPlan() {
// //     if (audits.isEmpty) {
// //       return Card(
// //         elevation: 0,
// //         shape:
// //         RoundedRectangleBorder(
// //           borderRadius:
// //           BorderRadius.circular(18),
// //           side: const BorderSide(
// //             color: Color(0xFFE4E8F0),
// //           ),
// //         ),
// //         child: const Center(
// //           child: Column(
// //             mainAxisAlignment:
// //             MainAxisAlignment.center,
// //             children: [
// //               Icon(
// //                 Icons.fact_check_outlined,
// //                 size: 58,
// //                 color: Color(0xFF9CA3AF),
// //               ),
// //               SizedBox(height: 14),
// //               Text(
// //                 'No audits found',
// //                 style: TextStyle(
// //                   fontSize: 20,
// //                   fontWeight:
// //                   FontWeight.w700,
// //                 ),
// //               ),
// //               SizedBox(height: 5),
// //               Text(
// //                 'Start a new audit to create an audit plan.',
// //                 style: TextStyle(
// //                   color:
// //                   Color(0xFF6B7280),
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }
// //
// //     return Card(
// //       elevation: 0,
// //
// //       shape:
// //       RoundedRectangleBorder(
// //         borderRadius:
// //         BorderRadius.circular(18),
// //         side: const BorderSide(
// //           color: Color(0xFFE4E8F0),
// //         ),
// //       ),
// //
// //       child: ClipRRect(
// //         borderRadius:
// //         BorderRadius.circular(18),
// //
// //         child: SingleChildScrollView(
// //           scrollDirection:
// //           Axis.horizontal,
// //
// //           child: DataTable(
// //             headingRowHeight: 52,
// //             dataRowMinHeight: 62,
// //             dataRowMaxHeight: 72,
// //
// //             columns: const [
// //               DataColumn(
// //                 label: Text('MIL'),
// //               ),
// //               DataColumn(
// //                 label:
// //                 Text('Audit Type'),
// //               ),
// //               DataColumn(
// //                 label: Text('Date'),
// //               ),
// //               DataColumn(
// //                 label:
// //                 Text('Vendor'),
// //               ),
// //               DataColumn(
// //                 label: Text('Site'),
// //               ),
// //               DataColumn(
// //                 label:
// //                 Text('Auditor'),
// //               ),
// //               DataColumn(
// //                 label:
// //                 Text('Status'),
// //               ),
// //               DataColumn(
// //                 label:
// //                 Text('Action'),
// //               ),
// //             ],
// //
// //             rows: audits.map(
// //                   (map) {
// //                 final audit =
// //                 Audit.fromMap(map);
// //
// //                 final completed =
// //                     audit.status ==
// //                         'Completed';
// //
// //                 return DataRow(
// //                   cells: [
// //                     DataCell(
// //                       Text(
// //                         audit.milNumber ??
// //                             '-',
// //                         style:
// //                         const TextStyle(
// //                           fontWeight:
// //                           FontWeight.w600,
// //                         ),
// //                       ),
// //                     ),
// //
// //                     DataCell(
// //                       Text(
// //                         audit.auditType,
// //                       ),
// //                     ),
// //
// //                     DataCell(
// //                       Text(
// //                         _date(
// //                           audit.auditDate,
// //                         ),
// //                       ),
// //                     ),
// //
// //                     DataCell(
// //                       Text(audit.vendor),
// //                     ),
// //
// //                     DataCell(
// //                       Text(audit.site),
// //                     ),
// //
// //                     DataCell(
// //                       Text(
// //                         audit.auditorName,
// //                       ),
// //                     ),
// //
// //                     DataCell(
// //                       _statusChip(
// //                         audit.status,
// //                       ),
// //                     ),
// //
// //                     DataCell(
// //                       TextButton.icon(
// //                         onPressed: () =>
// //                             _continueAudit(
// //                               audit,
// //                             ),
// //                         icon: Icon(
// //                           completed
// //                               ? Icons.visibility_outlined
// //                               : Icons.play_arrow,
// //                           size: 18,
// //                         ),
// //                         label: Text(
// //                           completed
// //                               ? 'View'
// //                               : 'Continue',
// //                         ),
// //                       ),
// //                     ),
// //                   ],
// //                 );
// //               },
// //             ).toList(),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _statusChip(
// //       String status) {
// //     final completed =
// //         status == 'Completed';
// //
// //     return Container(
// //       padding:
// //       const EdgeInsets.symmetric(
// //         horizontal: 11,
// //         vertical: 6,
// //       ),
// //       decoration: BoxDecoration(
// //         color: completed
// //             ? Colors.green.shade50
// //             : Colors.orange.shade50,
// //         borderRadius:
// //         BorderRadius.circular(20),
// //       ),
// //       child: Text(
// //         completed
// //             ? 'Completed'
// //             : 'In Progress',
// //         style: TextStyle(
// //           fontWeight:
// //           FontWeight.w700,
// //           color: completed
// //               ? Colors.green.shade700
// //               : Colors.orange.shade700,
// //         ),
// //       ),
// //     );
// //   }
// // }
//
// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_service.dart';
// import '../../services/audit/audit_calculation_service.dart';
// import '../../services/audit/audit_pdf_service.dart';
// import 'audit_details_screen.dart';
// import 'audit_process_selection_screen.dart';
// import 'audit_summary_screen.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_calculation_service.dart';
//
// class AuditHomeScreen extends StatefulWidget {
//   const AuditHomeScreen({
//     super.key,
//   });
//
//   @override
//   State<AuditHomeScreen> createState() =>
//       _AuditHomeScreenState();
// }
//
// class _AuditHomeScreenState
//     extends State<AuditHomeScreen> {
//   bool loading = true;
//
//   List<Map<String, dynamic>> audits =
//   [];
//
//   @override
//   void initState() {
//     super.initState();
//     _loadAudits();
//   }
//   Future<void> _downloadAuditSummary() async {
//     try {
//       if (audits.isEmpty) {
//         _showError(
//           'There are no audits to export.',
//         );
//         return;
//       }
//
//       final completedAudits = audits
//           .map(
//             (map) => Audit.fromMap(map),
//       )
//           .where(
//             (audit) =>
//         audit.status == 'Completed',
//       )
//           .toList();
//
//       if (completedAudits.isEmpty) {
//         _showError(
//           'There are no completed audits to export.',
//         );
//         return;
//       }
//
//       final findingsByAudit =
//       <String, List<AuditFinding>>{};
//
//       for (final audit
//       in completedAudits) {
//         findingsByAudit[audit.auditId] =
//         await AuditService.getFindings(
//           audit.auditId,
//         );
//       }
//
//       await AuditPdfService
//           .shareAllAuditSummaries(
//         audits: completedAudits,
//         findingsByAudit:
//         findingsByAudit,
//       );
//     } catch (e) {
//       if (!mounted) {
//         return;
//       }
//
//       _showError(
//         'Unable to generate Audit Summary.\n$e',
//       );
//     }
//   }
//   // Future<void> _loadAudits() async {
//   //   try {
//   //     final result =
//   //     await AuditService.getAuditPlan();
//   //
//   //     final enriched =
//   //     <Map<String, dynamic>>[];
//   //
//   //     for (final map in result) {
//   //       final audit =
//   //       Audit.fromMap(map);
//   //
//   //       final findings =
//   //       await AuditService.getFindings(
//   //         audit.auditId,
//   //       );
//   //
//   //       final score =
//   //       AuditCalculationService.auditScore(
//   //         audit: audit,
//   //         findings: findings,
//   //       );
//   //
//   //       final cph =
//   //       AuditCalculationService.cph(
//   //         audit: audit,
//   //         findings: findings,
//   //       );
//   //
//   //       enriched.add({
//   //         ...map,
//   //
//   //         '_auditScore': score,
//   //
//   //         '_cph': cph,
//   //
//   //         '_critical':
//   //         AuditCalculationService
//   //             .criticalCount(
//   //           findings,
//   //         ),
//   //
//   //         '_major':
//   //         AuditCalculationService
//   //             .majorCount(
//   //           findings,
//   //         ),
//   //
//   //         '_minor':
//   //         AuditCalculationService
//   //             .minorCount(
//   //           findings,
//   //         ),
//   //       });
//   //     }
//   //
//   //     if (!mounted) {
//   //       return;
//   //     }
//   //
//   //     setState(() {
//   //       audits = enriched;
//   //       loading = false;
//   //     });
//   //   } catch (e) {
//   //     if (!mounted) {
//   //       return;
//   //     }
//   //
//   //     setState(() {
//   //       loading = false;
//   //     });
//   //   }
//   // }
//   Future<void> _loadAudits() async {
//     try {
//       final result =
//       await AuditService.getAuditPlan();
//
//       final enriched =
//       <Map<String, dynamic>>[];
//
//       for (final map in result) {
//         final audit =
//         Audit.fromMap(map);
//
//         final findings =
//         await AuditService.getFindings(
//           audit.auditId,
//         );
//
//         final cph =
//         AuditCalculationService.cph(
//           audit: audit,
//           findings: findings,
//         );
//
//         final score =
//         AuditCalculationService.auditScore(
//           audit: audit,
//           findings: findings,
//         );
//
//         enriched.add({
//           ...map,
//
//           '_cph': cph,
//
//           '_auditScore': score,
//
//           '_critical':
//           AuditCalculationService
//               .criticalCount(
//             findings,
//           ),
//
//           '_major':
//           AuditCalculationService
//               .majorCount(
//             findings,
//           ),
//
//           '_minor':
//           AuditCalculationService
//               .minorCount(
//             findings,
//           ),
//         });
//       }
//
//       if (!mounted) {
//         return;
//       }
//
//       setState(() {
//         audits = enriched;
//         loading = false;
//       });
//     } catch (e) {
//       if (!mounted) {
//         return;
//       }
//
//       setState(() {
//         loading = false;
//       });
//
//       _showError(
//         'Unable to load Audit Plan.\n$e',
//       );
//     }
//   }
//
//   Future<void> _startNewAudit() async {
//     await Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) =>
//         const AuditDetailsScreen(),
//       ),
//     );
//
//     if (!mounted) {
//       return;
//     }
//
//     setState(() {
//       loading = true;
//     });
//
//     await _loadAudits();
//   }
//
//   // ============================================================
//   // CONTINUE AUDIT
//   // ============================================================
//
//   Future<void> _continueAudit(
//       Audit audit) async {
//     if (audit.status == 'Completed') {
//       await _viewCompletedAudit(audit);
//       return;
//     }
//
//     await Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) =>
//             AuditProcessSelectionScreen(
//               audit: audit,
//             ),
//       ),
//     );
//
//     if (!mounted) {
//       return;
//     }
//
//     setState(() {
//       loading = true;
//     });
//
//     await _loadAudits();
//   }
//   // ============================================================
//   // VIEW COMPLETED AUDIT
//   // ============================================================
//
//   Future<void> _viewCompletedAudit(
//       Audit audit) async {
//     try {
//       final findings =
//       await AuditService.getFindings(
//         audit.auditId,
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               AuditSummaryScreen(
//                 audit: audit,
//                 findings: findings,
//                 milNumber:
//                 audit.milNumber ?? '-',
//               ),
//         ),
//       );
//     } catch (e) {
//       if (!mounted) {
//         return;
//       }
//
//       _showError(
//         'Unable to open completed audit.\n$e',
//       );
//     }
//   }
//
//   void _showError(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior:
//         SnackBarBehavior.floating,
//       ),
//     );
//   }
//
//   String _date(
//       DateTime date) {
//     return '${date.day.toString().padLeft(2, '0')}/'
//         '${date.month.toString().padLeft(2, '0')}/'
//         '${date.year}';
//   }
//
//   @override
//   Widget build(
//       BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: const Text(
//           'Audit Management',
//           style: TextStyle(
//             fontWeight:
//             FontWeight.w800,
//           ),
//         ),
//
//         backgroundColor:
//         Colors.white,
//
//         foregroundColor:
//         const Color(0xFF172033),
//
//         elevation: 0,
//       ),
//
//       body: Padding(
//         padding:
//         const EdgeInsets.all(28),
//
//         child: Column(
//           crossAxisAlignment:
//           CrossAxisAlignment.start,
//
//           children: [
//             Row(
//               crossAxisAlignment:
//               CrossAxisAlignment.start,
//
//               children: [
//                 const Expanded(
//                   child: Column(
//                     crossAxisAlignment:
//                     CrossAxisAlignment.start,
//
//                     children: [
//                       Text(
//                         'Audit Plan',
//                         style:
//                         TextStyle(
//                           fontSize: 30,
//                           fontWeight:
//                           FontWeight.w800,
//                         ),
//                       ),
//
//                       SizedBox(
//                         height: 6,
//                       ),
//
//                       Text(
//                         'Plan, perform and track audits',
//                         style:
//                         TextStyle(
//                           color:
//                           Color(0xFF6B7280),
//                           fontSize: 15,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//
//                 Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     OutlinedButton.icon(
//                       onPressed:
//                       _downloadAuditSummary,
//                       icon: const Icon(
//                         Icons.picture_as_pdf_outlined,
//                         size: 18,
//                       ),
//                       label: const Text(
//                         'Audit Summary',
//                       ),
//                       style: OutlinedButton.styleFrom(
//                         padding:
//                         const EdgeInsets.symmetric(
//                           horizontal: 18,
//                           vertical: 16,
//                         ),
//                         shape:
//                         RoundedRectangleBorder(
//                           borderRadius:
//                           BorderRadius.circular(12),
//                         ),
//                       ),
//                     ),
//
//                     const SizedBox(width: 10),
//
//                     ElevatedButton.icon(
//                       onPressed:
//                       _startNewAudit,
//                       icon: const Icon(
//                         Icons.add,
//                       ),
//                       label: const Text(
//                         'Start New Audit',
//                       ),
//                       style:
//                       ElevatedButton.styleFrom(
//                         padding:
//                         const EdgeInsets.symmetric(
//                           horizontal: 22,
//                           vertical: 16,
//                         ),
//                         shape:
//                         RoundedRectangleBorder(
//                           borderRadius:
//                           BorderRadius.circular(12),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//
//             const SizedBox(
//               height: 25,
//             ),
//
//             Expanded(
//               child: loading
//                   ? const Center(
//                 child:
//                 CircularProgressIndicator(),
//               )
//                   : _buildPlan(),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildPlan() {
//     if (audits.isEmpty) {
//       return Card(
//         elevation: 0,
//
//         shape:
//         RoundedRectangleBorder(
//           borderRadius:
//           BorderRadius.circular(18),
//
//           side:
//           const BorderSide(
//             color:
//             Color(0xFFE4E8F0),
//           ),
//         ),
//
//         child: const Center(
//           child: Column(
//             mainAxisAlignment:
//             MainAxisAlignment.center,
//
//             children: [
//               Icon(
//                 Icons
//                     .fact_check_outlined,
//                 size: 58,
//                 color:
//                 Color(0xFF9CA3AF),
//               ),
//
//               SizedBox(
//                 height: 14,
//               ),
//
//               Text(
//                 'No audits found',
//                 style:
//                 TextStyle(
//                   fontSize: 20,
//                   fontWeight:
//                   FontWeight.w700,
//                 ),
//               ),
//
//               SizedBox(
//                 height: 5,
//               ),
//
//               Text(
//                 'Start a new audit to create an audit plan.',
//                 style:
//                 TextStyle(
//                   color:
//                   Color(0xFF6B7280),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     }
//
//     return Card(
//       elevation: 0,
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(18),
//
//         side:
//         const BorderSide(
//           color:
//           Color(0xFFE4E8F0),
//         ),
//       ),
//
//       child: ClipRRect(
//         borderRadius:
//         BorderRadius.circular(18),
//
//         child:
//         SingleChildScrollView(
//           scrollDirection:
//           Axis.horizontal,
//
//           child: DataTable(
//             headingRowHeight: 52,
//
//             dataRowMinHeight:
//             62,
//
//             dataRowMaxHeight:
//             72,
//
//             columns: const [
//               DataColumn(
//                 label:
//                 Text('MIL'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Audit Type'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Date'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Vendor'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Site'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Auditor'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Status'),
//               ),
//
//               DataColumn(
//                 label:
//                 Text('Action'),
//               ),
//               DataColumn(
//                 label: Text('Hours'),
//               ),
//
//               DataColumn(
//                 label: Text('CPH'),
//               ),
//
//               DataColumn(
//                 label: Text('Score'),
//               ),
//
//               DataColumn(
//                 label: Text('MIL Status'),
//               ),
//
//             ],
//
//             rows:
//             audits.map(
//                   (map) {
//                 final audit =
//                 Audit.fromMap(
//                   map,
//                 );
//
//                 final completed =
//                     audit.status ==
//                         'Completed';
//
//                 return DataRow(
//                   cells: [
//                     DataCell(
//                       Text(
//                         audit.milNumber ??
//                             '-',
//                         style:
//                         const TextStyle(
//                           fontWeight:
//                           FontWeight.w600,
//                         ),
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         audit.auditType,
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         _date(
//                           audit.auditDate,
//                         ),
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         audit.vendor,
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         audit.site,
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         audit.auditorName,
//                       ),
//                     ),
//
//                     DataCell(
//                       _statusChip(
//                         audit.status,
//                       ),
//                     ),
//                     DataCell(
//                       Text(
//                         audit.totalTimeTakenHours
//                             .toStringAsFixed(2),
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         ((map['_cph'] as num?)?.toDouble() ?? 0)
//                             .toStringAsFixed(2),
//                       ),
//                     ),
//
//                     DataCell(
//                       Text(
//                         audit.auditType == 'Process Audit' ||
//                             audit.auditType == 'System Audit'
//                             ? ((map['_auditScore'] as num?)
//                             ?.toDouble() ??
//                             0)
//                             .toStringAsFixed(2)
//                             : '-',
//                         style: const TextStyle(
//                           fontWeight: FontWeight.w700,
//                         ),
//                       ),
//                     ),
//
//                     DataCell(
//                       _milStatusChip(
//                         map['mil_status']?.toString() ??
//                             'Not Generated',
//                       ),
//                     ),
//
//                     DataCell(
//                       TextButton.icon(
//                         onPressed:
//                             () =>
//                             _continueAudit(
//                               audit,
//                             ),
//
//                         icon:
//                         Icon(
//                           completed
//                               ? Icons
//                               .visibility_outlined
//                               : Icons
//                               .play_arrow,
//                           size: 18,
//                         ),
//
//                         label:
//                         Text(
//                           completed
//                               ? 'View'
//                               : 'Continue',
//                         ),
//                       ),
//                     ),
//                   ],
//                 );
//               },
//             ).toList(),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _statusChip(
//       String status) {
//     final completed =
//         status == 'Completed';
//
//     return Container(
//       padding:
//       const EdgeInsets.symmetric(
//         horizontal: 11,
//         vertical: 6,
//       ),
//
//       decoration:
//       BoxDecoration(
//         color: completed
//             ? Colors.green.shade50
//             : Colors.orange.shade50,
//
//         borderRadius:
//         BorderRadius.circular(20),
//       ),
//
//       child: Text(
//         completed
//             ? 'Completed'
//             : 'In Progress',
//
//         style:
//         TextStyle(
//           fontWeight:
//           FontWeight.w700,
//
//           color: completed
//               ? Colors.green.shade700
//               : Colors.orange.shade700,
//         ),
//       ),
//     );
//   }
//   Widget _milStatusChip(
//       String status,
//       ) {
//     final normalized =
//     status.trim().toLowerCase();
//
//     final isOpen =
//         normalized == 'open';
//
//     final isClosed =
//         normalized == 'closed';
//
//     Color background;
//     Color foreground;
//
//     if (isOpen) {
//       background = Colors.red.shade50;
//       foreground = Colors.red.shade700;
//     } else if (isClosed) {
//       background = Colors.green.shade50;
//       foreground = Colors.green.shade700;
//     } else {
//       background = Colors.grey.shade100;
//       foreground = Colors.grey.shade700;
//     }
//
//     return Container(
//       padding: const EdgeInsets.symmetric(
//         horizontal: 10,
//         vertical: 6,
//       ),
//       decoration: BoxDecoration(
//         color: background,
//         borderRadius:
//         BorderRadius.circular(20),
//       ),
//       child: Text(
//         status,
//         style: TextStyle(
//           color: foreground,
//           fontWeight: FontWeight.w700,
//           fontSize: 12,
//         ),
//       ),
//     );
//   }
//   Future<void> _downloadAuditSummary(
//       Audit audit) async {
//     try {
//       final findings =
//       await AuditService.getFindings(
//         audit.auditId,
//       );
//
//       await AuditPdfService
//           .shareSummaryReport(
//         audit: audit,
//         findings: findings,
//         milNumber:
//         audit.milNumber ?? '-',
//       );
//     } catch (e) {
//       if (!mounted) return;
//
//       _showError(
//         'Unable to generate Audit Summary PDF.\n$e',
//       );
//     }
//
//   }
//
// }


import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_calculation_service.dart';
import '../../services/audit/audit_service.dart';
import '../../pdf/audit/audit_summary_pdf.dart';

import 'audit_details_screen.dart';
import 'audit_process_selection_screen.dart';
import 'audit_summary_screen.dart';
import 'audit_mil_screen.dart';

class AuditHomeScreen extends StatefulWidget {
  const AuditHomeScreen({
    super.key,
  });

  @override
  State<AuditHomeScreen> createState() =>
      _AuditHomeScreenState();
}

class _AuditHomeScreenState
    extends State<AuditHomeScreen> {
  bool loading = true;

  List<Map<String, dynamic>> audits = [];

  @override
  void initState() {
    super.initState();
    _loadAudits();
  }

  // ============================================================
  // LOAD AUDITS
  // ============================================================

  Future<void> _loadAudits() async {
    try {
      final result =
      await AuditService.getAuditPlan();

      final enriched =
      <Map<String, dynamic>>[];

      for (final map in result) {
        final audit =
        Audit.fromMap(map);

        List<AuditFinding> findings = [];

        try {
          findings =
          await AuditService.getFindings(
            audit.auditId,
          );
        } catch (_) {
          findings = [];
        }

        final critical =
        AuditCalculationService
            .criticalCount(
          findings,
        );

        final major =
        AuditCalculationService
            .majorCount(
          findings,
        );

        final minor =
        AuditCalculationService
            .minorCount(
          findings,
        );

        final cph =
        AuditCalculationService.cph(
          audit: audit,
          findings: findings,
        );

        final score =
        AuditCalculationService
            .auditScore(
          audit: audit,
          findings: findings,
        );

        enriched.add({
          ...map,
          '_critical': critical,
          '_major': major,
          '_minor': minor,
          '_cph': cph,
          '_auditScore': score,
        });
      }

      if (!mounted) {
        return;
      }

      setState(() {
        audits = enriched;
        loading = false;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }

      setState(() {
        loading = false;
      });

      _showError(
        'Unable to load Audit Plan.\n$e',
      );
    }
  }

  // ============================================================
  // START NEW AUDIT
  // ============================================================

  Future<void> _startNewAudit() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
        const AuditDetailsScreen(),
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      loading = true;
    });

    await _loadAudits();
  }

  // ============================================================
  // CONTINUE AUDIT
  // ============================================================

  Future<void> _continueAudit(
      Audit audit,
      ) async {
    if (audit.status == 'Completed') {
      await _viewCompletedAudit(audit);
      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            AuditProcessSelectionScreen(
              audit: audit,
            ),
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      loading = true;
    });

    await _loadAudits();
  }

  // ============================================================
  // VIEW COMPLETED AUDIT
  // ============================================================

  Future<void> _viewCompletedAudit(
      Audit audit,
      ) async {
    try {
      final findings =
      await AuditService.getFindings(
        audit.auditId,
      );

      if (!mounted) {
        return;
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) =>
              AuditSummaryScreen(
                audit: audit,
                findings: findings,
                milNumber:
                audit.milNumber ?? '-',
              ),
        ),
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      _showError(
        'Unable to open completed audit.\n$e',
      );
    }
  }
// ============================================================
// OPEN MIL REPORT
// ============================================================

  Future<void> _openMilReport(
      Audit audit,
      ) async {
    if (audit.status != 'Completed') {
      _showError(
        'MIL Report is available only after the audit is completed.',
      );
      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            AuditMilScreen(
              audit: audit,
            ),
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      loading = true;
    });

    await _loadAudits();
  }
  // ============================================================
  // DOWNLOAD ALL AUDIT SUMMARY
  // ============================================================

  Future<void> _downloadAuditSummary() async {
    if (audits.isEmpty) {
      _showError(
        'There are no audits to include in the summary.',
      );
      return;
    }

    try {
      final auditObjects =
      <Audit>[];

      final findingsByAudit =
      <String, List<AuditFinding>>{};

      for (final map in audits) {
        final audit =
        Audit.fromMap(map);

        auditObjects.add(audit);

        try {
          findingsByAudit[audit.auditId] =
          await AuditService.getFindings(
            audit.auditId,
          );
        } catch (_) {
          findingsByAudit[audit.auditId] =
          [];
        }
      }

      final bytes =
      await AuditSummaryPdf.generateAll(
        audits: auditObjects,
        findingsByAudit:
        findingsByAudit,
      );

      await Printing.sharePdf(
        bytes: bytes,
        filename:
        'Audit_Summary_All_Audits.pdf',
      );

      if (!mounted) {
        return;
      }

      _showMessage(
        'Audit summary generated successfully.',
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      _showError(
        'Unable to generate Audit Summary.\n$e',
      );
    }
  }

  // ============================================================
  // ERROR
  // ============================================================

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior:
        SnackBarBehavior.floating,
      ),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior:
        SnackBarBehavior.floating,
      ),
    );
  }

  // ============================================================
  // DATE
  // ============================================================

  String _date(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }

  // ============================================================
  // STATUS CHIP
  // ============================================================

  Widget _statusChip(String status) {
    final completed =
        status == 'Completed';

    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration:
      BoxDecoration(
        color: completed
            ? Colors.green.shade50
            : Colors.orange.shade50,
        borderRadius:
        BorderRadius.circular(20),
      ),
      child: Text(
        completed
            ? 'Completed'
            : 'In Progress',
        style: TextStyle(
          fontSize: 12,
          fontWeight:
          FontWeight.w700,
          color: completed
              ? Colors.green.shade700
              : Colors.orange.shade700,
        ),
      ),
    );
  }

  // ============================================================
  // MIL STATUS
  //
  // Open / Pending / Not Closed = RED
  // Closed = GREEN
  // ============================================================

  Widget _milStatusChip(
      String status,
      ) {
    final closed =
        status.trim().toLowerCase() ==
            'closed';

    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration:
      BoxDecoration(
        color: closed
            ? Colors.green.shade50
            : Colors.red.shade50,
        borderRadius:
        BorderRadius.circular(20),
      ),
      child: Text(
        closed ? 'Closed' : 'Open',
        style: TextStyle(
          fontSize: 12,
          fontWeight:
          FontWeight.w700,
          color: closed
              ? Colors.green.shade700
              : Colors.red.shade700,
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: const Text(
          'Audit Management',
          style: TextStyle(
            fontWeight:
            FontWeight.w800,
          ),
        ),
        backgroundColor:
        Colors.white,
        foregroundColor:
        const Color(0xFF172033),
        elevation: 0,
      ),

      body: Padding(
        padding:
        const EdgeInsets.all(28),

        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,

          children: [
            // ==================================================
            // HEADER
            // ==================================================

            Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Audit Plan',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight:
                          FontWeight.w800,
                          color:
                          Color(0xFF172033),
                        ),
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      Text(
                        'Plan, perform and track audits',
                        style: TextStyle(
                          color:
                          Color(0xFF6B7280),
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),

                OutlinedButton.icon(
                  onPressed:
                  _downloadAuditSummary,
                  icon: const Icon(
                    Icons.picture_as_pdf_outlined,
                    size: 18,
                  ),
                  label: const Text(
                    'Audit Summary',
                  ),
                  style:
                  OutlinedButton.styleFrom(
                    padding:
                    const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 14,
                    ),
                    shape:
                    RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(
                        10,
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 10),

                ElevatedButton.icon(
                  onPressed:
                  _startNewAudit,
                  icon: const Icon(
                    Icons.add,
                    size: 18,
                  ),
                  label: const Text(
                    'Start New Audit',
                  ),
                  style:
                  ElevatedButton.styleFrom(
                    padding:
                    const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 14,
                    ),
                    shape:
                    RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(
                        10,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 24,
            ),

            // ==================================================
            // PLAN
            // ==================================================

            Expanded(
              child: loading
                  ? const Center(
                child:
                CircularProgressIndicator(),
              )
                  : _buildPlan(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // AUDIT PLAN TABLE
  // ============================================================

  Widget _buildPlan() {
    if (audits.isEmpty) {
      return Card(
        elevation: 0,
        shape:
        RoundedRectangleBorder(
          borderRadius:
          BorderRadius.circular(18),
          side:
          const BorderSide(
            color:
            Color(0xFFE4E8F0),
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment:
            MainAxisAlignment.center,
            children: [
              Icon(
                Icons
                    .fact_check_outlined,
                size: 58,
                color:
                Color(0xFF9CA3AF),
              ),
              SizedBox(
                height: 14,
              ),
              Text(
                'No audits found',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight:
                  FontWeight.w700,
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Start a new audit to create an audit plan.',
                style: TextStyle(
                  color:
                  Color(0xFF6B7280),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      elevation: 0,
      shape:
      RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(18),
        side:
        const BorderSide(
          color:
          Color(0xFFE4E8F0),
        ),
      ),
      child: ClipRRect(
        borderRadius:
        BorderRadius.circular(18),
        child:
        SingleChildScrollView(
          scrollDirection:
          Axis.horizontal,
          child: DataTable(
            headingRowHeight: 52,
            dataRowMinHeight: 62,
            dataRowMaxHeight: 74,

            columns: const [
              DataColumn(
                label: Text('MIL'),
              ),
              DataColumn(
                label:
                Text('Audit Type'),
              ),
              DataColumn(
                label:
                Text('Date'),
              ),
              DataColumn(
                label:
                Text('Vendor'),
              ),
              DataColumn(
                label:
                Text('Site'),
              ),
              DataColumn(
                label:
                Text('Auditor'),
              ),
              DataColumn(
                label:
                Text('Status'),
              ),
              DataColumn(
                label:
                Text('Hours'),
              ),
              DataColumn(
                label:
                Text('CPH'),
              ),
              DataColumn(
                label:
                Text('Score'),
              ),
              DataColumn(
                label:
                Text('MIL Status'),
              ),
              DataColumn(
                label:
                Text('MIL Report'),
              ),
              DataColumn(
                label:
                Text('Action'),
              ),
            ],

            rows:
            audits.map(
                  (map) {
                final audit =
                Audit.fromMap(
                  map,
                );

                final completed =
                    audit.status ==
                        'Completed';

                final cph =
                    (map['_cph']
                    as num?)
                        ?.toDouble() ??
                        0;

                final score =
                    (map['_auditScore']
                    as num?)
                        ?.toDouble() ??
                        0;

                final milStatus =
                    map['mil_status']
                        ?.toString() ??
                        'Open';

                return DataRow(
                  cells: [
                    DataCell(
                      Text(
                        audit.milNumber ??
                            '-',
                        style:
                        const TextStyle(
                          fontWeight:
                          FontWeight.w600,
                        ),
                      ),
                    ),

                    DataCell(
                      Text(
                        audit.auditType,
                      ),
                    ),

                    DataCell(
                      Text(
                        _date(
                          audit.auditDate,
                        ),
                      ),
                    ),

                    DataCell(
                      Text(
                        audit.vendor,
                      ),
                    ),

                    DataCell(
                      Text(
                        audit.site,
                      ),
                    ),

                    DataCell(
                      Text(
                        audit.auditorName,
                      ),
                    ),

                    DataCell(
                      _statusChip(
                        audit.status,
                      ),
                    ),

                    DataCell(
                      Text(
                        audit
                            .totalTimeTakenHours
                            .toStringAsFixed(
                          2,
                        ),
                      ),
                    ),

                    DataCell(
                      Text(
                        cph.toStringAsFixed(
                          2,
                        ),
                      ),
                    ),

                    DataCell(
                      Text(
                        audit.auditType ==
                            'Process Audit' ||
                            audit.auditType ==
                                'System Audit'
                            ? score
                            .toStringAsFixed(
                          2,
                        )
                            : '-',
                        style:
                        const TextStyle(
                          fontWeight:
                          FontWeight.w700,
                        ),
                      ),
                    ),

                    DataCell(
                      _milStatusChip(
                        milStatus,
                      ),
                    ),

// ========================================================
// MIL REPORT
// ========================================================

                    DataCell(
                      audit.status == 'Completed'
                          ? TextButton.icon(
                        onPressed: () =>
                            _openMilReport(
                              audit,
                            ),
                        icon: const Icon(
                          Icons.description_outlined,
                          size: 17,
                        ),
                        label: const Text(
                          'Open',
                        ),
                      )
                          : const Text(
                        '-',
                        style: TextStyle(
                          color: Color(0xFF9CA3AF),
                        ),
                      ),
                    ),

// ========================================================
// ACTION
// ========================================================

                    DataCell(
                      TextButton.icon(
                        onPressed: () =>
                            _continueAudit(
                              audit,
                            ),
                        icon: Icon(
                          completed
                              ? Icons.visibility_outlined
                              : Icons.play_arrow,
                          size: 17,
                        ),
                        label: Text(
                          completed
                              ? 'View'
                              : 'Continue',
                        ),
                      ),
                    ),
                  ],
                );
              },
            ).toList(),
          ),
        ),
      ),
    );
  }
}