import 'package:flutter/material.dart';

class AuditTypeScreen extends StatelessWidget {
  final void Function(String type) onSelected;

  const AuditTypeScreen({
    super.key,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final types = [
      (
      'Process Audit',
      Icons.factory_rounded,
      ),
      (
      'System Audit',
      Icons.account_tree_rounded,
      ),
      (
      'Product Audit',
      Icons.inventory_2_rounded,
      ),
    ];

    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text(
          'Select Audit Type',
        ),
        backgroundColor: Colors.white,
        foregroundColor:
        const Color(0xFF172033),
        elevation: 0,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints:
          const BoxConstraints(
            maxWidth: 900,
          ),
          child: Padding(
            padding:
            const EdgeInsets.all(30),
            child: Row(
              children: types.map((type) {
                return Expanded(
                  child: Padding(
                    padding:
                    const EdgeInsets.all(10),
                    child: InkWell(
                      onTap: () =>
                          onSelected(type.$1),
                      borderRadius:
                      BorderRadius.circular(22),
                      child: Container(
                        height: 230,
                        decoration:
                        BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                          BorderRadius.circular(
                            22,
                          ),
                          border: Border.all(
                            color: const Color(
                              0xFFE4E8F0,
                            ),
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.center,
                          children: [
                            Icon(
                              type.$2,
                              size: 52,
                              color:
                              const Color(
                                0xFF3155D9,
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Text(
                              type.$1,
                              style:
                              const TextStyle(
                                fontSize: 20,
                                fontWeight:
                                FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }
}