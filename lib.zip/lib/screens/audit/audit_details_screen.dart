// import '../../services/supabase_service.dart';
// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../services/audit/audit_service.dart';
// import 'audit_process_selection_screen.dart';
// import 'audit_checklist_screen.dart';
//
// class AuditDetailsScreen extends StatefulWidget {
//   const AuditDetailsScreen({
//     super.key,
//   });
//
//   @override
//   State<AuditDetailsScreen> createState() =>
//       _AuditDetailsScreenState();
// }
// Future<void> _checkSupabaseSession() async {
//   final supabase = SupabaseService.client;
//
//   final session = supabase.auth.currentSession;
//   final user = supabase.auth.currentUser;
//
//   debugPrint('========== SUPABASE SESSION ==========');
//   debugPrint('Session exists: ${session != null}');
//   debugPrint('User ID: ${user?.id}');
//   debugPrint('Email: ${user?.email}');
//   debugPrint('Access token exists: ${session?.accessToken != null}');
//   debugPrint('======================================');
// }
// class _AuditDetailsScreenState
//     extends State<AuditDetailsScreen> {
//   String? auditType;
//
//   final vendor = TextEditingController();
//   final site = TextEditingController();
//   final lob = TextEditingController();
//   final program = TextEditingController();
//   final line = TextEditingController();
//   final apn = TextEditingController();
//   final auditor = TextEditingController();
//
//   DateTime auditDate = DateTime.now();
//
//   bool isStartingAudit = false;
//
//   @override
//   void dispose() {
//     vendor.dispose();
//     site.dispose();
//     lob.dispose();
//     program.dispose();
//     line.dispose();
//     apn.dispose();
//     auditor.dispose();
//
//     super.dispose();
//   }
//
//   Future<void> _startAudit() async {
//     FocusScope.of(context).unfocus();
//
//     if (auditType == null || auditType!.isEmpty) {
//       _error('Select audit type.');
//       return;
//     }
//
//     if (vendor.text.trim().isEmpty ||
//         site.text.trim().isEmpty ||
//         lob.text.trim().isEmpty ||
//         auditor.text.trim().isEmpty) {
//       _error(
//         'Vendor, Site, LOB and Auditor Name are required.',
//       );
//       return;
//     }
//
//     if (isStartingAudit) {
//       return;
//     }
//
//     setState(() {
//       isStartingAudit = true;
//     });
//
//     try {
//       final Audit audit =
//       await AuditService.createAudit(
//         auditType: auditType!,
//         vendor: vendor.text.trim(),
//         site: site.text.trim(),
//         lob: lob.text.trim(),
//         program: program.text.trim(),
//         line: line.text.trim(),
//         apn: apn.text.trim(),
//         auditDate: auditDate,
//         auditorName: auditor.text.trim(),
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       if (auditType == 'Process Audit') {
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(
//             builder: (_) =>
//                 AuditProcessSelectionScreen(
//                   audit: audit,
//                 ),
//           ),
//         );
//       } else {
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(
//             builder: (_) =>
//                 AuditChecklistScreen(
//                   audit: audit,
//                 ),
//           ),
//         );
//       }
//     } catch (e) {
//       if (!mounted) {
//         return;
//       }
//
//       _error(
//         _cleanErrorMessage(e),
//       );
//     } finally {
//       if (mounted) {
//         setState(() {
//           isStartingAudit = false;
//         });
//       }
//     }
//   }
//
//   String _cleanErrorMessage(Object error) {
//     final message = error.toString();
//
//     if (message.contains(
//       'row-level security policy',
//     )) {
//       return 'Unable to create audit. '
//           'The database security policy is blocking '
//           'this operation. Please check Supabase RLS policies.';
//     }
//
//     return message;
//   }
//
//   void _error(String message) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior: SnackBarBehavior.floating,
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: const Text(
//           'Audit Details',
//         ),
//         backgroundColor: Colors.white,
//         foregroundColor: const Color(0xFF172033),
//         elevation: 0,
//       ),
//
//       body: Center(
//         child: ConstrainedBox(
//           constraints: const BoxConstraints(
//             maxWidth: 900,
//           ),
//
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(30),
//
//             child: Column(
//               crossAxisAlignment:
//               CrossAxisAlignment.start,
//
//               children: [
//
//                 // =================================================
//                 // AUDIT TYPE
//                 // =================================================
//
//                 _sectionTitle(
//                   'Audit Type',
//                 ),
//
//                 const SizedBox(height: 10),
//
//                 DropdownButtonFormField<String>(
//                   value: auditType,
//
//                   decoration:
//                   const InputDecoration(
//                     labelText:
//                     'Select Audit Type',
//                     border:
//                     OutlineInputBorder(),
//                     prefixIcon: Icon(
//                       Icons.fact_check_outlined,
//                     ),
//                   ),
//
//                   items: const [
//                     DropdownMenuItem<String>(
//                       value: 'Process Audit',
//                       child: Text(
//                         'Process Audit',
//                       ),
//                     ),
//
//                     DropdownMenuItem<String>(
//                       value: 'System Audit',
//                       child: Text(
//                         'System Audit',
//                       ),
//                     ),
//
//                     DropdownMenuItem<String>(
//                       value: 'Product Audit',
//                       child: Text(
//                         'Product Audit',
//                       ),
//                     ),
//                   ],
//
//                   onChanged: isStartingAudit
//                       ? null
//                       : (value) {
//                     setState(() {
//                       auditType = value;
//                     });
//                   },
//                 ),
//
//                 const SizedBox(height: 25),
//
//                 // =================================================
//                 // AUDIT INFORMATION
//                 // =================================================
//
//                 _sectionTitle(
//                   'Audit Information',
//                 ),
//
//                 const SizedBox(height: 15),
//
//                 _grid(),
//
//                 const SizedBox(height: 30),
//
//                 // =================================================
//                 // START AUDIT
//                 // =================================================
//
//                 SizedBox(
//                   width: double.infinity,
//                   height: 52,
//
//                   child: ElevatedButton.icon(
//                     onPressed: isStartingAudit
//                         ? null
//                         : _startAudit,
//
//                     icon: isStartingAudit
//                         ? const SizedBox(
//                       width: 20,
//                       height: 20,
//                       child:
//                       CircularProgressIndicator(
//                         strokeWidth: 2,
//                       ),
//                     )
//                         : const Icon(
//                       Icons.play_arrow,
//                     ),
//
//                     label: Text(
//                       isStartingAudit
//                           ? 'Starting Audit...'
//                           : 'Start Audit',
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _sectionTitle(
//       String text,
//       ) {
//     return Text(
//       text,
//       style: const TextStyle(
//         fontSize: 21,
//         fontWeight: FontWeight.w800,
//       ),
//     );
//   }
//
//   Widget _grid() {
//     return LayoutBuilder(
//       builder: (
//           context,
//           constraints,
//           ) {
//         final width =
//             (constraints.maxWidth - 20) / 2;
//
//         return Wrap(
//           spacing: 20,
//           runSpacing: 18,
//
//           children: [
//
//             _field(
//               'Vendor',
//               vendor,
//               width,
//             ),
//
//             _field(
//               'Site',
//               site,
//               width,
//             ),
//
//             _field(
//               'LOB',
//               lob,
//               width,
//             ),
//
//             _field(
//               'Program',
//               program,
//               width,
//             ),
//
//             _field(
//               'Line',
//               line,
//               width,
//             ),
//
//             _field(
//               'APN',
//               apn,
//               width,
//             ),
//
//             // ================================================
//             // AUDIT DATE
//             // ================================================
//
//             SizedBox(
//               width: width,
//
//               child: InkWell(
//                 onTap: isStartingAudit
//                     ? null
//                     : () async {
//                   final date =
//                   await showDatePicker(
//                     context: context,
//                     firstDate:
//                     DateTime(2020),
//                     lastDate:
//                     DateTime(2100),
//                     initialDate:
//                     auditDate,
//                   );
//
//                   if (date != null &&
//                       mounted) {
//                     setState(() {
//                       auditDate = date;
//                     });
//                   }
//                 },
//
//                 child: InputDecorator(
//                   decoration:
//                   const InputDecoration(
//                     labelText:
//                     'Audit Date',
//                     border:
//                     OutlineInputBorder(),
//                     suffixIcon: Icon(
//                       Icons.calendar_today,
//                     ),
//                   ),
//
//                   child: Text(
//                     '${auditDate.day.toString().padLeft(2, '0')}/'
//                         '${auditDate.month.toString().padLeft(2, '0')}/'
//                         '${auditDate.year}',
//                   ),
//                 ),
//               ),
//             ),
//
//             _field(
//               'Auditor Name',
//               auditor,
//               width,
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   Widget _field(
//       String label,
//       TextEditingController controller,
//       double width,
//       ) {
//     return SizedBox(
//       width: width,
//
//       child: TextField(
//         controller: controller,
//
//         enabled: !isStartingAudit,
//
//         textInputAction:
//         TextInputAction.next,
//
//         decoration:
//         InputDecoration(
//           labelText: label,
//           border:
//           const OutlineInputBorder(),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

import '../../models/audit/audit.dart';
import '../../services/audit/audit_service.dart';
import 'audit_process_selection_screen.dart';

class AuditDetailsScreen extends StatefulWidget {
  const AuditDetailsScreen({
    super.key,
  });

  @override
  State<AuditDetailsScreen> createState() =>
      _AuditDetailsScreenState();
}

class _AuditDetailsScreenState
    extends State<AuditDetailsScreen> {
  String? auditType;

  final vendor =
  TextEditingController();
  final site =
  TextEditingController();
  final lob =
  TextEditingController();
  final program =
  TextEditingController();
  final line =
  TextEditingController();
  final apn =
  TextEditingController();
  final auditor =
  TextEditingController();


  final timeTakenController =
  TextEditingController();

  DateTime auditDate =
  DateTime.now();

  bool isStartingAudit = false;

  @override
  void dispose() {
    vendor.dispose();
    site.dispose();
    lob.dispose();
    program.dispose();
    line.dispose();
    apn.dispose();
    auditor.dispose();
    timeTakenController.dispose();
    super.dispose();
  }

  Future<void> _startAudit() async {
    FocusScope.of(context).unfocus();

    if (auditType == null ||
        auditType!.trim().isEmpty) {
      _error(
        'Select audit type.',
      );
      return;
    }

    if (vendor.text.trim().isEmpty ||
        site.text.trim().isEmpty ||
        lob.text.trim().isEmpty ||
        auditor.text.trim().isEmpty) {
      _error(
        'Vendor, Site, LOB and Auditor Name are required.',
      );
      return;
    }

    final timeTakenHours =
    double.tryParse(
      timeTakenController.text.trim(),
    );

    if (timeTakenHours == null ||
        timeTakenHours <= 0) {
      _error(
        'Please enter a valid Time Taken in hours.',
      );
      return;
    }

    if (isStartingAudit) {
      return;
    }

    setState(() {
      isStartingAudit = true;
    });

    try {
      final audit =
      await AuditService.createAudit(
        auditType: auditType!,
        vendor: vendor.text,
        site: site.text,
        lob: lob.text,
        program: program.text,
        line: line.text,
        apn: apn.text,
        auditDate: auditDate,
        auditorName: auditor.text,
        totalTimeTakenHours:
        timeTakenHours,
      );

      if (!mounted) {
        return;
      }

      // IMPORTANT:
      // Every audit type goes to the category screen.
      //
      // Do NOT directly open MIL.
      // Do NOT directly open checklist.
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              AuditProcessSelectionScreen(
                audit: audit,
              ),
        ),
      );
    } catch (e) {
      if (!mounted) {
        return;
      }

      _error(
        _cleanErrorMessage(e),
      );
    } finally {
      if (mounted) {
        setState(() {
          isStartingAudit = false;
        });
      }
    }
  }

  String _cleanErrorMessage(
      Object error) {
    final message =
    error.toString();

    if (message.contains(
      'row-level security',
    )) {
      return 'Unable to create audit because the database security policy blocked the operation.';
    }

    return message;
  }

  void _error(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior:
        SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: const Text(
          'Audit Details',
          style: TextStyle(
            fontWeight:
            FontWeight.w700,
          ),
        ),
        backgroundColor:
        Colors.white,
        foregroundColor:
        const Color(0xFF172033),
        elevation: 0,
      ),

      body: Center(
        child: ConstrainedBox(
          constraints:
          const BoxConstraints(
            maxWidth: 900,
          ),

          child:
          SingleChildScrollView(
            padding:
            const EdgeInsets.all(30),

            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,

              children: [
                _sectionTitle(
                  'Audit Type',
                ),

                const SizedBox(
                  height: 10,
                ),

                DropdownButtonFormField<
                    String>(
                  value: auditType,

                  decoration:
                  const InputDecoration(
                    labelText:
                    'Select Audit Type',
                    border:
                    OutlineInputBorder(),
                    prefixIcon:
                    Icon(
                      Icons
                          .fact_check_outlined,
                    ),
                  ),

                  items: const [
                    DropdownMenuItem<
                        String>(
                      value:
                      'Process Audit',
                      child: Text(
                        'Process Audit',
                      ),
                    ),
                    DropdownMenuItem<
                        String>(
                      value:
                      'System Audit',
                      child: Text(
                        'System Audit',
                      ),
                    ),
                    DropdownMenuItem<
                        String>(
                      value:
                      'Product Audit',
                      child: Text(
                        'Product Audit',
                      ),
                    ),
                  ],

                  onChanged:
                  isStartingAudit
                      ? null
                      : (value) {
                    setState(() {
                      auditType =
                          value;
                    });
                  },
                ),

                const SizedBox(
                  height: 25,
                ),

                _sectionTitle(
                  'Audit Information',
                ),

                const SizedBox(
                  height: 15,
                ),

                _grid(),

                const SizedBox(
                  height: 30,
                ),

                SizedBox(
                  width:
                  double.infinity,
                  height: 52,

                  child:
                  ElevatedButton.icon(
                    onPressed:
                    isStartingAudit
                        ? null
                        : _startAudit,

                    icon:
                    isStartingAudit
                        ? const SizedBox(
                      width: 20,
                      height: 20,
                      child:
                      CircularProgressIndicator(
                        strokeWidth: 2,
                      ),
                    )
                        : const Icon(
                      Icons.play_arrow,
                    ),

                    label: Text(
                      isStartingAudit
                          ? 'Starting Audit...'
                          : 'Start Audit',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(
      String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 21,
        fontWeight:
        FontWeight.w800,
      ),
    );
  }

  Widget _grid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width =
            (constraints.maxWidth - 20) / 2;

        return Wrap(
          spacing: 20,
          runSpacing: 18,
          children: [
            _field(
              'Vendor',
              vendor,
              width,
            ),

            _field(
              'Site',
              site,
              width,
            ),

            _field(
              'LOB',
              lob,
              width,
            ),

            _field(
              'Program',
              program,
              width,
            ),

            _field(
              'Line',
              line,
              width,
            ),

            _field(
              'APN',
              apn,
              width,
            ),

            SizedBox(
              width: width,
              child: InkWell(
                onTap: () async {
                  final date =
                  await showDatePicker(
                    context: context,
                    firstDate:
                    DateTime(2020),
                    lastDate:
                    DateTime(2100),
                    initialDate: auditDate,
                  );

                  if (date != null) {
                    setState(() {
                      auditDate = date;
                    });
                  }
                },
                child: InputDecorator(
                  decoration:
                  const InputDecoration(
                    labelText: 'Audit Date',
                    border:
                    OutlineInputBorder(),
                    suffixIcon:
                    Icon(
                      Icons.calendar_today,
                    ),
                  ),
                  child: Text(
                    '${auditDate.day.toString().padLeft(2, '0')}/'
                        '${auditDate.month.toString().padLeft(2, '0')}/'
                        '${auditDate.year}',
                  ),
                ),
              ),
            ),

            _field(
              'Auditor Name',
              auditor,
              width,
            ),

            // ==================================================
            // OVERALL AUDIT TIME
            // ==================================================

            SizedBox(
              width: width,
              child: TextField(
                controller: timeTakenController,
                keyboardType:
                const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration:
                const InputDecoration(
                  labelText:
                  'Time Taken (Hours)',
                  hintText:
                  'Example: 5.50',
                  prefixIcon:
                  Icon(
                    Icons.schedule_outlined,
                  ),
                  border:
                  OutlineInputBorder(),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _field(
      String label,
      TextEditingController controller,
      double width,
      ) {
    return SizedBox(
      width: width,
      child: TextField(
        controller: controller,
        decoration:
        InputDecoration(
          labelText: label,
          border:
          const OutlineInputBorder(),
        ),
      ),
    );
  }
}