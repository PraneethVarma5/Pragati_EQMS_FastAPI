// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_pdf_service.dart';
//
// class AuditSummaryScreen
//     extends StatelessWidget {
//   final Audit audit;
//   final List<AuditFinding> findings;
//   final String milNumber;
//
//   const AuditSummaryScreen({
//     super.key,
//     required this.audit,
//     required this.findings,
//     required this.milNumber,
//   });
//
//   int _count(FindingCategory category) {
//     return findings
//         .where(
//           (finding) =>
//       finding.category == category,
//     )
//         .length;
//   }
//
//   double get hours {
//     if (audit.startedAt == null ||
//         audit.finishedAt == null) {
//       return 0;
//     }
//
//     return audit.finishedAt!
//         .difference(audit.startedAt!)
//         .inSeconds /
//         3600;
//   }
//
//   double get cph {
//     if (hours <= 0) return 0;
//
//     return (_count(
//       FindingCategory.critical,
//     ) +
//         _count(
//           FindingCategory.major,
//         )) /
//         hours;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//       appBar: AppBar(
//         title: const Text(
//           'Audit Summary',
//         ),
//         backgroundColor: Colors.white,
//         foregroundColor:
//         const Color(0xFF172033),
//         elevation: 0,
//       ),
//       body: SingleChildScrollView(
//         padding:
//         const EdgeInsets.all(28),
//         child: Column(
//           children: [
//             _header(),
//             const SizedBox(height: 20),
//             _statistics(),
//             const SizedBox(height: 25),
//             _details(),
//             const SizedBox(height: 25),
//             _actions(context),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _header() {
//     return Card(
//       elevation: 0,
//       child: Padding(
//         padding:
//         const EdgeInsets.all(25),
//         child: Row(
//           children: [
//             Container(
//               width: 60,
//               height: 60,
//               decoration:
//               BoxDecoration(
//                 color:
//                 Colors.green.shade50,
//                 borderRadius:
//                 BorderRadius.circular(
//                   15,
//                 ),
//               ),
//               child: Icon(
//                 Icons.check_circle,
//                 color:
//                 Colors.green.shade600,
//                 size: 35,
//               ),
//             ),
//             const SizedBox(width: 18),
//             Column(
//               crossAxisAlignment:
//               CrossAxisAlignment.start,
//               children: [
//                 const Text(
//                   'Audit Completed',
//                   style:
//                   TextStyle(
//                     fontSize: 24,
//                     fontWeight:
//                     FontWeight.w800,
//                   ),
//                 ),
//                 Text(
//                   'MIL Number: $milNumber',
//                   style:
//                   const TextStyle(
//                     color:
//                     Color(0xFF6B7280),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _statistics() {
//     return Row(
//       children: [
//         _stat(
//           'Critical',
//           _count(
//             FindingCategory.critical,
//           ),
//           Colors.red,
//         ),
//         _stat(
//           'Major',
//           _count(
//             FindingCategory.major,
//           ),
//           Colors.orange,
//         ),
//         _stat(
//           'Minor',
//           _count(
//             FindingCategory.minor,
//           ),
//           Colors.green,
//         ),
//         _stat(
//           'Audited Hours',
//           hours.toStringAsFixed(2),
//           Colors.blue,
//         ),
//         _stat(
//           'CPH',
//           cph.toStringAsFixed(2),
//           Colors.purple,
//         ),
//       ],
//     );
//   }
//
//   Widget _stat(
//       String title,
//       Object value,
//       Color color,
//       ) {
//     return Expanded(
//       child: Card(
//         elevation: 0,
//         child: Padding(
//           padding:
//           const EdgeInsets.all(20),
//           child: Column(
//             children: [
//               Text(
//                 '$value',
//                 style: TextStyle(
//                   fontSize: 28,
//                   fontWeight:
//                   FontWeight.w800,
//                   color: color,
//                 ),
//               ),
//               const SizedBox(height: 5),
//               Text(
//                 title,
//                 style:
//                 const TextStyle(
//                   color:
//                   Color(0xFF6B7280),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _details() {
//     return Card(
//       elevation: 0,
//       child: Padding(
//         padding:
//         const EdgeInsets.all(25),
//         child: Column(
//           children: [
//             _row(
//               'Audit Type',
//               audit.auditType,
//             ),
//             _row(
//               'Audit Date',
//               '${audit.auditDate.day}/'
//                   '${audit.auditDate.month}/'
//                   '${audit.auditDate.year}',
//             ),
//             _row(
//               'Vendor',
//               audit.vendor,
//             ),
//             _row(
//               'Site',
//               audit.site,
//             ),
//             _row(
//               'LOB',
//               audit.lob,
//             ),
//             _row(
//               'Program',
//               audit.program,
//             ),
//             _row(
//               'Line',
//               audit.line,
//             ),
//             _row(
//               'APN',
//               audit.apn,
//             ),
//             _row(
//               'Auditor',
//               audit.auditorName,
//             ),
//             _row(
//               'Started',
//               audit.startedAt
//                   ?.toLocal()
//                   .toString() ??
//                   '-',
//             ),
//             _row(
//               'Finished',
//               audit.finishedAt
//                   ?.toLocal()
//                   .toString() ??
//                   '-',
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _row(
//       String label,
//       String value,
//       ) {
//     return Padding(
//       padding:
//       const EdgeInsets.symmetric(
//         vertical: 9,
//       ),
//       child: Row(
//         children: [
//           SizedBox(
//             width: 180,
//             child: Text(
//               label,
//               style:
//               const TextStyle(
//                 fontWeight:
//                 FontWeight.w700,
//               ),
//             ),
//           ),
//           Expanded(
//             child: Text(value),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _actions(BuildContext context) {
//     return Row(
//       mainAxisAlignment:
//       MainAxisAlignment.center,
//       children: [
//         ElevatedButton.icon(
//           onPressed: () {
//             AuditPdfService
//                 .shareMilReport(
//               audit: audit,
//               findings: findings,
//               milNumber: milNumber,
//             );
//           },
//           icon:
//           const Icon(Icons.picture_as_pdf),
//           label: const Text(
//             'MIL Report',
//           ),
//         ),
//         const SizedBox(width: 15),
//         ElevatedButton.icon(
//           onPressed: () {
//             AuditPdfService
//                 .shareSummaryReport(
//               audit: audit,
//               findings: findings,
//               milNumber: milNumber,
//             );
//           },
//           icon:
//           const Icon(Icons.summarize),
//           label: const Text(
//             'Audit Summary',
//           ),
//         ),
//       ],
//     );
//   }
// }
import 'package:flutter/material.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_calculation_service.dart';
import '../../services/audit/audit_pdf_service.dart';

class AuditSummaryScreen
    extends StatelessWidget {
  final Audit audit;
  final List<AuditFinding> findings;
  final String milNumber;

  const AuditSummaryScreen({
    super.key,
    required this.audit,
    required this.findings,
    required this.milNumber,
  });

  int _count(
      FindingCategory category) {
    return findings
        .where(
          (finding) =>
      finding.category ==
          category,
    )
        .length;
  }

  double get hours =>
      AuditCalculationService
          .auditedHours(audit);

  double get cph =>
      AuditCalculationService
          .cph(
        audit: audit,
        findings: findings,
      );
  double get score =>
      AuditCalculationService.auditScore(
        audit: audit,
        findings: findings,
      );
  String _date(
      DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }

  @override
  Widget build(
      BuildContext context) {
    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: const Text(
          'Audit Summary',
        ),

        backgroundColor:
        Colors.white,

        foregroundColor:
        const Color(
          0xFF172033,
        ),

        elevation: 0,
      ),

      body: SingleChildScrollView(
        padding:
        const EdgeInsets.all(
          28,
        ),

        child: Column(
          children: [
            _header(),

            const SizedBox(
              height: 20,
            ),

            _statistics(),

            const SizedBox(
              height: 25,
            ),

            _details(),

            const SizedBox(
              height: 25,
            ),

            _findingSummary(),

            const SizedBox(
              height: 25,
            ),

            _actions(context),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Card(
      elevation: 0,

      child: Padding(
        padding:
        const EdgeInsets.all(
          25,
        ),

        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration:
              BoxDecoration(
                color:
                Colors.green.shade50,
                borderRadius:
                BorderRadius.circular(
                  15,
                ),
              ),
              child: Icon(
                Icons.check_circle,
                color:
                Colors.green.shade600,
                size: 35,
              ),
            ),

            const SizedBox(
              width: 18,
            ),

            Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,

              children: [
                const Text(
                  'Audit Completed',
                  style:
                  TextStyle(
                    fontSize: 24,
                    fontWeight:
                    FontWeight.w800,
                  ),
                ),

                Text(
                  'MIL Number: $milNumber',
                  style:
                  const TextStyle(
                    color:
                    Color(
                      0xFF6B7280,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statistics() {
    return Row(
      children: [
        _stat(
          'Critical',
          _count(
            FindingCategory
                .critical,
          ),
          Colors.red,
        ),

        _stat(
          'Major',
          _count(
            FindingCategory.major,
          ),
          Colors.orange,
        ),

        _stat(
          'Minor',
          _count(
            FindingCategory.minor,
          ),
          Colors.green,
        ),

        _stat(
          'Audited Hours',
          hours.toStringAsFixed(2),
          Colors.blue,
        ),

        _stat(
          'CPH',
          cph.toStringAsFixed(2),
          Colors.purple,
        ),

        if (audit.auditType == 'Process Audit' ||
            audit.auditType == 'System Audit')
          _stat(
            'Audit Score',
            auditScore.toStringAsFixed(2),
            Colors.indigo,
          ),
      ],
    );
  }

  Widget _stat(
      String title,
      Object value,
      Color color) {
    return Expanded(
      child: Card(
        elevation: 0,

        child: Padding(
          padding:
          const EdgeInsets.all(
            20,
          ),

          child: Column(
            children: [
              Text(
                '$value',
                style:
                TextStyle(
                  fontSize: 28,
                  fontWeight:
                  FontWeight
                      .w800,
                  color: color,
                ),
              ),

              const SizedBox(
                height: 5,
              ),

              Text(
                title,
                style:
                const TextStyle(
                  color:
                  Color(
                    0xFF6B7280,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _details() {
    return Card(
      elevation: 0,

      child: Padding(
        padding:
        const EdgeInsets.all(
          25,
        ),

        child: Column(
          children: [
            _row(
              'Audit Type',
              audit.auditType,
            ),

            _row(
              'Audit Date',
              _date(
                audit.auditDate,
              ),
            ),

            _row(
              'Vendor',
              audit.vendor,
            ),

            _row(
              'Site',
              audit.site,
            ),

            _row(
              'LOB',
              audit.lob,
            ),

            _row(
              'Program',
              audit.program,
            ),

            _row(
              'Line',
              audit.line,
            ),

            _row(
              'APN',
              audit.apn,
            ),

            _row(
              'Auditor',
              audit.auditorName,
            ),

            _row(
              'Started',
              audit.startedAt
                  ?.toLocal()
                  .toString() ??
                  '-',
            ),

            _row(
              'Finished',
              audit.finishedAt
                  ?.toLocal()
                  .toString() ??
                  '-',
            ),

            _row(
              'Total Audited Hours',
              hours.toStringAsFixed(
                2,
              ),
            ),

            _row(
              'CPH',
              cph.toStringAsFixed(
                2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _findingSummary() {
    return Card(
      elevation: 0,

      child: Padding(
        padding:
        const EdgeInsets.all(
          25,
        ),

        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment
              .start,

          children: [
            const Text(
              'Finding Summary',
              style:
              TextStyle(
                fontSize: 19,
                fontWeight:
                FontWeight.w800,
              ),
            ),

            const SizedBox(
              height: 15,
            ),

            _findingRow(
              'Critical',
              _count(
                FindingCategory
                    .critical,
              ),
              Colors.red,
            ),

            _findingRow(
              'Major',
              _count(
                FindingCategory
                    .major,
              ),
              Colors.orange,
            ),

            _findingRow(
              'Minor',
              _count(
                FindingCategory
                    .minor,
              ),
              Colors.green,
            ),
          ],
        ),
      ),
    );
  }

  Widget _findingRow(
      String title,
      int count,
      Color color) {
    return Padding(
      padding:
      const EdgeInsets
          .symmetric(
        vertical: 8,
      ),

      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration:
            BoxDecoration(
              color: color,
              shape:
              BoxShape.circle,
            ),
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              title,
              style:
              const TextStyle(
                fontWeight:
                FontWeight.w600,
              ),
            ),
          ),

          Text(
            '$count',
            style:
            const TextStyle(
              fontWeight:
              FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(
      String label,
      String value) {
    return Padding(
      padding:
      const EdgeInsets
          .symmetric(
        vertical: 9,
      ),

      child: Row(
        children: [
          SizedBox(
            width: 180,

            child: Text(
              label,
              style:
              const TextStyle(
                fontWeight:
                FontWeight.w700,
              ),
            ),
          ),

          Expanded(
            child:
            Text(value),
          ),
        ],
      ),
    );
  }

  // Widget _actions(
  //     BuildContext context) {
  //   return Row(
  //     mainAxisAlignment:
  //     MainAxisAlignment
  //         .center,
  //
  //     children: [
  //       ElevatedButton.icon(
  //         onPressed: () {
  //           AuditPdfService
  //               .shareMilReport(
  //             audit: audit,
  //             findings: findings,
  //             milNumber:
  //             milNumber,
  //           );
  //         },
  //         icon: const Icon(
  //           Icons.picture_as_pdf,
  //         ),
  //         label:
  //         const Text(
  //           'MIL Report',
  //         ),
  //       ),
  //
  //       const SizedBox(
  //         width: 15,
  //       ),
  //
  //       ElevatedButton.icon(
  //         onPressed: () {
  //           AuditPdfService
  //               .shareSummaryReport(
  //             audit: audit,
  //             findings: findings,
  //             milNumber:
  //             milNumber,
  //           );
  //         },
  //         icon: const Icon(
  //           Icons.summarize,
  //         ),
  //         label:
  //         const Text(
  //           'Audit Summary',
  //         ),
  //       ),
  //     ],
  //   );
  // }
  Widget _actions(BuildContext context) {
    return Row(
      mainAxisAlignment:
      MainAxisAlignment.center,
      children: [
        ElevatedButton.icon(
          onPressed: () async {
            await AuditPdfService
                .shareMilReport(
              audit: audit,
              findings: findings,
              milNumber: milNumber,
            );
          },
          icon: const Icon(
            Icons.picture_as_pdf,
          ),
          label: const Text(
            'MIL Report',
          ),
        ),
      ],
    );
  }
  double get auditScore =>
      AuditCalculationService.auditScore(
        audit: audit,
        findings: findings,
      );
}