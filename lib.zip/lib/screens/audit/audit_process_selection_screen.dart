// // // import 'package:flutter/material.dart';
// // //
// // // import '../../models/audit/audit.dart';
// // // import '../../services/audit/audit_checklist_data.dart';
// // // import '../../services/audit/audit_service.dart';
// // // import 'audit_checklist_screen.dart';
// // //
// // // class AuditProcessSelectionScreen extends StatefulWidget {
// // //   final Audit audit;
// // //
// // //   const AuditProcessSelectionScreen({
// // //     super.key,
// // //     required this.audit,
// // //   });
// // //
// // //   @override
// // //   State<AuditProcessSelectionScreen> createState() =>
// // //       _AuditProcessSelectionScreenState();
// // // }
// // //
// // // class _AuditProcessSelectionScreenState
// // //     extends State<AuditProcessSelectionScreen> {
// // //   final Set<String> selected = {};
// // //
// // //   late String selectedAuditType;
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //
// // //     selectedAuditType = widget.audit.auditType.isNotEmpty
// // //         ? widget.audit.auditType
// // //         : 'Process Audit';
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Scaffold(
// // //       backgroundColor: const Color(0xFFF5F7FB),
// // //
// // //       appBar: AppBar(
// // //         title: const Text(
// // //           'Select Audit Type',
// // //         ),
// // //         backgroundColor: Colors.white,
// // //         foregroundColor: const Color(0xFF172033),
// // //         elevation: 0,
// // //       ),
// // //
// // //       body: Center(
// // //         child: ConstrainedBox(
// // //           constraints: const BoxConstraints(
// // //             maxWidth: 900,
// // //           ),
// // //
// // //           child: Padding(
// // //             padding: const EdgeInsets.all(30),
// // //
// // //             child: Column(
// // //               crossAxisAlignment: CrossAxisAlignment.start,
// // //
// // //               children: [
// // //
// // //                 const Text(
// // //                   'Audit Type',
// // //                   style: TextStyle(
// // //                     fontSize: 23,
// // //                     fontWeight: FontWeight.w800,
// // //                   ),
// // //                 ),
// // //
// // //                 const SizedBox(height: 20),
// // //
// // //                 DropdownButtonFormField<String>(
// // //                   value: selectedAuditType,
// // //
// // //                   decoration: const InputDecoration(
// // //                     labelText: 'Select Audit Type',
// // //                     border: OutlineInputBorder(),
// // //                     prefixIcon: Icon(
// // //                       Icons.fact_check_outlined,
// // //                     ),
// // //                   ),
// // //
// // //                   items: const [
// // //                     DropdownMenuItem(
// // //                       value: 'Process Audit',
// // //                       child: Text(
// // //                         'Process Audit',
// // //                       ),
// // //                     ),
// // //
// // //                     DropdownMenuItem(
// // //                       value: 'System Audit',
// // //                       child: Text(
// // //                         'System Audit',
// // //                       ),
// // //                     ),
// // //
// // //                     DropdownMenuItem(
// // //                       value: 'Product Audit',
// // //                       child: Text(
// // //                         'Product Audit',
// // //                       ),
// // //                     ),
// // //                   ],
// // //
// // //                   onChanged: (value) {
// // //                     if (value == null) {
// // //                       return;
// // //                     }
// // //
// // //                     setState(() {
// // //                       selectedAuditType = value;
// // //
// // //                       // Clear process sections when
// // //                       // switching audit type.
// // //                       selected.clear();
// // //                     });
// // //                   },
// // //                 ),
// // //
// // //                 const SizedBox(height: 25),
// // //
// // //                 if (selectedAuditType == 'Process Audit') ...[
// // //                   const Text(
// // //                     'Select the process sections to audit',
// // //                     style: TextStyle(
// // //                       fontSize: 18,
// // //                       fontWeight: FontWeight.w700,
// // //                     ),
// // //                   ),
// // //
// // //                   const SizedBox(height: 15),
// // //
// // //                   Expanded(
// // //                     child: ListView(
// // //                       children: [
// // //                         ...AuditChecklistData.processSections.map(
// // //                               (section) {
// // //                             final bool isSelected =
// // //                             selected.contains(section);
// // //
// // //                             return Card(
// // //                               elevation: 0,
// // //
// // //                               margin: const EdgeInsets.only(
// // //                                 bottom: 10,
// // //                               ),
// // //
// // //                               child: CheckboxListTile(
// // //                                 value: isSelected,
// // //
// // //                                 onChanged: (value) {
// // //                                   setState(() {
// // //                                     if (value == true) {
// // //                                       selected.add(section);
// // //                                     } else {
// // //                                       selected.remove(section);
// // //                                     }
// // //                                   });
// // //                                 },
// // //
// // //                                 title: Text(
// // //                                   'Process audit / $section',
// // //                                   style: const TextStyle(
// // //                                     fontWeight: FontWeight.w700,
// // //                                   ),
// // //                                 ),
// // //
// // //                                 secondary: Icon(
// // //                                   isSelected
// // //                                       ? Icons.check_circle
// // //                                       : Icons
// // //                                       .radio_button_unchecked,
// // //
// // //                                   color: isSelected
// // //                                       ? Colors.green
// // //                                       : Colors.grey,
// // //                                 ),
// // //                               ),
// // //                             );
// // //                           },
// // //                         ),
// // //                       ],
// // //                     ),
// // //                   ),
// // //                 ] else ...[
// // //                   Expanded(
// // //                     child: Center(
// // //                       child: Card(
// // //                         elevation: 0,
// // //
// // //                         child: Padding(
// // //                           padding: const EdgeInsets.all(25),
// // //
// // //                           child: Row(
// // //                             children: [
// // //
// // //                               Icon(
// // //                                 selectedAuditType ==
// // //                                     'Product Audit'
// // //                                     ? Icons
// // //                                     .inventory_2_outlined
// // //                                     : Icons
// // //                                     .settings_outlined,
// // //
// // //                                 size: 35,
// // //
// // //                                 color: const Color(
// // //                                   0xFF3155D9,
// // //                                 ),
// // //                               ),
// // //
// // //                               const SizedBox(width: 15),
// // //
// // //                               Expanded(
// // //                                 child: Text(
// // //                                   '$selectedAuditType checklist '
// // //                                       'will be loaded when you continue.',
// // //
// // //                                   style: const TextStyle(
// // //                                     fontSize: 16,
// // //                                     fontWeight: FontWeight.w600,
// // //                                   ),
// // //                                 ),
// // //                               ),
// // //                             ],
// // //                           ),
// // //                         ),
// // //                       ),
// // //                     ),
// // //                   ),
// // //                 ],
// // //
// // //                 const SizedBox(height: 20),
// // //
// // //                 SizedBox(
// // //                   width: double.infinity,
// // //                   height: 52,
// // //
// // //                   child: ElevatedButton.icon(
// // //                     onPressed:
// // //                     selectedAuditType == 'Process Audit' &&
// // //                         selected.isEmpty
// // //                         ? null
// // //                         : () async {
// // //                       final List<String>? sections =
// // //                       selectedAuditType ==
// // //                           'Process Audit'
// // //                           ? selected.toList()
// // //                           : null;
// // //
// // //                       try {
// // //                         await AuditService
// // //                             .updateCurrentSection(
// // //                           auditId:
// // //                           widget.audit.auditId,
// // //                           section:
// // //                           selectedAuditType ==
// // //                               'Process Audit'
// // //                               ? sections!.first
// // //                               : selectedAuditType,
// // //                         );
// // //
// // //                         if (!context.mounted) {
// // //                           return;
// // //                         }
// // //
// // //                         Navigator.pushReplacement(
// // //                           context,
// // //                           MaterialPageRoute(
// // //                             builder: (_) =>
// // //                                 AuditChecklistScreen(
// // //                                   audit: widget.audit,
// // //                                   sections: sections,
// // //                                 ),
// // //                           ),
// // //                         );
// // //                       } catch (e) {
// // //                         if (!context.mounted) {
// // //                           return;
// // //                         }
// // //
// // //                         ScaffoldMessenger.of(
// // //                           context,
// // //                         ).showSnackBar(
// // //                           SnackBar(
// // //                             content: Text(
// // //                               'Unable to continue: $e',
// // //                             ),
// // //                           ),
// // //                         );
// // //                       }
// // //                     },
// // //
// // //                     icon: const Icon(
// // //                       Icons.arrow_forward,
// // //                     ),
// // //
// // //                     label: const Text(
// // //                       'Continue',
// // //                     ),
// // //                   ),
// // //                 ),
// // //               ],
// // //             ),
// // //           ),
// // //         ),
// // //       ),
// // //     );
// // //   }
// // // }
// //
// //
// //
// // //
// //
// // import 'package:flutter/material.dart';
// //
// // import '../../models/audit/audit.dart';
// // import '../../services/audit/audit_checklist_data.dart';
// // import '../../services/audit/audit_service.dart';
// // import 'audit_checklist_screen.dart';
// // import 'audit_mil_screen.dart';
// //
// // class AuditProcessSelectionScreen extends StatefulWidget {
// //   final Audit audit;
// //
// //   const AuditProcessSelectionScreen({
// //     super.key,
// //     required this.audit,
// //   });
// //
// //   @override
// //   State<AuditProcessSelectionScreen> createState() =>
// //       _AuditProcessSelectionScreenState();
// // }
// //
// // class _AuditProcessSelectionScreenState
// //     extends State<AuditProcessSelectionScreen> {
// //   bool loading = true;
// //   bool completing = false;
// //
// //   Map<String, bool> categoryStatus = {};
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _loadCategoryStatus();
// //   }
// //
// //   Future<void> _loadCategoryStatus() async {
// //     try {
// //       final status =
// //       await AuditService.getCategoryStatus(widget.audit);
// //
// //       if (!mounted) return;
// //
// //       setState(() {
// //         categoryStatus = status;
// //         loading = false;
// //       });
// //     } catch (e) {
// //       if (!mounted) return;
// //
// //       setState(() {
// //         loading = false;
// //       });
// //
// //       _showMessage(
// //         'Unable to load audit categories.\n$e',
// //       );
// //     }
// //   }
// //
// //   List<String> get categories {
// //     switch (widget.audit.auditType) {
// //       case 'Process Audit':
// //         return AuditChecklistData.processSections;
// //
// //       case 'System Audit':
// //         return AuditChecklistData.systemProcesses;
// //
// //       case 'Product Audit':
// //         return const ['Product Audit'];
// //
// //       default:
// //         return [];
// //     }
// //   }
// //
// //   Future<void> _openCategory(String category) async {
// //     await Navigator.push(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) => AuditChecklistScreen(
// //           audit: widget.audit,
// //           section: category,
// //         ),
// //       ),
// //     );
// //
// //     if (!mounted) return;
// //
// //     setState(() {
// //       loading = true;
// //     });
// //
// //     await _loadCategoryStatus();
// //   }
// //
// //   Future<void> _openMilIfComplete() async {
// //     if (completing) return;
// //
// //     final status =
// //     await AuditService.getCategoryStatus(widget.audit);
// //
// //     final allCompleted =
// //         status.isNotEmpty &&
// //             status.values.every((completed) => completed);
// //
// //     if (!allCompleted) {
// //       final pending =
// //       status.entries
// //           .where((entry) => !entry.value)
// //           .map((entry) => entry.key)
// //           .toList();
// //
// //       _showMessage(
// //         'Complete all audit categories first.\n'
// //             'Pending: ${pending.join(', ')}',
// //       );
// //
// //       return;
// //     }
// //
// //     setState(() {
// //       completing = true;
// //     });
// //
// //     try {
// //       Navigator.push(
// //         context,
// //         MaterialPageRoute(
// //           builder: (_) => AuditMilScreen(
// //             audit: widget.audit,
// //           ),
// //         ),
// //       );
// //     } finally {
// //       if (mounted) {
// //         setState(() {
// //           completing = false;
// //         });
// //       }
// //     }
// //   }
// //
// //   IconData _iconFor(String category) {
// //     switch (widget.audit.auditType) {
// //       case 'Process Audit':
// //         switch (category) {
// //           case 'Incoming Raw Material / Raw material warehouse':
// //             return Icons.inventory_2_outlined;
// //
// //           case 'Manufacturing':
// //             return Icons.precision_manufacturing_outlined;
// //
// //           case '100% Cosmetic Inspection':
// //             return Icons.search_outlined;
// //
// //           case 'FQC + OQC':
// //             return Icons.verified_outlined;
// //
// //           default:
// //             return Icons.fact_check_outlined;
// //         }
// //
// //       case 'System Audit':
// //         return Icons.account_tree_outlined;
// //
// //       case 'Product Audit':
// //         return Icons.inventory_2_outlined;
// //
// //       default:
// //         return Icons.fact_check_outlined;
// //     }
// //   }
// //
// //   void _showMessage(String message) {
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       SnackBar(
// //         content: Text(message),
// //         behavior: SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     final completedCount =
// //         categoryStatus.values
// //             .where((value) => value)
// //             .length;
// //
// //     final totalCount = categories.length;
// //
// //     final allCompleted =
// //         totalCount > 0 &&
// //             completedCount == totalCount;
// //
// //     return Scaffold(
// //       backgroundColor: const Color(0xFFF5F7FB),
// //
// //       appBar: AppBar(
// //         title: const Text(
// //           'Audit Categories',
// //           style: TextStyle(
// //             fontWeight: FontWeight.w700,
// //           ),
// //         ),
// //         backgroundColor: Colors.white,
// //         foregroundColor: const Color(0xFF172033),
// //         elevation: 0,
// //       ),
// //
// //       body: loading
// //           ? const Center(
// //         child: CircularProgressIndicator(),
// //       )
// //           : Center(
// //         child: ConstrainedBox(
// //           constraints: const BoxConstraints(
// //             maxWidth: 1050,
// //           ),
// //           child: Padding(
// //             padding: const EdgeInsets.all(30),
// //             child: Column(
// //               crossAxisAlignment:
// //               CrossAxisAlignment.start,
// //               children: [
// //                 _header(
// //                   completedCount,
// //                   totalCount,
// //                 ),
// //
// //                 const SizedBox(height: 25),
// //
// //                 Expanded(
// //                   child: ListView.separated(
// //                     itemCount: categories.length,
// //                     separatorBuilder: (_, __) =>
// //                     const SizedBox(height: 12),
// //                     itemBuilder:
// //                         (context, index) {
// //                       final category =
// //                       categories[index];
// //
// //                       final completed =
// //                           categoryStatus[
// //                           category] ??
// //                               false;
// //
// //                       return _categoryCard(
// //                         category: category,
// //                         completed: completed,
// //                       );
// //                     },
// //                   ),
// //                 ),
// //
// //                 const SizedBox(height: 20),
// //
// //                 SizedBox(
// //                   width: double.infinity,
// //                   height: 52,
// //                   child: ElevatedButton.icon(
// //                     onPressed:
// //                     allCompleted
// //                         ? _openMilIfComplete
// //                         : null,
// //                     icon: const Icon(
// //                       Icons.assignment_turned_in_outlined,
// //                     ),
// //                     label: Text(
// //                       allCompleted
// //                           ? 'Open MIL Report'
// //                           : 'Complete All Categories to Continue',
// //                     ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _header(
// //       int completed,
// //       int total,
// //       ) {
// //     final progress =
// //     total == 0 ? 0.0 : completed / total;
// //
// //     return Card(
// //       elevation: 0,
// //       shape: RoundedRectangleBorder(
// //         borderRadius: BorderRadius.circular(18),
// //         side: const BorderSide(
// //           color: Color(0xFFE4E8F0),
// //         ),
// //       ),
// //       child: Padding(
// //         padding: const EdgeInsets.all(24),
// //         child: Column(
// //           crossAxisAlignment:
// //           CrossAxisAlignment.start,
// //           children: [
// //             Text(
// //               widget.audit.auditType,
// //               style: const TextStyle(
// //                 fontSize: 24,
// //                 fontWeight: FontWeight.w800,
// //               ),
// //             ),
// //
// //             const SizedBox(height: 5),
// //
// //             const Text(
// //               'Complete every category before the audit can be closed.',
// //               style: TextStyle(
// //                 color: Color(0xFF6B7280),
// //               ),
// //             ),
// //
// //             const SizedBox(height: 20),
// //
// //             Row(
// //               children: [
// //                 Expanded(
// //                   child: LinearProgressIndicator(
// //                     value: progress,
// //                     minHeight: 8,
// //                     borderRadius:
// //                     BorderRadius.circular(10),
// //                   ),
// //                 ),
// //
// //                 const SizedBox(width: 15),
// //
// //                 Text(
// //                   '$completed / $total',
// //                   style: const TextStyle(
// //                     fontWeight: FontWeight.w800,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _categoryCard({
// //     required String category,
// //     required bool completed,
// //   }) {
// //     return Card(
// //       elevation: 0,
// //       shape: RoundedRectangleBorder(
// //         borderRadius: BorderRadius.circular(16),
// //         side: BorderSide(
// //           color: completed
// //               ? Colors.green.shade200
// //               : const Color(0xFFE4E8F0),
// //         ),
// //       ),
// //       child: Padding(
// //         padding: const EdgeInsets.all(18),
// //         child: Row(
// //           children: [
// //             Container(
// //               width: 48,
// //               height: 48,
// //               decoration: BoxDecoration(
// //                 color: completed
// //                     ? Colors.green.shade50
// //                     : const Color(0xFFEFF3FF),
// //                 borderRadius:
// //                 BorderRadius.circular(12),
// //               ),
// //               child: Icon(
// //                 completed
// //                     ? Icons.check_circle_outline
// //                     : _iconFor(category),
// //                 color: completed
// //                     ? Colors.green.shade700
// //                     : const Color(0xFF3155D9),
// //               ),
// //             ),
// //
// //             const SizedBox(width: 16),
// //
// //             Expanded(
// //               child: Column(
// //                 crossAxisAlignment:
// //                 CrossAxisAlignment.start,
// //                 children: [
// //                   Text(
// //                     category,
// //                     style: const TextStyle(
// //                       fontSize: 16,
// //                       fontWeight: FontWeight.w700,
// //                     ),
// //                   ),
// //
// //                   const SizedBox(height: 5),
// //
// //                   Text(
// //                     completed
// //                         ? 'Completed'
// //                         : 'Pending',
// //                     style: TextStyle(
// //                       color: completed
// //                           ? Colors.green.shade700
// //                           : Colors.orange.shade700,
// //                       fontWeight: FontWeight.w600,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //
// //             OutlinedButton.icon(
// //               onPressed: () => _openCategory(category),
// //               icon: Icon(
// //                 completed
// //                     ? Icons.visibility_outlined
// //                     : Icons.arrow_forward,
// //                 size: 18,
// //               ),
// //               label: Text(
// //                 completed ? 'View / Edit' : 'Enter',
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
//
// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../services/audit/audit_checklist_data.dart';
// import '../../services/audit/audit_service.dart';
// import 'audit_checklist_screen.dart';
// import 'audit_mil_screen.dart';
//
// class AuditProcessSelectionScreen
//     extends StatefulWidget {
//   final Audit audit;
//
//   const AuditProcessSelectionScreen({
//     super.key,
//     required this.audit,
//   });
//
//   @override
//   State<AuditProcessSelectionScreen>
//   createState() =>
//       _AuditProcessSelectionScreenState();
// }
//
// class _AuditProcessSelectionScreenState
//     extends State<AuditProcessSelectionScreen> {
//   bool loading = true;
//   bool openingMil = false;
//
//   Map<String, bool> categoryStatus = {};
//
//   @override
//   void initState() {
//     super.initState();
//     _loadCategoryStatus();
//   }
//
//   List<String> get categories {
//     switch (widget.audit.auditType) {
//       case 'Process Audit':
//         return AuditChecklistData
//             .processSections;
//
//       case 'System Audit':
//         return AuditChecklistData
//             .systemProcesses;
//
//       case 'Product Audit':
//         return const [
//           'Product Audit',
//         ];
//
//       default:
//         return [];
//     }
//   }
//
//   Future<void> _loadCategoryStatus() async {
//     try {
//       final status =
//       await AuditService.getCategoryStatus(
//         widget.audit,
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       setState(() {
//         categoryStatus = status;
//         loading = false;
//       });
//     } catch (e) {
//       if (!mounted) {
//         return;
//       }
//
//       setState(() {
//         loading = false;
//       });
//
//       _showMessage(
//         'Unable to load audit categories.\n$e',
//       );
//     }
//   }
//
//   Future<void> _openCategory(
//       String category) async {
//     await Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) =>
//             AuditChecklistScreen(
//               audit: widget.audit,
//               section: category,
//             ),
//       ),
//     );
//
//     if (!mounted) {
//       return;
//     }
//
//     setState(() {
//       loading = true;
//     });
//
//     await _loadCategoryStatus();
//   }
//
//   Future<void> _completeCategoriesAndOpenMil()
//   async {
//     if (openingMil) {
//       return;
//     }
//
//     setState(() {
//       openingMil = true;
//     });
//
//     try {
//       final latestStatus =
//       await AuditService.getCategoryStatus(
//         widget.audit,
//       );
//
//       final allCompleted =
//           categories.isNotEmpty &&
//               categories.every(
//                     (category) =>
//                 latestStatus[
//                 category] ==
//                     true,
//               );
//
//       if (!allCompleted) {
//         final pending =
//         categories
//             .where(
//               (category) =>
//           latestStatus[
//           category] !=
//               true,
//         )
//             .toList();
//
//         _showMessage(
//           'Complete all categories first.\n'
//               'Pending: ${pending.join(', ')}',
//         );
//
//         return;
//       }
//
//       // Mark audit completed ONLY after every
//       // category has been completed.
//       await AuditService.completeAudit(
//         widget.audit.auditId,
//       );
//
//       final completedAudit =
//       await AuditService.getAudit(
//         widget.audit.auditId,
//       );
//
//       if (completedAudit == null) {
//         throw Exception(
//           'Unable to reload completed audit.',
//         );
//       }
//
//       if (!mounted) {
//         return;
//       }
//
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               AuditMilScreen(
//                 audit: completedAudit,
//               ),
//         ),
//       );
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           'Unable to open MIL report.\n$e',
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           openingMil = false;
//         });
//       }
//     }
//   }
//
//   IconData _iconFor(
//       String category) {
//     switch (widget.audit.auditType) {
//       case 'Process Audit':
//         switch (category) {
//           case 'Incoming Raw Material / Raw material warehouse':
//             return Icons.inventory_2_outlined;
//
//           case 'Manufacturing':
//             return Icons
//                 .precision_manufacturing_outlined;
//
//           case '100% Cosmetic Inspection':
//             return Icons.search_outlined;
//
//           case 'FQC + OQC':
//             return Icons.verified_outlined;
//
//           default:
//             return Icons.fact_check_outlined;
//         }
//
//       case 'System Audit':
//         return Icons.account_tree_outlined;
//
//       case 'Product Audit':
//         return Icons.inventory_2_outlined;
//
//       default:
//         return Icons.fact_check_outlined;
//     }
//   }
//
//   void _showMessage(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior:
//         SnackBarBehavior.floating,
//       ),
//     );
//   }
//
//   @override
//   Widget build(
//       BuildContext context) {
//     final completedCount =
//         categoryStatus.values
//             .where(
//               (value) => value,
//         )
//             .length;
//
//     final totalCount =
//         categories.length;
//
//     final allCompleted =
//         totalCount > 0 &&
//             completedCount ==
//                 totalCount;
//
//     final progress =
//     totalCount == 0
//         ? 0.0
//         : completedCount /
//         totalCount;
//
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: const Text(
//           'Audit Categories',
//           style: TextStyle(
//             fontWeight:
//             FontWeight.w700,
//           ),
//         ),
//         backgroundColor:
//         Colors.white,
//         foregroundColor:
//         const Color(0xFF172033),
//         elevation: 0,
//       ),
//
//       body: loading
//           ? const Center(
//         child:
//         CircularProgressIndicator(),
//       )
//           : Center(
//         child: ConstrainedBox(
//           constraints:
//           const BoxConstraints(
//             maxWidth: 1050,
//           ),
//
//           child: Padding(
//             padding:
//             const EdgeInsets.all(30),
//
//             child: Column(
//               crossAxisAlignment:
//               CrossAxisAlignment.start,
//
//               children: [
//                 _buildHeader(
//                   completedCount,
//                   totalCount,
//                   progress,
//                 ),
//
//                 const SizedBox(
//                   height: 22,
//                 ),
//
//                 Expanded(
//                   child:
//                   categories.isEmpty
//                       ? _emptyState()
//                       : ListView
//                       .separated(
//                     itemCount:
//                     categories.length,
//                     separatorBuilder:
//                         (_, __) =>
//                     const SizedBox(
//                       height: 12,
//                     ),
//                     itemBuilder:
//                         (context, index) {
//                       final category =
//                       categories[
//                       index];
//
//                       final completed =
//                           categoryStatus[
//                           category] ??
//                               false;
//
//                       return _categoryCard(
//                         category:
//                         category,
//                         completed:
//                         completed,
//                       );
//                     },
//                   ),
//                 ),
//
//                 const SizedBox(
//                   height: 18,
//                 ),
//
//                 SizedBox(
//                   width:
//                   double.infinity,
//                   height: 52,
//
//                   child:
//                   ElevatedButton.icon(
//                     onPressed:
//                     allCompleted &&
//                         !openingMil
//                         ? _completeCategoriesAndOpenMil
//                         : null,
//
//                     icon:
//                     openingMil
//                         ? const SizedBox(
//                       width: 20,
//                       height: 20,
//                       child:
//                       CircularProgressIndicator(
//                         strokeWidth: 2,
//                       ),
//                     )
//                         : Icon(
//                       allCompleted
//                           ? Icons
//                           .assignment_turned_in_outlined
//                           : Icons
//                           .lock_outline,
//                     ),
//
//                     label: Text(
//                       openingMil
//                           ? 'Opening MIL...'
//                           : allCompleted
//                           ? 'Open MIL Report'
//                           : 'Complete All Categories to Continue',
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildHeader(
//       int completed,
//       int total,
//       double progress) {
//     return Card(
//       elevation: 0,
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(18),
//         side: const BorderSide(
//           color: Color(0xFFE4E8F0),
//         ),
//       ),
//
//       child: Padding(
//         padding:
//         const EdgeInsets.all(24),
//
//         child: Column(
//           crossAxisAlignment:
//           CrossAxisAlignment.start,
//
//           children: [
//             Row(
//               children: [
//                 Container(
//                   width: 52,
//                   height: 52,
//                   decoration:
//                   BoxDecoration(
//                     color:
//                     const Color(
//                       0xFFEFF3FF,
//                     ),
//                     borderRadius:
//                     BorderRadius.circular(
//                       14,
//                     ),
//                   ),
//                   child: Icon(
//                     widget.audit.auditType ==
//                         'Process Audit'
//                         ? Icons.factory_outlined
//                         : widget.audit.auditType ==
//                         'System Audit'
//                         ? Icons
//                         .account_tree_outlined
//                         : Icons
//                         .inventory_2_outlined,
//                     color:
//                     const Color(
//                       0xFF3155D9,
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 15,
//                 ),
//
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment:
//                     CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         widget.audit.auditType,
//                         style:
//                         const TextStyle(
//                           fontSize: 24,
//                           fontWeight:
//                           FontWeight.w800,
//                         ),
//                       ),
//                       const SizedBox(
//                         height: 4,
//                       ),
//                       const Text(
//                         'Complete every category before opening the MIL report.',
//                         style:
//                         TextStyle(
//                           color:
//                           Color(0xFF6B7280),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 22,
//             ),
//
//             Row(
//               children: [
//                 Expanded(
//                   child:
//                   LinearProgressIndicator(
//                     value: progress,
//                     minHeight: 8,
//                     borderRadius:
//                     BorderRadius.circular(
//                       10,
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 15,
//                 ),
//
//                 Text(
//                   '$completed / $total completed',
//                   style:
//                   const TextStyle(
//                     fontWeight:
//                     FontWeight.w800,
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _categoryCard({
//     required String category,
//     required bool completed,
//   }) {
//     return Card(
//       elevation: 0,
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(16),
//         side: BorderSide(
//           color: completed
//               ? Colors.green.shade200
//               : const Color(
//             0xFFE4E8F0,
//           ),
//         ),
//       ),
//
//       child: Padding(
//         padding:
//         const EdgeInsets.all(18),
//
//         child: Row(
//           children: [
//             Container(
//               width: 48,
//               height: 48,
//
//               decoration:
//               BoxDecoration(
//                 color: completed
//                     ? Colors
//                     .green.shade50
//                     : const Color(
//                   0xFFEFF3FF,
//                 ),
//                 borderRadius:
//                 BorderRadius.circular(
//                   12,
//                 ),
//               ),
//
//               child: Icon(
//                 completed
//                     ? Icons
//                     .check_circle_outline
//                     : _iconFor(
//                   category,
//                 ),
//                 color: completed
//                     ? Colors
//                     .green.shade700
//                     : const Color(
//                   0xFF3155D9,
//                 ),
//               ),
//             ),
//
//             const SizedBox(
//               width: 16,
//             ),
//
//             Expanded(
//               child: Column(
//                 crossAxisAlignment:
//                 CrossAxisAlignment.start,
//
//                 children: [
//                   Text(
//                     category,
//                     style:
//                     const TextStyle(
//                       fontSize: 16,
//                       fontWeight:
//                       FontWeight.w700,
//                     ),
//                   ),
//
//                   const SizedBox(
//                     height: 5,
//                   ),
//
//                   Row(
//                     children: [
//                       Icon(
//                         completed
//                             ? Icons
//                             .check_circle
//                             : Icons
//                             .pending_outlined,
//                         size: 17,
//                         color: completed
//                             ? Colors
//                             .green.shade700
//                             : Colors
//                             .orange.shade700,
//                       ),
//
//                       const SizedBox(
//                         width: 6,
//                       ),
//
//                       Text(
//                         completed
//                             ? 'Completed'
//                             : 'Pending',
//                         style:
//                         TextStyle(
//                           color: completed
//                               ? Colors
//                               .green.shade700
//                               : Colors
//                               .orange.shade700,
//                           fontWeight:
//                           FontWeight.w600,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//
//             OutlinedButton.icon(
//               onPressed: () =>
//                   _openCategory(
//                     category,
//                   ),
//
//               icon: Icon(
//                 completed
//                     ? Icons
//                     .edit_outlined
//                     : Icons
//                     .arrow_forward,
//                 size: 18,
//               ),
//
//               label: Text(
//                 completed
//                     ? 'View / Edit'
//                     : 'Enter',
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _emptyState() {
//     return const Center(
//       child: Text(
//         'No audit categories are configured for this audit type.',
//         style: TextStyle(
//           color:
//           Color(0xFF6B7280),
//         ),
//       ),
//     );
//   }
// }




import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/audit/audit.dart';
import '../../services/audit/audit_checklist_data.dart';
import '../../services/audit/audit_service.dart';
import 'audit_checklist_screen.dart';
import 'audit_mil_screen.dart';

class AuditProcessSelectionScreen
    extends StatefulWidget {
  final Audit audit;

  const AuditProcessSelectionScreen({
    super.key,
    required this.audit,
  });

  @override
  State<AuditProcessSelectionScreen>
  createState() =>
      _AuditProcessSelectionScreenState();
}

class _AuditProcessSelectionScreenState
    extends State<
        AuditProcessSelectionScreen> {
  bool loading = true;
  bool openingMil = false;

  Map<String, bool>
  categoryStatus = {};

  @override
  void initState() {
    super.initState();

    _loadCategoryStatus();
  }
  // ============================================================
  // CATEGORIES
  // ============================================================

  List<String> get categories {
    return AuditService
        .categoriesForAuditType(
      widget.audit.auditType,
    );
  }

  // ============================================================
  // LOAD STATUS
  // ============================================================

  Future<void>
  _loadCategoryStatus() async {
    try {
      final status =
      await AuditService
          .getCategoryStatus(
        widget.audit,
      );

      if (!mounted) {
        return;
      }

      setState(() {
        categoryStatus =
            status;
        loading = false;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }

      setState(() {
        loading = false;
      });

      _showMessage(
        'Unable to load audit categories.\n$e',
      );
    }
  }

  // ============================================================
  // OPEN CATEGORY
  // ============================================================

  Future<void> _openCategory(
      String category) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            AuditChecklistScreen(
              audit: widget.audit,
              section: category,
            ),
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      loading = true;
    });

    await _loadCategoryStatus();
  }
  // ============================================================
  // OPEN MIL
  // ============================================================

  Future<void>
  _openMilIfComplete() async {
    if (openingMil) {
      return;
    }

    final status =
    await AuditService
        .getCategoryStatus(
      widget.audit,
    );

    final allCompleted =
        categories.isNotEmpty &&
            categories.every(
                  (category) =>
              status[category] ==
                  true,
            );

    if (!allCompleted) {
      final pending =
      categories
          .where(
            (category) =>
        status[category] !=
            true,
      )
          .toList();

      _showMessage(
        'Complete all categories first.\n'
            'Pending: ${pending.join(', ')}',
      );

      return;
    }

    setState(() {
      openingMil = true;
    });

    try {
      // Stop timer and persist final audit
      // duration.
      await AuditService
          .completeAudit(
        widget.audit.auditId,
      );

      final completedAudit =
      await AuditService.getAudit(
        widget.audit.auditId,
      );

      if (completedAudit ==
          null) {
        throw Exception(
          'Unable to reload completed audit.',
        );
      }

      if (!mounted) {
        return;
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              AuditMilScreen(
                audit:
                completedAudit,
              ),
        ),
      );
    } catch (e) {
      if (mounted) {
        _showMessage(
          'Unable to open MIL report.\n$e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          openingMil = false;
        });
      }
    }
  }

  // ============================================================
  // ICON
  // ============================================================

  IconData _iconFor(
      String category) {
    switch (widget.audit.auditType) {
      case 'Process Audit':
        switch (category) {
          case 'Incoming Raw Material / Raw material warehouse':
            return Icons
                .inventory_2_outlined;

          case 'Manufacturing':
            return Icons
                .precision_manufacturing_outlined;

          case '100% Cosmetic Inspection':
            return Icons
                .search_outlined;

          case 'FQC + OQC':
            return Icons
                .verified_outlined;

          default:
            return Icons
                .fact_check_outlined;
        }

      case 'System Audit':
        return Icons
            .account_tree_outlined;

      case 'Product Audit':
        return Icons
            .inventory_2_outlined;

      default:
        return Icons
            .fact_check_outlined;
    }
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
      String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content:
        Text(message),
        behavior:
        SnackBarBehavior
            .floating,
      ),
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    super.dispose();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
      BuildContext context) {
    final completedCount =
        categoryStatus.values
            .where(
              (value) => value,
        )
            .length;

    final totalCount =
        categories.length;

    final allCompleted =
        totalCount > 0 &&
            completedCount ==
                totalCount;

    final progress =
    totalCount == 0
        ? 0.0
        : completedCount /
        totalCount;

    return Scaffold(
      backgroundColor:
        const Color(0xFFF5F7FB),

        appBar: AppBar(
          title: const Text(
            'Audit Categories',
            style:
            TextStyle(
              fontWeight:
              FontWeight.w700,
            ),
          ),

          backgroundColor:
          Colors.white,

          foregroundColor:
          const Color(
            0xFF172033,
          ),

          elevation: 0,
        ),

        body: loading
            ? const Center(
          child:
          CircularProgressIndicator(),
        )
            : Center(
          child:
          ConstrainedBox(
            constraints:
            const BoxConstraints(
              maxWidth: 1050,
            ),

            child:
            Padding(
              padding:
              const EdgeInsets
                  .all(30),

              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,

                children: [
                  _header(
                    completedCount,
                    totalCount,
                    progress,
                  ),

                  const SizedBox(
                    height: 22,
                  ),

                  Expanded(
                    child: categories
                        .isEmpty
                        ? _emptyState()
                        : ListView
                        .separated(
                      itemCount:
                      categories
                          .length,
                      separatorBuilder:
                          (_, __) =>
                      const SizedBox(
                        height: 12,
                      ),
                      itemBuilder:
                          (context,
                          index) {
                        final category =
                        categories[
                        index];

                        final completed =
                            categoryStatus[
                            category] ??
                                false;

                        return _categoryCard(
                          category:
                          category,
                          completed:
                          completed,
                        );
                      },
                    ),
                  ),

                  const SizedBox(
                    height: 18,
                  ),

                  SizedBox(
                    width:
                    double.infinity,
                    height: 52,

                    child:
                    ElevatedButton
                        .icon(
                      onPressed:
                      allCompleted &&
                          !openingMil
                          ? _openMilIfComplete
                          : null,

                      icon: openingMil
                          ? const SizedBox(
                        width: 20,
                        height: 20,
                        child:
                        CircularProgressIndicator(
                          strokeWidth:
                          2,
                        ),
                      )
                          : Icon(
                        allCompleted
                            ? Icons
                            .assignment_turned_in_outlined
                            : Icons
                            .lock_outline,
                      ),

                      label:
                      Text(
                        openingMil
                            ? 'Opening MIL...'
                            : allCompleted
                            ? 'Open MIL Report'
                            : 'Complete All Categories to Continue',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _header(
      int completed,
      int total,
      double progress) {
    return Card(
      elevation: 0,

      shape:
      RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(
          18,
        ),
        side:
        const BorderSide(
          color:
          Color(0xFFE4E8F0),
        ),
      ),

      child: Padding(
        padding:
        const EdgeInsets.all(
          24,
        ),

        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment
              .start,

          children: [
            Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration:
                  BoxDecoration(
                    color:
                    const Color(
                      0xFFEFF3FF,
                    ),
                    borderRadius:
                    BorderRadius
                        .circular(
                      14,
                    ),
                  ),
                  child: Icon(
                    widget.audit
                        .auditType ==
                        'Process Audit'
                        ? Icons
                        .factory_outlined
                        : widget.audit
                        .auditType ==
                        'System Audit'
                        ? Icons
                        .account_tree_outlined
                        : Icons
                        .inventory_2_outlined,
                    color:
                    const Color(
                      0xFF3155D9,
                    ),
                  ),
                ),

                const SizedBox(
                  width: 15,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                    children: [
                      Text(
                        widget.audit
                            .auditType,
                        style:
                        const TextStyle(
                          fontSize: 24,
                          fontWeight:
                          FontWeight
                              .w800,
                        ),
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      const Text(
                        'Complete every category before the audit can be closed.',
                        style:
                        TextStyle(
                          color:
                          Color(
                            0xFF6B7280,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 20,
            ),

            Row(
              children: [
                Expanded(
                  child:
                  LinearProgressIndicator(
                    value:
                    progress,
                    minHeight: 8,
                    borderRadius:
                    BorderRadius
                        .circular(
                      10,
                    ),
                  ),
                ),

                const SizedBox(
                  width: 15,
                ),

                Text(
                  '$completed / $total',
                  style:
                  const TextStyle(
                    fontWeight:
                    FontWeight
                        .w800,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CATEGORY CARD
  // ============================================================

  Widget _categoryCard({
    required String category,
    required bool completed,
  }) {
    return Card(
      elevation: 0,

      shape:
      RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(
          16,
        ),
        side:
        BorderSide(
          color: completed
              ? Colors.green
              .shade200
              : const Color(
            0xFFE4E8F0,
          ),
        ),
      ),

      child: Padding(
        padding:
        const EdgeInsets.all(
          18,
        ),

        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration:
              BoxDecoration(
                color: completed
                    ? Colors.green
                    .shade50
                    : const Color(
                  0xFFEFF3FF,
                ),
                borderRadius:
                BorderRadius
                    .circular(
                  12,
                ),
              ),
              child: Icon(
                completed
                    ? Icons
                    .check_circle_outline
                    : _iconFor(
                  category,
                ),
                color: completed
                    ? Colors.green
                    .shade700
                    : const Color(
                  0xFF3155D9,
                ),
              ),
            ),

            const SizedBox(
              width: 16,
            ),

            Expanded(
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,
                children: [
                  Text(
                    category,
                    style:
                    const TextStyle(
                      fontSize: 16,
                      fontWeight:
                      FontWeight.w700,
                    ),
                  ),

                  const SizedBox(
                    height: 5,
                  ),

                  Text(
                    completed
                        ? 'Completed'
                        : 'Pending',
                    style:
                    TextStyle(
                      color: completed
                          ? Colors.green
                          .shade700
                          : Colors.orange
                          .shade700,
                      fontWeight:
                      FontWeight
                          .w600,
                    ),
                  ),
                ],
              ),
            ),

            OutlinedButton.icon(
              onPressed:
                  () => _openCategory(
                category,
              ),

              icon: Icon(
                completed
                    ? Icons
                    .visibility_outlined
                    : Icons
                    .arrow_forward,
                size: 18,
              ),

              label: Text(
                completed
                    ? 'View / Edit'
                    : 'Enter',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState() {
    return const Center(
      child: Text(
        'No audit categories configured.',
        style: TextStyle(
          color:
          Color(0xFF6B7280),
        ),
      ),
    );
  }
}