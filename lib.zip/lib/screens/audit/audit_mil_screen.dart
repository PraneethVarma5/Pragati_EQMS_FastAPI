// // // import 'package:flutter/material.dart';
// // //
// // // import '../../models/audit/audit.dart';
// // // import '../../models/audit/audit_finding.dart';
// // // import '../../services/audit/audit_service.dart';
// // // import 'audit_summary_screen.dart';
// // //
// // // class AuditMilScreen extends StatefulWidget {
// // //   final Audit audit;
// // //
// // //   const AuditMilScreen({
// // //     super.key,
// // //     required this.audit,
// // //   });
// // //
// // //   @override
// // //   State<AuditMilScreen> createState() =>
// // //       _AuditMilScreenState();
// // // }
// // //
// // // class _AuditMilScreenState
// // //     extends State<AuditMilScreen> {
// // //   List<AuditFinding> findings = [];
// // //   bool loading = true;
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //     _loadFindings();
// // //   }
// // //
// // //   Future<void> _loadFindings() async {
// // //     try {
// // //       findings =
// // //       await AuditService.getFindings(
// // //         widget.audit.auditId,
// // //       );
// // //
// // //       // If findings do not exist yet, create
// // //       // them from checklist answers.
// // //       if (findings.isEmpty) {
// // //         final answers =
// // //         await AuditService.getAnswers(
// // //           widget.audit.auditId,
// // //         );
// // //
// // //         for (final row in answers) {
// // //           if (row['answer'] != 'No') {
// // //             continue;
// // //           }
// // //
// // //           final finding =
// // //           AuditFinding(
// // //             id: row['answer_id']
// // //                 ?.toString() ??
// // //                 DateTime.now()
// // //                     .microsecondsSinceEpoch
// // //                     .toString(),
// // //             auditId:
// // //             widget.audit.auditId,
// // //             section:
// // //             row['section']?.toString() ??
// // //                 '',
// // //             checklistItemId:
// // //             row['checklist_item_id']
// // //                 ?.toString() ??
// // //                 '',
// // //             questionNumber:
// // //             (row['question_number']
// // //             as num?)
// // //                 ?.toInt() ??
// // //                 0,
// // //             question:
// // //             row['question']?.toString() ??
// // //                 '',
// // //             answer: 'No',
// // //             description:
// // //             row['description']
// // //                 ?.toString() ??
// // //                 '',
// // //             category:
// // //             row['finding_category'] == null
// // //                 ? null
// // //                 : FindingCategoryExtension
// // //                 .fromString(
// // //               row['finding_category']
// // //                   .toString(),
// // //             ),
// // //           );
// // //
// // //           await AuditService.saveFinding(
// // //             finding,
// // //           );
// // //
// // //           findings.add(finding);
// // //         }
// // //       }
// // //
// // //       if (mounted) {
// // //         setState(() {
// // //           loading = false;
// // //         });
// // //       }
// // //     } catch (e) {
// // //       if (mounted) {
// // //         setState(() {
// // //           loading = false;
// // //         });
// // //       }
// // //     }
// // //   }
// // //
// // //   Future<void> _save() async {
// // //     for (final finding in findings) {
// // //       await AuditService.saveFinding(
// // //         finding,
// // //       );
// // //     }
// // //
// // //     if (!mounted) return;
// // //
// // //     ScaffoldMessenger.of(context)
// // //         .showSnackBar(
// // //       const SnackBar(
// // //         content: Text(
// // //           'MIL findings saved.',
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Future<void> _complete() async {
// // //     await _save();
// // //
// // //     final milNumber =
// // //     await AuditService
// // //         .generateMilNumber(
// // //       widget.audit.auditDate,
// // //     );
// // //
// // //     await AuditService.assignMilNumber(
// // //       widget.audit.auditId,
// // //       milNumber,
// // //     );
// // //
// // //     await AuditService.completeAudit(
// // //       widget.audit.auditId,
// // //     );
// // //
// // //     if (!mounted) return;
// // //
// // //     Navigator.pushReplacement(
// // //       context,
// // //       MaterialPageRoute(
// // //         builder: (_) =>
// // //             AuditSummaryScreen(
// // //               audit: widget.audit,
// // //               findings: findings,
// // //               milNumber: milNumber,
// // //             ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Scaffold(
// // //       backgroundColor:
// // //       const Color(0xFFF5F7FB),
// // //       appBar: AppBar(
// // //         title: const Text(
// // //           'MIL Report - Findings',
// // //         ),
// // //         backgroundColor: Colors.white,
// // //         foregroundColor:
// // //         const Color(0xFF172033),
// // //         elevation: 0,
// // //       ),
// // //       body: loading
// // //           ? const Center(
// // //         child:
// // //         CircularProgressIndicator(),
// // //       )
// // //           : findings.isEmpty
// // //           ? _noFindings()
// // //           : ListView.builder(
// // //         padding:
// // //         const EdgeInsets.all(25),
// // //         itemCount:
// // //         findings.length,
// // //         itemBuilder:
// // //             (context, index) {
// // //           return _findingCard(
// // //             findings[index],
// // //             index,
// // //           );
// // //         },
// // //       ),
// // //       bottomNavigationBar:
// // //       findings.isEmpty
// // //           ? null
// // //           : Padding(
// // //         padding:
// // //         const EdgeInsets.all(18),
// // //         child: Row(
// // //           children: [
// // //             OutlinedButton(
// // //               onPressed: _save,
// // //               child:
// // //               const Text(
// // //                 'Save Progress',
// // //               ),
// // //             ),
// // //             const Spacer(),
// // //             ElevatedButton.icon(
// // //               onPressed: _complete,
// // //               icon: const Icon(
// // //                 Icons.check,
// // //               ),
// // //               label: const Text(
// // //                 'Complete Audit',
// // //               ),
// // //             ),
// // //           ],
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _noFindings() {
// // //     return Center(
// // //       child: Column(
// // //         mainAxisAlignment:
// // //         MainAxisAlignment.center,
// // //         children: [
// // //           Icon(
// // //             Icons.check_circle,
// // //             size: 70,
// // //             color: Colors.green.shade600,
// // //           ),
// // //           const SizedBox(height: 15),
// // //           const Text(
// // //             'No findings',
// // //             style: TextStyle(
// // //               fontSize: 23,
// // //               fontWeight: FontWeight.w800,
// // //             ),
// // //           ),
// // //           const SizedBox(height: 8),
// // //           const Text(
// // //             'All checklist items were answered Yes.',
// // //           ),
// // //           const SizedBox(height: 25),
// // //           ElevatedButton(
// // //             onPressed: _complete,
// // //             child: const Text(
// // //               'Complete Audit',
// // //             ),
// // //           ),
// // //         ],
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _findingCard(
// // //       AuditFinding finding,
// // //       int index,
// // //       ) {
// // //     return Card(
// // //       margin:
// // //       const EdgeInsets.only(bottom: 18),
// // //       elevation: 0,
// // //       child: Padding(
// // //         padding:
// // //         const EdgeInsets.all(20),
// // //         child: Column(
// // //           crossAxisAlignment:
// // //           CrossAxisAlignment.start,
// // //           children: [
// // //             Row(
// // //               children: [
// // //                 Text(
// // //                   'Issue ${index + 1}',
// // //                   style:
// // //                   const TextStyle(
// // //                     fontSize: 18,
// // //                     fontWeight:
// // //                     FontWeight.w800,
// // //                   ),
// // //                 ),
// // //                 const Spacer(),
// // //                 _categoryChip(
// // //                   finding.category,
// // //                 ),
// // //               ],
// // //             ),
// // //             const SizedBox(height: 12),
// // //             Text(
// // //               finding.question,
// // //               style:
// // //               const TextStyle(
// // //                 fontWeight:
// // //                 FontWeight.w600,
// // //               ),
// // //             ),
// // //             const SizedBox(height: 15),
// // //             TextFormField(
// // //               initialValue:
// // //               finding.issue.isEmpty
// // //                   ? finding.description
// // //                   : finding.issue,
// // //               maxLines: 3,
// // //               onChanged: (value) {
// // //                 finding.issue = value;
// // //               },
// // //               decoration:
// // //               const InputDecoration(
// // //                 labelText: 'Issue',
// // //                 border:
// // //                 OutlineInputBorder(),
// // //               ),
// // //             ),
// // //             const SizedBox(height: 12),
// // //             TextFormField(
// // //               initialValue:
// // //               finding.rootCause,
// // //               maxLines: 2,
// // //               onChanged: (value) {
// // //                 finding.rootCause =
// // //                     value;
// // //               },
// // //               decoration:
// // //               const InputDecoration(
// // //                 labelText: 'Root Cause',
// // //                 border:
// // //                 OutlineInputBorder(),
// // //               ),
// // //             ),
// // //             const SizedBox(height: 12),
// // //             TextFormField(
// // //               initialValue:
// // //               finding.correctiveAction,
// // //               maxLines: 2,
// // //               onChanged: (value) {
// // //                 finding.correctiveAction =
// // //                     value;
// // //               },
// // //               decoration:
// // //               const InputDecoration(
// // //                 labelText:
// // //                 'Corrective Action',
// // //                 border:
// // //                 OutlineInputBorder(),
// // //               ),
// // //             ),
// // //             const SizedBox(height: 12),
// // //             Row(
// // //               children: [
// // //                 Expanded(
// // //                   child: TextFormField(
// // //                     initialValue:
// // //                     finding.driName,
// // //                     onChanged: (value) {
// // //                       finding.driName =
// // //                           value;
// // //                     },
// // //                     decoration:
// // //                     const InputDecoration(
// // //                       labelText:
// // //                       'DRI Name',
// // //                       border:
// // //                       OutlineInputBorder(),
// // //                     ),
// // //                   ),
// // //                 ),
// // //                 const SizedBox(width: 12),
// // //                 Expanded(
// // //                   child: TextFormField(
// // //                     initialValue:
// // //                     finding.mailId,
// // //                     onChanged: (value) {
// // //                       finding.mailId =
// // //                           value;
// // //                     },
// // //                     decoration:
// // //                     const InputDecoration(
// // //                       labelText:
// // //                       'Mail ID',
// // //                       border:
// // //                       OutlineInputBorder(),
// // //                     ),
// // //                   ),
// // //                 ),
// // //               ],
// // //             ),
// // //             const SizedBox(height: 12),
// // //             Row(
// // //               children: [
// // //                 Expanded(
// // //                   child: DropdownButtonFormField<
// // //                       FindingCategory>(
// // //                     value:
// // //                     finding.category,
// // //                     decoration:
// // //                     const InputDecoration(
// // //                       labelText:
// // //                       'Finding Category',
// // //                       border:
// // //                       OutlineInputBorder(),
// // //                     ),
// // //                     items: FindingCategory
// // //                         .values
// // //                         .map(
// // //                           (category) {
// // //                         return DropdownMenuItem(
// // //                           value:
// // //                           category,
// // //                           child:
// // //                           Text(
// // //                             category.value,
// // //                           ),
// // //                         );
// // //                       },
// // //                     ).toList(),
// // //                     onChanged:
// // //                         (value) {
// // //                       setState(() {
// // //                         finding.category =
// // //                             value;
// // //                       });
// // //                     },
// // //                   ),
// // //                 ),
// // //                 const SizedBox(width: 12),
// // //                 Expanded(
// // //                   child: DropdownButtonFormField<
// // //                       String>(
// // //                     value:
// // //                     finding.overallStatus,
// // //                     decoration:
// // //                     const InputDecoration(
// // //                       labelText:
// // //                       'Overall Status',
// // //                       border:
// // //                       OutlineInputBorder(),
// // //                     ),
// // //                     items: const [
// // //                       DropdownMenuItem(
// // //                         value: 'Open',
// // //                         child:
// // //                         Text('Open'),
// // //                       ),
// // //                       DropdownMenuItem(
// // //                         value: 'Closed',
// // //                         child:
// // //                         Text('Closed'),
// // //                       ),
// // //                       DropdownMenuItem(
// // //                         value: 'Under Investigation',
// // //                         child: Text(
// // //                           'Under Investigation',
// // //                         ),
// // //                       ),
// // //                       DropdownMenuItem(
// // //                         value: 'Pending Implementation',
// // //                         child: Text(
// // //                           'Pending Implementation',
// // //                         ),
// // //                       ),
// // //                     ],
// // //                     onChanged:
// // //                         (value) {
// // //                       if (value == null) {
// // //                         return;
// // //                       }
// // //
// // //                       setState(() {
// // //                         finding.overallStatus =
// // //                             value;
// // //                       });
// // //                     },
// // //                   ),
// // //                 ),
// // //               ],
// // //             ),
// // //             const SizedBox(height: 12),
// // //             OutlinedButton.icon(
// // //               onPressed: () async {
// // //                 final date =
// // //                 await showDatePicker(
// // //                   context: context,
// // //                   firstDate:
// // //                   DateTime.now(),
// // //                   lastDate:
// // //                   DateTime(2100),
// // //                   initialDate:
// // //                   finding.deadline ??
// // //                       DateTime.now(),
// // //                 );
// // //
// // //                 if (date != null) {
// // //                   setState(() {
// // //                     finding.deadline =
// // //                         date;
// // //                   });
// // //                 }
// // //               },
// // //               icon: const Icon(
// // //                 Icons.calendar_today,
// // //               ),
// // //               label: Text(
// // //                 finding.deadline == null
// // //                     ? 'Select Deadline'
// // //                     : 'Deadline: '
// // //                     '${finding.deadline!.day}/'
// // //                     '${finding.deadline!.month}/'
// // //                     '${finding.deadline!.year}',
// // //               ),
// // //             ),
// // //           ],
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _categoryChip(
// // //       FindingCategory? category,
// // //       ) {
// // //     if (category == null) {
// // //       return const Chip(
// // //         label: Text(
// // //           'Not classified',
// // //         ),
// // //       );
// // //     }
// // //
// // //     Color color;
// // //
// // //     switch (category) {
// // //       case FindingCategory.critical:
// // //         color = Colors.red;
// // //         break;
// // //       case FindingCategory.major:
// // //         color = Colors.orange;
// // //         break;
// // //       case FindingCategory.minor:
// // //         color = Colors.green;
// // //         break;
// // //     }
// // //
// // //     return Chip(
// // //       label: Text(
// // //         category.value,
// // //         style: const TextStyle(
// // //           color: Colors.white,
// // //           fontWeight: FontWeight.w700,
// // //         ),
// // //       ),
// // //       backgroundColor: color,
// // //     );
// // //   }
// // // }
// //
// // import 'package:flutter/material.dart';
// //
// // import '../../models/audit/audit.dart';
// // import '../../models/audit/audit_finding.dart';
// // import '../../services/audit/audit_service.dart';
// // import 'audit_summary_screen.dart';
// //
// // class AuditMilScreen extends StatefulWidget {
// //   final Audit audit;
// //
// //   const AuditMilScreen({
// //     super.key,
// //     required this.audit,
// //   });
// //
// //   @override
// //   State<AuditMilScreen> createState() =>
// //       _AuditMilScreenState();
// // }
// //
// // class _AuditMilScreenState
// //     extends State<AuditMilScreen> {
// //   List<AuditFinding> findings = [];
// //
// //   bool loading = true;
// //   bool saving = false;
// //   bool completing = false;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _loadFindings();
// //   }
// //
// //   Future<void> _loadFindings() async {
// //     try {
// //       findings =
// //       await AuditService.getFindings(
// //         widget.audit.auditId,
// //       );
// //
// //       final answers =
// //       await AuditService.getAnswers(
// //         widget.audit.auditId,
// //       );
// //
// //       final existingIds =
// //       findings
// //           .map(
// //             (e) => e.checklistItemId,
// //       )
// //           .toSet();
// //
// //       for (final row in answers) {
// //         if (row['answer'] != 'No') {
// //           continue;
// //         }
// //
// //         final checklistId =
// //         row['checklist_item_id']
// //             ?.toString();
// //
// //         if (checklistId == null ||
// //             existingIds.contains(
// //               checklistId,
// //             )) {
// //           continue;
// //         }
// //
// //         final finding =
// //         AuditFinding(
// //           id: row['answer_id']
// //               ?.toString() ??
// //               DateTime.now()
// //                   .microsecondsSinceEpoch
// //                   .toString(),
// //
// //           auditId:
// //           widget.audit.auditId,
// //
// //           section:
// //           row['section']
// //               ?.toString() ??
// //               '',
// //
// //           checklistItemId:
// //           checklistId,
// //
// //           questionNumber:
// //           (row['question_number']
// //           as num?)
// //               ?.toInt() ??
// //               0,
// //
// //           question:
// //           row['question']
// //               ?.toString() ??
// //               '',
// //
// //           answer: 'No',
// //
// //           description:
// //           row['description']
// //               ?.toString() ??
// //               '',
// //
// //           category:
// //           row['finding_category'] ==
// //               null
// //               ? null
// //               : FindingCategoryExtension
// //               .fromString(
// //             row['finding_category']
// //                 .toString(),
// //           ),
// //         );
// //
// //         await AuditService.saveFinding(
// //           finding,
// //         );
// //
// //         findings.add(finding);
// //         existingIds.add(checklistId);
// //       }
// //
// //       if (mounted) {
// //         setState(() {
// //           loading = false;
// //         });
// //       }
// //     } catch (e) {
// //       if (mounted) {
// //         setState(() {
// //           loading = false;
// //         });
// //
// //         _showMessage(
// //           'Unable to load MIL findings.\n$e',
// //         );
// //       }
// //     }
// //   }
// //
// //   Future<void> _save() async {
// //     if (saving) return;
// //
// //     setState(() {
// //       saving = true;
// //     });
// //
// //     try {
// //       for (final finding in findings) {
// //         if (finding.category == null) {
// //           throw Exception(
// //             'Every finding must have a finding category.',
// //           );
// //         }
// //
// //         if (finding.issue.trim().isEmpty &&
// //             finding.description
// //                 .trim()
// //                 .isEmpty) {
// //           throw Exception(
// //             'Every finding must have an issue description.',
// //           );
// //         }
// //
// //         await AuditService.saveFinding(
// //           finding,
// //         );
// //       }
// //
// //       if (mounted) {
// //         _showMessage(
// //           'MIL findings saved successfully.',
// //         );
// //       }
// //     } catch (e) {
// //       if (mounted) {
// //         _showMessage(
// //           e.toString()
// //               .replaceFirst(
// //             'Exception: ',
// //             '',
// //           ),
// //         );
// //       }
// //     } finally {
// //       if (mounted) {
// //         setState(() {
// //           saving = false;
// //         });
// //       }
// //     }
// //   }
// //
// //   Future<void> _complete() async {
// //     if (completing) return;
// //
// //     setState(() {
// //       completing = true;
// //     });
// //
// //     try {
// //       await _save();
// //
// //       if (!mounted) return;
// //
// //       final refreshedFindings =
// //       await AuditService.getFindings(
// //         widget.audit.auditId,
// //       );
// //
// //       final incomplete =
// //       refreshedFindings.any(
// //             (finding) =>
// //         finding.category == null ||
// //             (finding.issue.trim().isEmpty &&
// //                 finding.description
// //                     .trim()
// //                     .isEmpty),
// //       );
// //
// //       if (incomplete) {
// //         throw Exception(
// //           'Complete all MIL finding details before closing the audit.',
// //         );
// //       }
// //
// //       final existingAudit =
// //       await AuditService.getAudit(
// //         widget.audit.auditId,
// //       );
// //
// //       String milNumber =
// //           existingAudit?.milNumber ?? '';
// //
// //       if (milNumber.isEmpty) {
// //         milNumber =
// //         await AuditService
// //             .generateMilNumber(
// //           widget.audit.auditDate,
// //         );
// //
// //         await AuditService.assignMilNumber(
// //           widget.audit.auditId,
// //           milNumber,
// //         );
// //       }
// //
// //       await AuditService.completeAudit(
// //         widget.audit.auditId,
// //       );
// //
// //       final completedAudit =
// //       await AuditService.getAudit(
// //         widget.audit.auditId,
// //       );
// //
// //       if (completedAudit == null) {
// //         throw Exception(
// //           'Unable to reload the completed audit.',
// //         );
// //       }
// //
// //       if (!mounted) return;
// //
// //       Navigator.pushReplacement(
// //         context,
// //         MaterialPageRoute(
// //           builder: (_) =>
// //               AuditSummaryScreen(
// //                 audit: completedAudit,
// //                 findings:
// //                 refreshedFindings,
// //                 milNumber:
// //                 completedAudit
// //                     .milNumber ??
// //                     milNumber,
// //               ),
// //         ),
// //       );
// //     } catch (e) {
// //       if (mounted) {
// //         _showMessage(
// //           e.toString()
// //               .replaceFirst(
// //             'Exception: ',
// //             '',
// //           ),
// //         );
// //
// //         setState(() {
// //           completing = false;
// //         });
// //       }
// //     }
// //   }
// //
// //   void _showMessage(String message) {
// //     ScaffoldMessenger.of(context)
// //         .showSnackBar(
// //       SnackBar(
// //         content: Text(message),
// //         behavior:
// //         SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// //
// //   Color _categoryColor(
// //       FindingCategory? category) {
// //     switch (category) {
// //       case FindingCategory.critical:
// //         return Colors.red;
// //       case FindingCategory.major:
// //         return Colors.orange;
// //       case FindingCategory.minor:
// //         return Colors.green;
// //       case null:
// //         return Colors.grey;
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor:
// //       const Color(0xFFF5F7FB),
// //
// //       appBar: AppBar(
// //         title: const Text(
// //           'MIL Report',
// //           style: TextStyle(
// //             fontWeight:
// //             FontWeight.w700,
// //           ),
// //         ),
// //         backgroundColor: Colors.white,
// //         foregroundColor:
// //         const Color(0xFF172033),
// //         elevation: 0,
// //       ),
// //
// //       body: loading
// //           ? const Center(
// //         child:
// //         CircularProgressIndicator(),
// //       )
// //           : findings.isEmpty
// //           ? _noFindings()
// //           : ListView.builder(
// //         padding:
// //         const EdgeInsets.fromLTRB(
// //           28,
// //           25,
// //           28,
// //           110,
// //         ),
// //         itemCount:
// //         findings.length,
// //         itemBuilder:
// //             (context, index) {
// //           return _findingCard(
// //             findings[index],
// //             index,
// //           );
// //         },
// //       ),
// //
// //       bottomNavigationBar:
// //       !loading
// //           ? _bottomBar()
// //           : null,
// //     );
// //   }
// //
// //   Widget _noFindings() {
// //     return Center(
// //       child: Padding(
// //         padding:
// //         const EdgeInsets.all(30),
// //
// //         child: Column(
// //           mainAxisAlignment:
// //           MainAxisAlignment.center,
// //
// //           children: [
// //             Container(
// //               width: 80,
// //               height: 80,
// //               decoration:
// //               BoxDecoration(
// //                 color:
// //                 Colors.green.shade50,
// //                 shape:
// //                 BoxShape.circle,
// //               ),
// //               child: Icon(
// //                 Icons.check_circle_outline,
// //                 size: 48,
// //                 color:
// //                 Colors.green.shade600,
// //               ),
// //             ),
// //
// //             const SizedBox(
// //               height: 18,
// //             ),
// //
// //             const Text(
// //               'No Findings Recorded',
// //               style: TextStyle(
// //                 fontSize: 23,
// //                 fontWeight:
// //                 FontWeight.w800,
// //               ),
// //             ),
// //
// //             const SizedBox(
// //               height: 8,
// //             ),
// //
// //             const Text(
// //               'All checklist items were answered Yes.',
// //               textAlign:
// //               TextAlign.center,
// //               style: TextStyle(
// //                 color:
// //                 Color(0xFF6B7280),
// //               ),
// //             ),
// //
// //             const SizedBox(
// //               height: 25,
// //             ),
// //
// //             ElevatedButton.icon(
// //               onPressed:
// //               completing
// //                   ? null
// //                   : _complete,
// //               icon: const Icon(
// //                 Icons.check,
// //               ),
// //               label: const Text(
// //                 'Complete Audit',
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _findingCard(
// //       AuditFinding finding,
// //       int index,
// //       ) {
// //     return Card(
// //       margin:
// //       const EdgeInsets.only(
// //         bottom: 18,
// //       ),
// //       elevation: 0,
// //
// //       shape:
// //       RoundedRectangleBorder(
// //         borderRadius:
// //         BorderRadius.circular(
// //           16,
// //         ),
// //         side: const BorderSide(
// //           color: Color(0xFFE4E8F0),
// //         ),
// //       ),
// //
// //       child: Padding(
// //         padding:
// //         const EdgeInsets.all(22),
// //
// //         child: Column(
// //           crossAxisAlignment:
// //           CrossAxisAlignment.start,
// //
// //           children: [
// //             Row(
// //               children: [
// //                 Container(
// //                   width: 40,
// //                   height: 40,
// //                   alignment:
// //                   Alignment.center,
// //                   decoration:
// //                   BoxDecoration(
// //                     color:
// //                     const Color(
// //                       0xFFEFF3FF,
// //                     ),
// //                     borderRadius:
// //                     BorderRadius.circular(
// //                       10,
// //                     ),
// //                   ),
// //                   child: Text(
// //                     '${index + 1}',
// //                     style:
// //                     const TextStyle(
// //                       color:
// //                       Color(0xFF3155D9),
// //                       fontWeight:
// //                       FontWeight.w800,
// //                     ),
// //                   ),
// //                 ),
// //
// //                 const SizedBox(
// //                   width: 13,
// //                 ),
// //
// //                 Expanded(
// //                   child: Text(
// //                     'Finding ${index + 1}',
// //                     style:
// //                     const TextStyle(
// //                       fontSize: 18,
// //                       fontWeight:
// //                       FontWeight.w800,
// //                     ),
// //                   ),
// //                 ),
// //
// //                 if (finding.category !=
// //                     null)
// //                   Container(
// //                     padding:
// //                     const EdgeInsets
// //                         .symmetric(
// //                       horizontal: 10,
// //                       vertical: 6,
// //                     ),
// //                     decoration:
// //                     BoxDecoration(
// //                       color:
// //                       _categoryColor(
// //                         finding.category,
// //                       ).withOpacity(.10),
// //                       borderRadius:
// //                       BorderRadius.circular(
// //                         20,
// //                       ),
// //                     ),
// //                     child: Text(
// //                       finding.category!
// //                           .value,
// //                       style: TextStyle(
// //                         color:
// //                         _categoryColor(
// //                           finding.category,
// //                         ),
// //                         fontWeight:
// //                         FontWeight.w700,
// //                       ),
// //                     ),
// //                   ),
// //               ],
// //             ),
// //
// //             const SizedBox(
// //               height: 18,
// //             ),
// //
// //             Text(
// //               finding.question,
// //               style:
// //               const TextStyle(
// //                 fontWeight:
// //                 FontWeight.w600,
// //                 height: 1.4,
// //               ),
// //             ),
// //
// //             const SizedBox(
// //               height: 16,
// //             ),
// //
// //             TextFormField(
// //               initialValue:
// //               finding.issue.isEmpty
// //                   ? finding.description
// //                   : finding.issue,
// //
// //               maxLines: 4,
// //
// //               onChanged: (value) {
// //                 finding.issue = value;
// //               },
// //
// //               decoration:
// //               const InputDecoration(
// //                 labelText:
// //                 'Issue / Finding',
// //                 border:
// //                 OutlineInputBorder(),
// //                 alignLabelWithHint: true,
// //               ),
// //             ),
// //
// //             const SizedBox(
// //               height: 14,
// //             ),
// //
// //             DropdownButtonFormField<
// //                 FindingCategory>(
// //               value:
// //               finding.category,
// //
// //               decoration:
// //               const InputDecoration(
// //                 labelText:
// //                 'Finding Category',
// //                 border:
// //                 OutlineInputBorder(),
// //               ),
// //
// //               items: FindingCategory
// //                   .values
// //                   .map(
// //                     (category) {
// //                   return DropdownMenuItem<
// //                       FindingCategory>(
// //                     value: category,
// //                     child: Row(
// //                       children: [
// //                         Container(
// //                           width: 11,
// //                           height: 11,
// //                           decoration:
// //                           BoxDecoration(
// //                             color:
// //                             _categoryColor(
// //                               category,
// //                             ),
// //                             shape:
// //                             BoxShape
// //                                 .circle,
// //                           ),
// //                         ),
// //                         const SizedBox(
// //                           width: 10,
// //                         ),
// //                         Text(
// //                           category.value,
// //                         ),
// //                       ],
// //                     ),
// //                   );
// //                 },
// //               ).toList(),
// //
// //               onChanged: completing
// //                   ? null
// //                   : (value) {
// //                 if (value ==
// //                     null) {
// //                   return;
// //                 }
// //
// //                 setState(() {
// //                   finding.category =
// //                       value;
// //                 });
// //               },
// //             ),
// //
// //             const SizedBox(
// //               height: 14,
// //             ),
// //
// //             Row(
// //               children: [
// //                 Expanded(
// //                   child:
// //                   TextFormField(
// //                     initialValue:
// //                     finding.rootCause,
// //                     maxLines: 2,
// //                     onChanged:
// //                         (value) {
// //                       finding.rootCause =
// //                           value;
// //                     },
// //                     decoration:
// //                     const InputDecoration(
// //                       labelText:
// //                       'Root Cause',
// //                       border:
// //                       OutlineInputBorder(),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 const SizedBox(
// //                   width: 12,
// //                 ),
// //
// //                 Expanded(
// //                   child:
// //                   TextFormField(
// //                     initialValue:
// //                     finding.correctiveAction,
// //                     maxLines: 2,
// //                     onChanged:
// //                         (value) {
// //                       finding.correctiveAction =
// //                           value;
// //                     },
// //                     decoration:
// //                     const InputDecoration(
// //                       labelText:
// //                       'Corrective Action',
// //                       border:
// //                       OutlineInputBorder(),
// //                     ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             const SizedBox(
// //               height: 14,
// //             ),
// //
// //             Row(
// //               children: [
// //                 Expanded(
// //                   child:
// //                   TextFormField(
// //                     initialValue:
// //                     finding.driName,
// //                     onChanged:
// //                         (value) {
// //                       finding.driName =
// //                           value;
// //                     },
// //                     decoration:
// //                     const InputDecoration(
// //                       labelText:
// //                       'DRI Name',
// //                       border:
// //                       OutlineInputBorder(),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 const SizedBox(
// //                   width: 12,
// //                 ),
// //
// //                 Expanded(
// //                   child:
// //                   TextFormField(
// //                     initialValue:
// //                     finding.mailId,
// //                     onChanged:
// //                         (value) {
// //                       finding.mailId =
// //                           value;
// //                     },
// //                     decoration:
// //                     const InputDecoration(
// //                       labelText:
// //                       'Mail ID',
// //                       border:
// //                       OutlineInputBorder(),
// //                     ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             const SizedBox(
// //               height: 14,
// //             ),
// //
// //             TextFormField(
// //               initialValue:
// //               finding.overallStatus,
// //
// //               onChanged: (value) {
// //                 finding.overallStatus =
// //                     value;
// //               },
// //
// //               decoration:
// //               const InputDecoration(
// //                 labelText:
// //                 'Overall Status',
// //                 border:
// //                 OutlineInputBorder(),
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _bottomBar() {
// //     return Container(
// //       padding:
// //       const EdgeInsets.all(16),
// //
// //       decoration:
// //       const BoxDecoration(
// //         color: Colors.white,
// //         border: Border(
// //           top: BorderSide(
// //             color: Color(0xFFE4E8F0),
// //           ),
// //         ),
// //       ),
// //
// //       child: Row(
// //         children: [
// //           OutlinedButton.icon(
// //             onPressed:
// //             saving || completing
// //                 ? null
// //                 : _save,
// //             icon: const Icon(
// //               Icons.save_outlined,
// //             ),
// //             label: const Text(
// //               'Save Progress',
// //             ),
// //           ),
// //
// //           const Spacer(),
// //
// //           ElevatedButton.icon(
// //             onPressed:
// //             completing
// //                 ? null
// //                 : _complete,
// //             icon: completing
// //                 ? const SizedBox(
// //               width: 18,
// //               height: 18,
// //               child:
// //               CircularProgressIndicator(
// //                 strokeWidth: 2,
// //                 color:
// //                 Colors.white,
// //               ),
// //             )
// //                 : const Icon(
// //               Icons.check_circle_outline,
// //             ),
// //             label: Text(
// //               completing
// //                   ? 'Completing...'
// //                   : 'Complete Audit',
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }
//
// import 'package:flutter/material.dart';
// import 'package:uuid/uuid.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_service.dart';
// import 'audit_summary_screen.dart';
//
// class AuditMilScreen extends StatefulWidget {
//   final Audit audit;
//
//   const AuditMilScreen({
//     super.key,
//     required this.audit,
//   });
//
//   @override
//   State<AuditMilScreen> createState() =>
//       _AuditMilScreenState();
// }
//
// class _AuditMilScreenState
//     extends State<AuditMilScreen> {
//   final Uuid _uuid =
//   const Uuid();
//
//   List<AuditFinding> findings =
//   [];
//
//   bool loading = true;
//   bool saving = false;
//   bool completing = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadFindings();
//   }
//
//   // ============================================================
//   // LOAD FINDINGS
//   // ============================================================
//
//   Future<void> _loadFindings() async {
//     try {
//       final allCompleted =
//       await AuditService
//           .areAllCategoriesCompleted(
//         widget.audit,
//       );
//
//       if (!allCompleted) {
//         throw Exception(
//           'MIL report is available only after all audit categories are completed.',
//         );
//       }
//
//       findings =
//       await AuditService.getFindings(
//         widget.audit.auditId,
//       );
//
//       final answers =
//       await AuditService.getAnswers(
//         widget.audit.auditId,
//       );
//
//       final existingIds =
//       findings
//           .map(
//             (finding) =>
//         finding
//             .checklistItemId,
//       )
//           .toSet();
//
//       for (final row in answers) {
//         final answer =
//         row['answer']
//             ?.toString();
//
//         if (answer != 'No') {
//           continue;
//         }
//
//         final checklistId =
//         row['checklist_item_id']
//             ?.toString();
//
//         if (checklistId == null ||
//             checklistId.isEmpty ||
//             existingIds.contains(
//               checklistId,
//             )) {
//           continue;
//         }
//
//         final finding =
//         AuditFinding(
//           id:
//           _uuid.v4(),
//
//           auditId:
//           widget.audit.auditId,
//
//           section:
//           row['section']
//               ?.toString() ??
//               '',
//
//           checklistItemId:
//           checklistId,
//
//           questionNumber:
//           (row['question_number']
//           as num?)
//               ?.toInt() ??
//               0,
//
//           question:
//           row['question']
//               ?.toString() ??
//               '',
//
//           answer: 'No',
//
//           description:
//           row['description']
//               ?.toString() ??
//               '',
//
//           category:
//           row['finding_category'] ==
//               null
//               ? null
//               : FindingCategoryExtension
//               .fromString(
//             row['finding_category']
//                 .toString(),
//           ),
//         );
//
//         await AuditService.saveFinding(
//           finding,
//         );
//
//         findings.add(
//           finding,
//         );
//
//         existingIds.add(
//           checklistId,
//         );
//       }
//
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//       }
//     } catch (e) {
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//
//         _showMessage(
//           'Unable to load MIL findings.\n$e',
//         );
//       }
//     }
//   }
//
//   // ============================================================
//   // SAVE MIL
//   // ============================================================
//
//   Future<bool> _save({
//     bool showMessage = true,
//   }) async {
//     if (saving) {
//       return false;
//     }
//
//     setState(() {
//       saving = true;
//     });
//
//     try {
//       for (final finding in findings) {
//         if (finding.category == null) {
//           throw Exception(
//             'Every finding must have a finding category.',
//           );
//         }
//
//         if (finding.issue
//             .trim()
//             .isEmpty &&
//             finding.description
//                 .trim()
//                 .isEmpty) {
//           throw Exception(
//             'Every finding must have an issue description.',
//           );
//         }
//
//         await AuditService.saveFinding(
//           finding,
//         );
//       }
//
//       if (showMessage &&
//           mounted) {
//         _showMessage(
//           'MIL findings saved successfully.',
//         );
//       }
//
//       return true;
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           e.toString()
//               .replaceFirst(
//             'Exception: ',
//             '',
//           ),
//         );
//       }
//
//       return false;
//     } finally {
//       if (mounted) {
//         setState(() {
//           saving = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // COMPLETE / OPEN SUMMARY
//   // ============================================================
//
//   Future<void> _complete() async {
//     if (completing) {
//       return;
//     }
//
//     setState(() {
//       completing = true;
//     });
//
//     try {
//       final saved =
//       await _save(
//         showMessage: false,
//       );
//
//       if (!saved) {
//         return;
//       }
//
//       final refreshedFindings =
//       await AuditService.getFindings(
//         widget.audit.auditId,
//       );
//
//       final incomplete =
//       refreshedFindings.any(
//             (finding) =>
//         finding.category ==
//             null ||
//             (finding.issue
//                 .trim()
//                 .isEmpty &&
//                 finding.description
//                     .trim()
//                     .isEmpty),
//       );
//
//       if (incomplete) {
//         throw Exception(
//           'Complete all MIL finding details before closing the report.',
//         );
//       }
//
//       final existingAudit =
//       await AuditService.getAudit(
//         widget.audit.auditId,
//       );
//
//       if (existingAudit == null) {
//         throw Exception(
//           'Audit could not be reloaded.',
//         );
//       }
//
//       String milNumber =
//           existingAudit.milNumber ??
//               '';
//
//       if (milNumber.isEmpty) {
//         milNumber =
//         await AuditService
//             .generateMilNumber(
//           existingAudit.auditDate,
//         );
//
//         await AuditService
//             .assignMilNumber(
//           existingAudit.auditId,
//           milNumber,
//         );
//       }
//
//       // The audit should already be Completed
//       // when all categories were finished.
//       //
//       // This call is harmless and ensures older
//       // records also have finished_at populated.
//       if (existingAudit.status !=
//           'Completed') {
//         await AuditService.completeAudit(
//           existingAudit.auditId,
//         );
//       }
//
//       final completedAudit =
//       await AuditService.getAudit(
//         existingAudit.auditId,
//       );
//
//       if (completedAudit == null) {
//         throw Exception(
//           'Unable to reload the completed audit.',
//         );
//       }
//
//       if (!mounted) {
//         return;
//       }
//
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               AuditSummaryScreen(
//                 audit:
//                 completedAudit,
//                 findings:
//                 refreshedFindings,
//                 milNumber:
//                 completedAudit
//                     .milNumber ??
//                     milNumber,
//               ),
//         ),
//       );
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           e.toString()
//               .replaceFirst(
//             'Exception: ',
//             '',
//           ),
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           completing = false;
//         });
//       }
//     }
//   }
//
//   void _showMessage(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior:
//         SnackBarBehavior.floating,
//       ),
//     );
//   }
//
//   Color _categoryColor(
//       FindingCategory? category) {
//     switch (category) {
//       case FindingCategory.critical:
//         return Colors.red;
//
//       case FindingCategory.major:
//         return Colors.orange;
//
//       case FindingCategory.minor:
//         return Colors.green;
//
//       case null:
//         return Colors.grey;
//     }
//   }
//
//   @override
//   Widget build(
//       BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: const Text(
//           'MIL Report',
//           style:
//           TextStyle(
//             fontWeight:
//             FontWeight.w700,
//           ),
//         ),
//
//         backgroundColor:
//         Colors.white,
//
//         foregroundColor:
//         const Color(0xFF172033),
//
//         elevation: 0,
//       ),
//
//       body: loading
//           ? const Center(
//         child:
//         CircularProgressIndicator(),
//       )
//           : findings.isEmpty
//           ? _noFindings()
//           : ListView.builder(
//         padding:
//         const EdgeInsets.all(25),
//
//         itemCount:
//         findings.length,
//
//         itemBuilder:
//             (context, index) {
//           return _findingCard(
//             findings[index],
//             index,
//           );
//         },
//       ),
//
//       bottomNavigationBar:
//       _bottomBar(),
//     );
//   }
//
//   // ============================================================
//   // NO FINDINGS
//   // ============================================================
//
//   Widget _noFindings() {
//     return Center(
//       child: Column(
//         mainAxisAlignment:
//         MainAxisAlignment.center,
//
//         children: [
//           Icon(
//             Icons.check_circle,
//             size: 70,
//             color:
//             Colors.green.shade600,
//           ),
//
//           const SizedBox(
//             height: 15,
//           ),
//
//           const Text(
//             'No Findings Recorded',
//             style:
//             TextStyle(
//               fontSize: 23,
//               fontWeight:
//               FontWeight.w800,
//             ),
//           ),
//
//           const SizedBox(
//             height: 7,
//           ),
//
//           const Text(
//             'All audit checklist questions were answered Yes.',
//             style:
//             TextStyle(
//               color:
//               Color(0xFF6B7280),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // ============================================================
//   // FINDING CARD
//   // ============================================================
//
//   Widget _findingCard(
//       AuditFinding finding,
//       int index) {
//     return Card(
//       elevation: 0,
//
//       margin:
//       const EdgeInsets.only(
//         bottom: 16,
//       ),
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(16),
//
//         side:
//         const BorderSide(
//           color:
//           Color(0xFFE4E8F0),
//         ),
//       ),
//
//       child: Padding(
//         padding:
//         const EdgeInsets.all(20),
//
//         child: Column(
//           crossAxisAlignment:
//           CrossAxisAlignment.start,
//
//           children: [
//             Row(
//               children: [
//                 Container(
//                   width: 38,
//                   height: 38,
//
//                   decoration:
//                   BoxDecoration(
//                     color:
//                     const Color(
//                       0xFFEFF3FF,
//                     ),
//                     borderRadius:
//                     BorderRadius.circular(
//                       10,
//                     ),
//                   ),
//
//                   child: Center(
//                     child: Text(
//                       '${index + 1}',
//                       style:
//                       const TextStyle(
//                         fontWeight:
//                         FontWeight.w800,
//                         color:
//                         Color(
//                           0xFF3155D9,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child: Text(
//                     finding.section,
//                     style:
//                     const TextStyle(
//                       fontWeight:
//                       FontWeight.w800,
//                       fontSize: 16,
//                     ),
//                   ),
//                 ),
//
//                 if (finding.category !=
//                     null)
//                   Container(
//                     padding:
//                     const EdgeInsets
//                         .symmetric(
//                       horizontal: 10,
//                       vertical: 6,
//                     ),
//
//                     decoration:
//                     BoxDecoration(
//                       color:
//                       _categoryColor(
//                         finding.category,
//                       ).withValues(
//                         alpha: 0.10,
//                       ),
//                       borderRadius:
//                       BorderRadius.circular(
//                         20,
//                       ),
//                     ),
//
//                     child: Text(
//                       finding.category!
//                           .value,
//                       style:
//                       TextStyle(
//                         color:
//                         _categoryColor(
//                           finding.category,
//                         ),
//                         fontWeight:
//                         FontWeight.w700,
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 18,
//             ),
//
//             Text(
//               finding.question,
//               style:
//               const TextStyle(
//                 fontSize: 15,
//                 fontWeight:
//                 FontWeight.w600,
//               ),
//             ),
//
//             const SizedBox(
//               height: 16,
//             ),
//
//             TextField(
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Issue',
//                 border:
//                 OutlineInputBorder(),
//               ),
//
//               controller:
//               TextEditingController(
//                 text:
//                 finding.issue,
//               ),
//
//               onChanged:
//                   (value) {
//                 finding.issue =
//                     value;
//               },
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             TextField(
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Root Cause',
//                 border:
//                 OutlineInputBorder(),
//               ),
//
//               controller:
//               TextEditingController(
//                 text:
//                 finding.rootCause,
//               ),
//
//               onChanged:
//                   (value) {
//                 finding.rootCause =
//                     value;
//               },
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             TextField(
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Corrective Action',
//                 border:
//                 OutlineInputBorder(),
//               ),
//
//               controller:
//               TextEditingController(
//                 text:
//                 finding.correctiveAction,
//               ),
//
//               onChanged:
//                   (value) {
//                 finding.correctiveAction =
//                     value;
//               },
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             Row(
//               children: [
//                 Expanded(
//                   child:
//                   TextField(
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'DRI Name',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//
//                     controller:
//                     TextEditingController(
//                       text:
//                       finding.driName,
//                     ),
//
//                     onChanged:
//                         (value) {
//                       finding.driName =
//                           value;
//                     },
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child:
//                   TextField(
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'Mail ID',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//
//                     controller:
//                     TextEditingController(
//                       text:
//                       finding.mailId,
//                     ),
//
//                     onChanged:
//                         (value) {
//                       finding.mailId =
//                           value;
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _bottomBar() {
//     if (loading) {
//       return const SizedBox.shrink();
//     }
//
//     return Container(
//       padding:
//       const EdgeInsets.all(18),
//
//       decoration:
//       const BoxDecoration(
//         color:
//         Colors.white,
//
//         border:
//         Border(
//           top:
//           BorderSide(
//             color:
//             Color(0xFFE4E8F0),
//           ),
//         ),
//       ),
//
//       child: Row(
//         children: [
//           OutlinedButton.icon(
//             onPressed:
//             saving
//                 ? null
//                 : () =>
//                 _save(),
//
//             icon:
//             const Icon(
//               Icons.save_outlined,
//             ),
//
//             label:
//             const Text(
//               'Save Progress',
//             ),
//           ),
//
//           const Spacer(),
//
//           ElevatedButton.icon(
//             onPressed:
//             completing
//                 ? null
//                 : _complete,
//
//             icon:
//             completing
//                 ? const SizedBox(
//               width: 19,
//               height: 19,
//               child:
//               CircularProgressIndicator(
//                 strokeWidth: 2,
//               ),
//             )
//                 : const Icon(
//               Icons.check,
//             ),
//
//             label:
//             Text(
//               completing
//                   ? 'Completing...'
//                   : 'Complete Audit',
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:uuid/uuid.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_service.dart';
// import 'audit_summary_screen.dart';
//
// class AuditMilScreen
//     extends StatefulWidget {
//   final Audit audit;
//
//   const AuditMilScreen({
//     super.key,
//     required this.audit,
//   });
//
//   @override
//   State<AuditMilScreen>
//   createState() =>
//       _AuditMilScreenState();
// }
//
// class _AuditMilScreenState
//     extends State<AuditMilScreen> {
//   final Uuid _uuid =
//   const Uuid();
//
//   List<AuditFinding> findings =
//   [];
//
//   bool loading = true;
//   bool saving = false;
//   bool completing = false;
//
//   @override
//   void initState() {
//     super.initState();
//
//     _loadFindings();
//   }
//
//   // ============================================================
//   // LOAD FINDINGS
//   // ============================================================
//
//   Future<void> _loadFindings() async {
//     try {
//       final allCompleted =
//       await AuditService
//           .areAllCategoriesCompleted(
//         widget.audit,
//       );
//
//       if (!allCompleted) {
//         throw Exception(
//           'MIL report is available only after all audit categories are completed.',
//         );
//       }
//
//       findings =
//       await AuditService.getFindings(
//         widget.audit.auditId,
//       );
//
//       if (findings.isNotEmpty) {
//         await AuditService.setMilStatus(
//           widget.audit.auditId,
//           'Open',
//         );
//       }
//
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//       }
//     } catch (e) {
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//
//         _showMessage(
//           'Unable to load MIL findings.\n$e',
//         );
//       }
//     }
//   }
//   // ============================================================
//   // SAVE
//   // ============================================================
//
//   Future<bool> _save({
//     bool showMessage = true,
//   }) async {
//     if (saving) {
//       return false;
//     }
//
//     setState(() {
//       saving = true;
//     });
//
//     try {
//       for (final finding
//       in findings) {
//         if (finding.category ==
//             null) {
//           throw Exception(
//             'Every finding must have a finding category.',
//           );
//         }
//
//         if (finding.issue
//             .trim()
//             .isEmpty) {
//           throw Exception(
//             'Every finding must have an issue description.',
//           );
//         }
//
//         await AuditService
//             .saveFinding(
//           finding,
//         );
//       }
//
//       if (showMessage &&
//           mounted) {
//         _showMessage(
//           'MIL findings saved successfully.',
//         );
//       }
//
//       return true;
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           e.toString()
//               .replaceFirst(
//             'Exception: ',
//             '',
//           ),
//         );
//       }
//
//       return false;
//     } finally {
//       if (mounted) {
//         setState(() {
//           saving = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // COMPLETE / SUMMARY
//   // ============================================================
//
//   Future<void>
//   _complete() async {
//     if (completing) {
//       return;
//     }
//
//     setState(() {
//       completing = true;
//     });
//
//     try {
//       final saved =
//       await _save(
//         showMessage: false,
//       );
//
//       if (!saved) {
//         return;
//       }
//
//       final refreshedFindings =
//       await AuditService
//           .getFindings(
//         widget.audit.auditId,
//       );
//
//       for (final finding
//       in refreshedFindings) {
//         if (finding.category ==
//             null) {
//           throw Exception(
//             'Complete every MIL finding category.',
//           );
//         }
//
//         if (finding.issue
//             .trim()
//             .isEmpty) {
//           throw Exception(
//             'Complete every MIL issue description.',
//           );
//         }
//       }
//
//       final existingAudit =
//       await AuditService
//           .getAudit(
//         widget.audit.auditId,
//       );
//
//       if (existingAudit ==
//           null) {
//         throw Exception(
//           'Audit could not be reloaded.',
//         );
//       }
//
//       String milNumber =
//           existingAudit.milNumber ??
//               '';
//
//       if (milNumber.isEmpty) {
//         milNumber =
//         await AuditService
//             .generateMilNumber(
//           existingAudit.auditDate,
//         );
//
//         await AuditService
//             .assignMilNumber(
//           existingAudit.auditId,
//           milNumber,
//         );
//       }
//
//       final completedAudit =
//       await AuditService
//           .getAudit(
//         existingAudit.auditId,
//       );
//
//       if (completedAudit ==
//           null) {
//         throw Exception(
//           'Unable to reload completed audit.',
//         );
//       }
//
//       if (!mounted) {
//         return;
//       }
//
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(
//           builder: (_) =>
//               AuditSummaryScreen(
//                 audit:
//                 completedAudit,
//                 findings:
//                 refreshedFindings,
//                 milNumber:
//                 completedAudit
//                     .milNumber ??
//                     milNumber,
//               ),
//         ),
//       );
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           e.toString()
//               .replaceFirst(
//             'Exception: ',
//             '',
//           ),
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           completing = false;
//         });
//       }
//     }
//   }
//   Future<void> _closeMil() async {
//     if (completing) {
//       return;
//     }
//
//     setState(() {
//       completing = true;
//     });
//
//     try {
//       final saved =
//       await _save(showMessage: false);
//
//       if (!saved) {
//         return;
//       }
//
//       await AuditService.closeMil(
//         widget.audit.auditId,
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       _showMessage(
//         'MIL closed successfully.',
//       );
//
//       Navigator.pop(context);
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           e.toString()
//               .replaceFirst(
//             'Exception: ',
//             '',
//           ),
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           completing = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // CATEGORY COLOR
//   // ============================================================
//
//   Color _categoryColor(
//       FindingCategory? category) {
//     switch (category) {
//       case FindingCategory.critical:
//         return Colors.red;
//
//       case FindingCategory.major:
//         return Colors.orange;
//
//       case FindingCategory.minor:
//         return Colors.green;
//
//       case null:
//         return Colors.grey;
//     }
//   }
//
//   // ============================================================
//   // MESSAGE
//   // ============================================================
//
//   void _showMessage(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content:
//         Text(message),
//         behavior:
//         SnackBarBehavior
//             .floating,
//       ),
//     );
//   }
//
//   // ============================================================
//   // BUILD
//   // ============================================================
//
//   @override
//   Widget build(
//       BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: const Text(
//           'MIL Report',
//           style:
//           TextStyle(
//             fontWeight:
//             FontWeight.w700,
//           ),
//         ),
//
//         backgroundColor:
//         Colors.white,
//
//         foregroundColor:
//         const Color(
//           0xFF172033,
//         ),
//
//         elevation: 0,
//       ),
//
//       body: loading
//           ? const Center(
//         child:
//         CircularProgressIndicator(),
//       )
//           : findings.isEmpty
//           ? _noFindings()
//           : ListView.builder(
//         padding:
//         const EdgeInsets
//             .fromLTRB(
//           25,
//           25,
//           25,
//           120,
//         ),
//         itemCount:
//         findings.length,
//         itemBuilder:
//             (context,
//             index) {
//           return _findingCard(
//             findings[index],
//             index,
//           );
//         },
//       ),
//
//       bottomNavigationBar:
//       _bottomBar(),
//     );
//   }
//
//   // ============================================================
//   // NO FINDINGS
//   // ============================================================
//
//   Widget _noFindings() {
//     return Center(
//       child: Column(
//         mainAxisAlignment:
//         MainAxisAlignment
//             .center,
//         children: [
//           Icon(
//             Icons.check_circle,
//             size: 70,
//             color:
//             Colors.green
//                 .shade600,
//           ),
//
//           const SizedBox(
//             height: 15,
//           ),
//
//           const Text(
//             'No Findings Recorded',
//             style:
//             TextStyle(
//               fontSize: 23,
//               fontWeight:
//               FontWeight.w800,
//             ),
//           ),
//
//           const SizedBox(
//             height: 7,
//           ),
//
//           const Text(
//             'All audit checklist questions were answered Yes.',
//             style:
//             TextStyle(
//               color:
//               Color(0xFF6B7280),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // ============================================================
//   // FINDING CARD
//   // ============================================================
//
//   Widget _findingCard(
//       AuditFinding finding,
//       int index) {
//     return Card(
//       elevation: 0,
//
//       margin:
//       const EdgeInsets.only(
//         bottom: 18,
//       ),
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(
//           16,
//         ),
//         side:
//         const BorderSide(
//           color:
//           Color(0xFFE4E8F0),
//         ),
//       ),
//
//       child: Padding(
//         padding:
//         const EdgeInsets.all(
//           20,
//         ),
//
//         child: Column(
//           crossAxisAlignment:
//           CrossAxisAlignment
//               .start,
//
//           children: [
//             Row(
//               children: [
//                 Container(
//                   width: 40,
//                   height: 40,
//                   alignment:
//                   Alignment.center,
//                   decoration:
//                   BoxDecoration(
//                     color:
//                     const Color(
//                       0xFFEFF3FF,
//                     ),
//                     borderRadius:
//                     BorderRadius
//                         .circular(
//                       10,
//                     ),
//                   ),
//                   child: Text(
//                     '${index + 1}',
//                     style:
//                     const TextStyle(
//                       color:
//                       Color(
//                         0xFF3155D9,
//                       ),
//                       fontWeight:
//                       FontWeight
//                           .w800,
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child: Text(
//                     finding.section,
//                     style:
//                     const TextStyle(
//                       fontWeight:
//                       FontWeight
//                           .w800,
//                       fontSize: 16,
//                     ),
//                   ),
//                 ),
//
//                 if (finding.category !=
//                     null)
//                   Container(
//                     padding:
//                     const EdgeInsets
//                         .symmetric(
//                       horizontal: 10,
//                       vertical: 6,
//                     ),
//                     decoration:
//                     BoxDecoration(
//                       color:
//                       _categoryColor(
//                         finding.category,
//                       ).withValues(
//                         alpha: 0.10,
//                       ),
//                       borderRadius:
//                       BorderRadius
//                           .circular(
//                         20,
//                       ),
//                     ),
//                     child: Text(
//                       finding.category!
//                           .value,
//                       style:
//                       TextStyle(
//                         color:
//                         _categoryColor(
//                           finding.category,
//                         ),
//                         fontWeight:
//                         FontWeight
//                             .w700,
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 18,
//             ),
//
//             Text(
//               finding.question,
//               style:
//               const TextStyle(
//                 fontWeight:
//                 FontWeight.w600,
//                 height: 1.4,
//               ),
//             ),
//
//             const SizedBox(
//               height: 16,
//             ),
//
//             TextFormField(
//               initialValue:
//               finding.issue.isEmpty
//                   ? finding.description
//                   : finding.issue,
//               maxLines: 4,
//               onChanged:
//                   (value) {
//                 finding.issue =
//                     value;
//               },
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Issue / Finding',
//                 border:
//                 OutlineInputBorder(),
//                 alignLabelWithHint:
//                 true,
//               ),
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             DropdownButtonFormField<
//                 FindingCategory>(
//               value:
//               finding.category,
//
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Finding Category',
//                 border:
//                 OutlineInputBorder(),
//               ),
//
//               items:
//               FindingCategory
//                   .values
//                   .map(
//                     (category) {
//                   return DropdownMenuItem<
//                       FindingCategory>(
//                     value:
//                     category,
//                     child: Row(
//                       children: [
//                         Container(
//                           width: 11,
//                           height: 11,
//                           decoration:
//                           BoxDecoration(
//                             color:
//                             _categoryColor(
//                               category,
//                             ),
//                             shape:
//                             BoxShape
//                                 .circle,
//                           ),
//                         ),
//                         const SizedBox(
//                           width: 10,
//                         ),
//                         Text(
//                           category
//                               .value,
//                         ),
//                       ],
//                     ),
//                   );
//                 },
//               ).toList(),
//
//               onChanged:
//               completing
//                   ? null
//                   : (value) {
//                 if (value ==
//                     null) {
//                   return;
//                 }
//
//                 setState(() {
//                   finding.category =
//                       value;
//                 });
//               },
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             Row(
//               children: [
//                 Expanded(
//                   child:
//                   TextFormField(
//                     initialValue:
//                     finding.rootCause,
//                     maxLines: 2,
//                     onChanged:
//                         (value) {
//                       finding.rootCause =
//                           value;
//                     },
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'Root Cause',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child:
//                   TextFormField(
//                     initialValue:
//                     finding.correctiveAction,
//                     maxLines: 2,
//                     onChanged:
//                         (value) {
//                       finding.correctiveAction =
//                           value;
//                     },
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'Corrective Action',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             Row(
//               children: [
//                 Expanded(
//                   child:
//                   TextFormField(
//                     initialValue:
//                     finding.driName,
//                     onChanged:
//                         (value) {
//                       finding.driName =
//                           value;
//                     },
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'DRI Name',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child:
//                   TextFormField(
//                     initialValue:
//                     finding.mailId,
//                     onChanged:
//                         (value) {
//                       finding.mailId =
//                           value;
//                     },
//                     decoration:
//                     const InputDecoration(
//                       labelText:
//                       'Mail ID',
//                       border:
//                       OutlineInputBorder(),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             OutlinedButton.icon(
//               onPressed:
//               completing
//                   ? null
//                   : () async {
//                 final date =
//                 await showDatePicker(
//                   context:
//                   context,
//                   firstDate:
//                   DateTime
//                       .now(),
//                   lastDate:
//                   DateTime(
//                     2100,
//                   ),
//                   initialDate:
//                   finding.deadline ??
//                       DateTime.now(),
//                 );
//
//                 if (date !=
//                     null) {
//                   setState(() {
//                     finding.deadline =
//                         date;
//                   });
//                 }
//               },
//               icon: const Icon(
//                 Icons.calendar_today,
//               ),
//               label: Text(
//                 finding.deadline ==
//                     null
//                     ? 'Select Deadline'
//                     : 'Deadline: '
//                     '${finding.deadline!.day}/'
//                     '${finding.deadline!.month}/'
//                     '${finding.deadline!.year}',
//               ),
//             ),
//
//             const SizedBox(
//               height: 14,
//             ),
//
//             DropdownButtonFormField<
//                 String>(
//               value:
//               finding.overallStatus,
//
//               decoration:
//               const InputDecoration(
//                 labelText:
//                 'Overall Status',
//                 border:
//                 OutlineInputBorder(),
//               ),
//
//               items: const [
//                 DropdownMenuItem(
//                   value: 'Open',
//                   child:
//                   Text('Open'),
//                 ),
//                 DropdownMenuItem(
//                   value: 'Closed',
//                   child:
//                   Text('Closed'),
//                 ),
//                 DropdownMenuItem(
//                   value:
//                   'Under Investigation',
//                   child: Text(
//                     'Under Investigation',
//                   ),
//                 ),
//                 DropdownMenuItem(
//                   value:
//                   'Pending Implementation',
//                   child: Text(
//                     'Pending Implementation',
//                   ),
//                 ),
//               ],
//
//               onChanged:
//               completing
//                   ? null
//                   : (value) {
//                 if (value ==
//                     null) {
//                   return;
//                 }
//
//                 setState(() {
//                   finding.overallStatus =
//                       value;
//                 });
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // ============================================================
//   // BOTTOM BAR
//   // ============================================================
//
//   Widget _bottomBar() {
//     return Container(
//       padding:
//       const EdgeInsets.all(16),
//       decoration:
//       const BoxDecoration(
//         color: Colors.white,
//         border: Border(
//           top: BorderSide(
//             color:
//             Color(0xFFE4E8F0),
//           ),
//         ),
//       ),
//       child: Row(
//         children: [
//           OutlinedButton.icon(
//             onPressed:
//             saving ||
//                 completing
//                 ? null
//                 : _save,
//             icon: const Icon(
//               Icons.save_outlined,
//             ),
//             label: const Text(
//               'Save Progress',
//             ),
//           ),
//
//           const Spacer(),
//
//           ElevatedButton.icon(
//             onPressed:
//             completing
//                 ? null
//                 : _complete,
//             icon: completing
//                 ? const SizedBox(
//               width: 18,
//               height: 18,
//               child:
//               CircularProgressIndicator(
//                 strokeWidth: 2,
//                 color:
//                 Colors.white,
//               ),
//             )
//                 : const Icon(
//               Icons
//                   .check_circle_outline,
//             ),
//             label: Text(
//               completing
//                   ? 'Completing...'
//                   : 'Complete Report',
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_service.dart';

class AuditMilScreen extends StatefulWidget {
  final Audit audit;

  const AuditMilScreen({
    super.key,
    required this.audit,
  });

  @override
  State<AuditMilScreen> createState() =>
      _AuditMilScreenState();
}

class _AuditMilScreenState
    extends State<AuditMilScreen> {
  List<AuditFinding> findings = [];

  bool loading = true;
  bool saving = false;
  bool closing = false;

  String milNumber = '';
  String milStatus = 'Not Generated';

  @override
  void initState() {
    super.initState();
    _loadMil();
  }

  // ============================================================
  // LOAD MIL
  // ============================================================

  Future<void> _loadMil() async {
    try {
      final audit =
      await AuditService.getAudit(
        widget.audit.auditId,
      );

      if (audit == null) {
        throw Exception(
          'Audit could not be loaded.',
        );
      }

      final allCompleted =
      await AuditService
          .areAllCategoriesCompleted(
        audit,
      );

      if (!allCompleted) {
        throw Exception(
          'MIL report is available only after all audit categories are completed.',
        );
      }

      // --------------------------------------------------------
      // GENERATE MIL NUMBER ON FIRST MIL OPEN
      // --------------------------------------------------------

      milNumber =
          audit.milNumber?.trim() ?? '';

      if (milNumber.isEmpty) {
        milNumber =
        await AuditService
            .generateMilNumber(
          audit.auditDate,
        );

        await AuditService.assignMilNumber(
          audit.auditId,
          milNumber,
        );
      }

      // --------------------------------------------------------
      // LOAD EXISTING MIL FINDINGS
      // --------------------------------------------------------

      final existingFindings =
      await AuditService.getFindings(
        audit.auditId,
      );

      // --------------------------------------------------------
      // LOAD CHECKLIST ANSWERS
      //
      // Only "No" answers belong in MIL.
      //
      // Question / Answer / Description /
      // Finding Category come from the checklist.
      // They are therefore LOCKED.
      // --------------------------------------------------------

      final answers =
      await AuditService.getAnswers(
        audit.auditId,
      );

      final existingByChecklistId =
      <String, AuditFinding>{};

      for (final finding
      in existingFindings) {
        existingByChecklistId[
        finding.checklistItemId] =
            finding;
      }

      final rebuiltFindings =
      <AuditFinding>[];

      for (final row in answers) {
        final answer =
            row['answer']
                ?.toString()
                .trim() ??
                '';

        if (answer != 'No') {
          continue;
        }

        final checklistId =
            row['checklist_item_id']
                ?.toString()
                .trim() ??
                '';

        if (checklistId.isEmpty) {
          continue;
        }

        final originalDescription =
            row['description']
                ?.toString() ??
                '';

        final originalCategory =
        row['finding_category']
            ?.toString()
            .trim();

        final FindingCategory?
        lockedCategory =
        originalCategory == null ||
            originalCategory.isEmpty
            ? null
            : FindingCategoryExtension
            .fromString(
          originalCategory,
        );

        final existing =
        existingByChecklistId[
        checklistId];

        final finding =
        AuditFinding(
          id: existing?.id ??
              row['answer_id']
                  ?.toString() ??
              DateTime.now()
                  .microsecondsSinceEpoch
                  .toString(),

          auditId:
          audit.auditId,

          section:
          row['section']
              ?.toString() ??
              '',

          checklistItemId:
          checklistId,

          questionNumber:
          (row['question_number']
          as num?)
              ?.toInt() ??
              0,

          question:
          row['question']
              ?.toString() ??
              '',

          // Always locked to No.
          answer: 'No',

          // Always from checklist.
          description:
          originalDescription,

          // Always from checklist.
          category:
          lockedCategory,

          // ----------------------------------------------------
          // MIL-EDITABLE FIELDS
          // ----------------------------------------------------

          // Keep existing issue only for backward compatibility.
          // UI will NOT allow editing it.
          issue:
          originalDescription,

          rootCause:
          existing?.rootCause ??
              '',

          correctiveAction:
          existing?.correctiveAction ??
              '',

          driName:
          existing?.driName ??
              '',

          mailId:
          existing?.mailId ??
              '',

          deadline:
          existing?.deadline,

          overallStatus:
          existing?.overallStatus ??
              'Open',
        );

        rebuiltFindings.add(
          finding,
        );
      }

      findings =
          rebuiltFindings;

      // --------------------------------------------------------
      // MIL STATUS
      // --------------------------------------------------------

      if (findings.isEmpty) {
        milStatus = 'Closed';

        await AuditService.setMilStatus(
          audit.auditId,
          'Closed',
        );
      } else {
        final existingStatus =
        await AuditService.getMilStatus(
          audit.auditId,
        );

        if (existingStatus ==
            'Not Generated' ||
            existingStatus.isEmpty) {
          milStatus = 'Open';

          await AuditService.setMilStatus(
            audit.auditId,
            'Open',
          );
        } else {
          milStatus =
              existingStatus;
        }
      }

      if (!mounted) {
        return;
      }

      setState(() {
        loading = false;
      });
    } catch (e) {
      if (!mounted) {
        return;
      }

      setState(() {
        loading = false;
      });

      _showMessage(
        'Unable to load MIL.\n$e',
      );
    }
  }

  // ============================================================
  // SAVE MIL EDITABLE FIELDS
  // ============================================================

  Future<void> _save() async {
    if (saving) {
      return;
    }

    setState(() {
      saving = true;
    });

    try {
      for (final finding in findings) {
        await AuditService.saveFinding(
          finding,
        );
      }

      // If findings exist, MIL remains open
      // until every finding is closed.
      if (findings.isNotEmpty) {
        await AuditService.setMilStatus(
          widget.audit.auditId,
          'Open',
        );

        milStatus = 'Open';
      }

      if (!mounted) {
        return;
      }

      _showMessage(
        'MIL changes saved successfully.',
      );
    } catch (e) {
      if (mounted) {
        _showMessage(
          'Unable to save MIL.\n$e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          saving = false;
        });
      }
    }
  }

  // ============================================================
  // CLOSE MIL
  // ============================================================

  Future<void> _closeMil() async {
    if (closing) {
      return;
    }

    if (findings.isEmpty) {
      await AuditService.setMilStatus(
        widget.audit.auditId,
        'Closed',
      );

      if (mounted) {
        setState(() {
          milStatus = 'Closed';
        });
      }

      return;
    }

    final notClosed =
    findings.where(
          (finding) =>
      finding.overallStatus
          .trim()
          .toLowerCase() !=
          'closed',
    );

    if (notClosed.isNotEmpty) {
      _showMessage(
        'MIL cannot be closed until every finding has Overall Status = Closed.',
      );

      return;
    }

    setState(() {
      closing = true;
    });

    try {
      // Save final editable values first.
      for (final finding in findings) {
        await AuditService.saveFinding(
          finding,
        );
      }

      await AuditService.closeMil(
        widget.audit.auditId,
      );

      if (!mounted) {
        return;
      }

      setState(() {
        milStatus = 'Closed';
      });

      _showMessage(
        'MIL closed successfully.',
      );
    } catch (e) {
      if (mounted) {
        _showMessage(
          'Unable to close MIL.\n$e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          closing = false;
        });
      }
    }
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
      String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior:
        SnackBarBehavior.floating,
      ),
    );
  }

  // ============================================================
  // CATEGORY COLOR
  // ============================================================

  Color _categoryColor(
      FindingCategory? category) {
    switch (category) {
      case FindingCategory.critical:
        return Colors.red;

      case FindingCategory.major:
        return Colors.orange;

      case FindingCategory.minor:
        return Colors.green;

      case null:
        return Colors.grey;
    }
  }

  // ============================================================
  // STATUS COLOR
  // ============================================================

  Color _statusColor(
      String status) {
    switch (status
        .trim()
        .toLowerCase()) {
      case 'closed':
        return Colors.green;

      case 'under investigation':
        return Colors.orange;

      case 'pending implementation':
        return Colors.deepOrange;

      default:
        return Colors.red;
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
      BuildContext context) {
    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: const Text(
          'MIL Report',
          style: TextStyle(
            fontWeight:
            FontWeight.w700,
          ),
        ),
        backgroundColor:
        Colors.white,
        foregroundColor:
        const Color(0xFF172033),
        elevation: 0,

        actions: [
          if (!loading)
            Padding(
              padding:
              const EdgeInsets.only(
                right: 18,
              ),
              child:
              _milStatusBadge(),
            ),
        ],
      ),

      body: loading
          ? const Center(
        child:
        CircularProgressIndicator(),
      )
          : Column(
        children: [
          _milHeader(),

          Expanded(
            child:
            findings.isEmpty
                ? _noFindings()
                : ListView.builder(
              padding:
              const EdgeInsets.fromLTRB(
                24,
                18,
                24,
                110,
              ),
              itemCount:
              findings.length,
              itemBuilder:
                  (
                  context,
                  index,
                  ) {
                return _findingCard(
                  findings[
                  index],
                  index,
                );
              },
            ),
          ),
        ],
      ),

      bottomNavigationBar:
      loading
          ? null
          : _bottomBar(),
    );
  }

  // ============================================================
  // MIL HEADER
  // ============================================================

  Widget _milHeader() {
    return Container(
      width: double.infinity,
      color: Colors.white,
      padding:
      const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 18,
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration:
            BoxDecoration(
              color:
              const Color(
                0xFFF0EBFA,
              ),
              borderRadius:
              BorderRadius.circular(
                12,
              ),
            ),
            child: const Icon(
              Icons.assignment_outlined,
              color:
              Color(0xFF7048B8),
            ),
          ),

          const SizedBox(
            width: 14,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                const Text(
                  'Major Issue List',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight:
                    FontWeight.w800,
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  milNumber.isEmpty
                      ? 'MIL Number pending'
                      : 'MIL Number: $milNumber',
                  style:
                  const TextStyle(
                    color:
                    Color(0xFF727A8C),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding:
            const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 7,
            ),
            decoration:
            BoxDecoration(
              color:
              _statusColor(
                milStatus,
              ).withValues(
                alpha: 0.10,
              ),
              borderRadius:
              BorderRadius.circular(
                20,
              ),
            ),
            child: Text(
              milStatus,
              style: TextStyle(
                color:
                _statusColor(
                  milStatus,
                ),
                fontSize: 12,
                fontWeight:
                FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _milStatusBadge() {
    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 7,
      ),
      decoration:
      BoxDecoration(
        color:
        _statusColor(
          milStatus,
        ).withValues(
          alpha: 0.10,
        ),
        borderRadius:
        BorderRadius.circular(
          20,
        ),
      ),
      child: Text(
        milStatus,
        style: TextStyle(
          color:
          _statusColor(
            milStatus,
          ),
          fontWeight:
          FontWeight.w700,
          fontSize: 12,
        ),
      ),
    );
  }

  // ============================================================
  // FINDING CARD
  // ============================================================

  Widget _findingCard(
      AuditFinding finding,
      int index) {
    final category =
        finding.category;

    final categoryColor =
    _categoryColor(
      category,
    );

    return Card(
      elevation: 0,
      margin:
      const EdgeInsets.only(
        bottom: 16,
      ),
      shape:
      RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(
          14,
        ),
        side:
        const BorderSide(
          color:
          Color(0xFFE3E6EF),
        ),
      ),
      child: Padding(
        padding:
        const EdgeInsets.all(
          18,
        ),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            // --------------------------------------------------
            // TOP ROW
            // --------------------------------------------------

            Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  alignment:
                  Alignment.center,
                  decoration:
                  BoxDecoration(
                    color:
                    const Color(
                      0xFFF0EBFA,
                    ),
                    borderRadius:
                    BorderRadius.circular(
                      9,
                    ),
                  ),
                  child: Text(
                    '${index + 1}',
                    style:
                    const TextStyle(
                      color:
                      Color(0xFF7048B8),
                      fontWeight:
                      FontWeight.w800,
                    ),
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Text(
                    finding.section,
                    style:
                    const TextStyle(
                      fontSize: 15,
                      fontWeight:
                      FontWeight.w800,
                    ),
                  ),
                ),

                if (category != null)
                  Container(
                    padding:
                    const EdgeInsets
                        .symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration:
                    BoxDecoration(
                      color:
                      categoryColor
                          .withValues(
                        alpha: 0.10,
                      ),
                      borderRadius:
                      BorderRadius
                          .circular(
                        20,
                      ),
                    ),
                    child: Text(
                      category.value,
                      style:
                      TextStyle(
                        color:
                        categoryColor,
                        fontSize: 12,
                        fontWeight:
                        FontWeight.w800,
                      ),
                    ),
                  ),
              ],
            ),

            const SizedBox(
              height: 16,
            ),

            // --------------------------------------------------
            // QUESTION
            // --------------------------------------------------

            _lockedField(
              label: 'Question',
              value:
              finding.question,
              icon:
              Icons.help_outline,
            ),

            const SizedBox(
              height: 10,
            ),

            // --------------------------------------------------
            // ANSWER
            // --------------------------------------------------

            _lockedField(
              label: 'Answer',
              value: 'No',
              icon:
              Icons.cancel_outlined,
              valueColor:
              Colors.red,
            ),

            const SizedBox(
              height: 10,
            ),

            // --------------------------------------------------
            // DESCRIPTION
            // --------------------------------------------------

            _lockedField(
              label: 'Description',
              value:
              finding.description,
              icon:
              Icons.description_outlined,
            ),

            const SizedBox(
              height: 10,
            ),

            // --------------------------------------------------
            // ERROR TYPE
            // --------------------------------------------------

            _lockedField(
              label: 'Error Type',
              value:
              category?.value ??
                  'Not classified',
              icon:
              Icons.warning_amber_outlined,
              valueColor:
              categoryColor,
            ),

            const SizedBox(
              height: 18,
            ),

            const Divider(
              height: 1,
            ),

            const SizedBox(
              height: 18,
            ),

            // --------------------------------------------------
            // ROOT CAUSE
            // EDITABLE
            // --------------------------------------------------

            _editableField(
              label: 'Root Cause',
              initialValue:
              finding.rootCause,
              maxLines: 3,
              onChanged:
                  (value) {
                finding.rootCause =
                    value;
              },
            ),

            const SizedBox(
              height: 12,
            ),

            // --------------------------------------------------
            // CORRECTIVE ACTION
            // EDITABLE
            // --------------------------------------------------

            _editableField(
              label:
              'Corrective Action',
              initialValue:
              finding.correctiveAction,
              maxLines: 3,
              onChanged:
                  (value) {
                finding.correctiveAction =
                    value;
              },
            ),

            const SizedBox(
              height: 12,
            ),

            // --------------------------------------------------
            // DRI + MAIL
            // --------------------------------------------------

            Row(
              children: [
                Expanded(
                  child:
                  _editableField(
                    label: 'DRI Name',
                    initialValue:
                    finding.driName,
                    onChanged:
                        (value) {
                      finding.driName =
                          value;
                    },
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child:
                  _editableField(
                    label: 'Mail ID',
                    initialValue:
                    finding.mailId,
                    keyboardType:
                    TextInputType
                        .emailAddress,
                    onChanged:
                        (value) {
                      finding.mailId =
                          value;
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 12,
            ),

            // --------------------------------------------------
            // DEADLINE + STATUS
            // --------------------------------------------------

            Row(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,
              children: [
                Expanded(
                  child:
                  _deadlineField(
                    finding,
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child:
                  _statusField(
                    finding,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // LOCKED FIELD
  // ============================================================

  Widget _lockedField({
    required String label,
    required String value,
    required IconData icon,
    Color? valueColor,
  }) {
    return Container(
      width: double.infinity,
      padding:
      const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration:
      BoxDecoration(
        color:
        const Color(0xFFF7F8FB),
        borderRadius:
        BorderRadius.circular(
          9,
        ),
        border:
        Border.all(
          color:
          const Color(0xFFE1E5ED),
        ),
      ),
      child: Row(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 18,
            color:
            const Color(0xFF7B8292),
          ),

          const SizedBox(
            width: 9,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style:
                  const TextStyle(
                    fontSize: 11,
                    fontWeight:
                    FontWeight.w700,
                    color:
                    Color(0xFF777F90),
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  value.trim().isEmpty
                      ? '-'
                      : value,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight:
                    FontWeight.w600,
                    color:
                    valueColor ??
                        const Color(
                          0xFF252B38,
                        ),
                  ),
                ),
              ],
            ),
          ),

          const Icon(
            Icons.lock_outline,
            size: 15,
            color:
            Color(0xFF9BA2B0),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // EDITABLE FIELD
  // ============================================================

  Widget _editableField({
    required String label,
    required String initialValue,
    required ValueChanged<String>
    onChanged,
    int maxLines = 1,
    TextInputType?
    keyboardType,
  }) {
    return TextFormField(
      initialValue:
      initialValue,
      maxLines: maxLines,
      keyboardType:
      keyboardType,
      onChanged:
      onChanged,
      decoration:
      InputDecoration(
        labelText: label,
        border:
        const OutlineInputBorder(),
        isDense: true,
        alignLabelWithHint:
        maxLines > 1,
      ),
    );
  }

  // ============================================================
  // DEADLINE
  // ============================================================

  Widget _deadlineField(
      AuditFinding finding) {
    final value =
        finding.deadline;

    return InkWell(
      onTap: saving ||
          closing
          ? null
          : () async {
        final selected =
        await showDatePicker(
          context:
          context,
          firstDate:
          DateTime(2020),
          lastDate:
          DateTime(2100),
          initialDate:
          value ??
              DateTime.now(),
        );

        if (selected ==
            null) {
          return;
        }

        setState(() {
          finding.deadline =
              selected;
        });
      },
      child: InputDecorator(
        decoration:
        const InputDecoration(
          labelText:
          'Deadline',
          border:
          OutlineInputBorder(),
          isDense: true,
          suffixIcon:
          Icon(
            Icons.calendar_today_outlined,
            size: 18,
          ),
        ),
        child: Text(
          value == null
              ? 'Select date'
              : '${value.day.toString().padLeft(2, '0')}/'
              '${value.month.toString().padLeft(2, '0')}/'
              '${value.year}',
          style:
          const TextStyle(
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // OVERALL STATUS
  // ============================================================

  Widget _statusField(
      AuditFinding finding) {
    return DropdownButtonFormField<
        String>(
      value:
      finding.overallStatus,
      isDense: true,
      decoration:
      const InputDecoration(
        labelText:
        'Overall Status',
        border:
        OutlineInputBorder(),
        isDense: true,
      ),
      items: const [
        DropdownMenuItem(
          value: 'Open',
          child:
          Text('Open'),
        ),
        DropdownMenuItem(
          value:
          'Under Investigation',
          child: Text(
            'Under Investigation',
          ),
        ),
        DropdownMenuItem(
          value:
          'Pending Implementation',
          child: Text(
            'Pending Implementation',
          ),
        ),
        DropdownMenuItem(
          value: 'Closed',
          child:
          Text('Closed'),
        ),
      ],
      onChanged:
      saving || closing
          ? null
          : (value) {
        if (value ==
            null) {
          return;
        }

        setState(() {
          finding
              .overallStatus =
              value;
        });
      },
    );
  }

  // ============================================================
  // NO FINDINGS
  // ============================================================

  Widget _noFindings() {
    return Center(
      child: Padding(
        padding:
        const EdgeInsets.all(
          30,
        ),
        child: Column(
          mainAxisAlignment:
          MainAxisAlignment.center,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration:
              BoxDecoration(
                color:
                Colors.green
                    .withValues(
                  alpha: 0.10,
                ),
                shape:
                BoxShape.circle,
              ),
              child:
              const Icon(
                Icons.check_circle,
                color:
                Colors.green,
                size: 38,
              ),
            ),

            const SizedBox(
              height: 14,
            ),

            const Text(
              'No Findings Recorded',
              style: TextStyle(
                fontSize: 19,
                fontWeight:
                FontWeight.w800,
              ),
            ),

            const SizedBox(
              height: 6,
            ),

            const Text(
              'All audit checklist questions were answered Yes.',
              textAlign:
              TextAlign.center,
              style: TextStyle(
                color:
                Color(0xFF777F90),
              ),
            ),

            if (milNumber
                .isNotEmpty) ...[
              const SizedBox(
                height: 12,
              ),
              Text(
                'MIL Number: $milNumber',
                style:
                const TextStyle(
                  fontWeight:
                  FontWeight.w700,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ============================================================
  // BOTTOM BAR
  // ============================================================

  Widget _bottomBar() {
    return Container(
      padding:
      const EdgeInsets.fromLTRB(
        18,
        12,
        18,
        12,
      ),
      decoration:
      const BoxDecoration(
        color: Colors.white,
        border:
        Border(
          top:
          BorderSide(
            color:
            Color(0xFFE3E6EF),
          ),
        ),
      ),
      child: Row(
        children: [
          OutlinedButton.icon(
            onPressed:
            saving || closing
                ? null
                : _save,
            icon:
            saving
                ? const SizedBox(
              width: 16,
              height: 16,
              child:
              CircularProgressIndicator(
                strokeWidth: 2,
              ),
            )
                : const Icon(
              Icons
                  .save_outlined,
              size: 18,
            ),
            label:
            Text(
              saving
                  ? 'Saving...'
                  : 'Save Changes',
            ),
          ),

          const Spacer(),

          if (findings.isNotEmpty)
            ElevatedButton.icon(
              onPressed:
              closing ||
                  milStatus ==
                      'Closed'
                  ? null
                  : _closeMil,
              icon:
              closing
                  ? const SizedBox(
                width: 16,
                height: 16,
                child:
                CircularProgressIndicator(
                  strokeWidth: 2,
                  color:
                  Colors.white,
                ),
              )
                  : const Icon(
                Icons
                    .check_circle_outline,
                size: 18,
              ),
              label:
              Text(
                closing
                    ? 'Closing...'
                    : 'Close MIL',
              ),
            ),
        ],
      ),
    );
  }
}