// // // import 'package:flutter/material.dart';
// // // import 'package:uuid/uuid.dart';
// // //
// // // import '../../models/audit/audit.dart';
// // // import '../../models/audit/audit_checklist_item.dart';
// // // import '../../models/audit/audit_finding.dart';
// // // import '../../services/audit/audit_checklist_data.dart';
// // // import '../../services/audit/audit_service.dart';
// // // import 'audit_mil_screen.dart';
// // //
// // // class AuditChecklistScreen
// // //     extends StatefulWidget {
// // //   final Audit audit;
// // //   final List<String>? sections;
// // //
// // //   const AuditChecklistScreen({
// // //     super.key,
// // //     required this.audit,
// // //     this.sections,
// // //   });
// // //
// // //   @override
// // //   State<AuditChecklistScreen>
// // //   createState() =>
// // //       _AuditChecklistScreenState();
// // // }
// // //
// // // class _AuditChecklistScreenState
// // //     extends State<AuditChecklistScreen> {
// // //   final Uuid uuid = const Uuid();
// // //
// // //   late List<String> sections;
// // //   int currentSectionIndex = 0;
// // //
// // //   final Map<String, String> answers = {};
// // //   final Map<String, String> descriptions = {};
// // //   final Map<String, FindingCategory>
// // //   categories = {};
// // //
// // //   bool saving = false;
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //
// // //     if (widget.audit.auditType ==
// // //         'Process Audit') {
// // //       sections =
// // //           widget.sections ??
// // //               AuditChecklistData
// // //                   .processSections;
// // //     } else if (widget.audit.auditType ==
// // //         'Product Audit') {
// // //       sections = ['Product Audit'];
// // //     } else {
// // //       sections = ['QMS System Audit'];
// // //     }
// // //
// // //     _loadSavedAnswers();
// // //   }
// // //
// // //   List<AuditChecklistItem> get items {
// // //     final section = sections[
// // //     currentSectionIndex];
// // //
// // //     if (widget.audit.auditType ==
// // //         'Process Audit') {
// // //       return AuditChecklistData
// // //           .processItemsFor(section);
// // //     }
// // //
// // //     if (widget.audit.auditType ==
// // //         'Product Audit') {
// // //       return AuditChecklistData.product;
// // //     }
// // //
// // //     return AuditChecklistData.system;
// // //   }
// // //
// // //   Future<void> _loadSavedAnswers() async {
// // //     try {
// // //       final saved =
// // //       await AuditService.getAnswers(
// // //         widget.audit.auditId,
// // //       );
// // //
// // //       for (final row in saved) {
// // //         final id =
// // //         row['checklist_item_id']
// // //             .toString();
// // //
// // //         answers[id] =
// // //             row['answer']?.toString() ?? '';
// // //
// // //         descriptions[id] =
// // //             row['description']?.toString() ?? '';
// // //
// // //         final category =
// // //         row['finding_category'];
// // //
// // //         if (category != null) {
// // //           categories[id] =
// // //               FindingCategoryExtension
// // //                   .fromString(
// // //                 category.toString(),
// // //               );
// // //         }
// // //       }
// // //
// // //       if (mounted) {
// // //         setState(() {});
// // //       }
// // //     } catch (_) {}
// // //   }
// // //
// // //   Future<void> _saveCurrentSection() async {
// // //     setState(() {
// // //       saving = true;
// // //     });
// // //
// // //     try {
// // //       for (final item in items) {
// // //         final answer =
// // //         answers[item.id];
// // //
// // //         if (answer == null ||
// // //             answer.isEmpty) {
// // //           continue;
// // //         }
// // //
// // //         await AuditService.saveAnswer(
// // //           auditId: widget.audit.auditId,
// // //           section: item.section,
// // //           checklistItemId: item.id,
// // //           questionNumber: item.number,
// // //           question: item.question,
// // //           answer: answer,
// // //           description:
// // //           descriptions[item.id] ?? '',
// // //           category: categories[item.id],
// // //         );
// // //       }
// // //
// // //       await AuditService
// // //           .updateCurrentSection(
// // //         auditId: widget.audit.auditId,
// // //         section: sections[
// // //         currentSectionIndex],
// // //       );
// // //
// // //       if (mounted) {
// // //         ScaffoldMessenger.of(context)
// // //             .showSnackBar(
// // //           const SnackBar(
// // //             content: Text(
// // //               'Progress saved.',
// // //             ),
// // //           ),
// // //         );
// // //       }
// // //     } finally {
// // //       if (mounted) {
// // //         setState(() {
// // //           saving = false;
// // //         });
// // //       }
// // //     }
// // //   }
// // //
// // //   Future<void> _next() async {
// // //     await _saveCurrentSection();
// // //
// // //     if (currentSectionIndex <
// // //         sections.length - 1) {
// // //       setState(() {
// // //         currentSectionIndex++;
// // //       });
// // //
// // //       return;
// // //     }
// // //
// // //     await _finishAudit();
// // //   }
// // //
// // //   Future<void> _finishAudit() async {
// // //     final unanswered = items.where(
// // //           (item) =>
// // //       answers[item.id] == null ||
// // //           answers[item.id]!.isEmpty,
// // //     );
// // //
// // //     if (unanswered.isNotEmpty) {
// // //       ScaffoldMessenger.of(context)
// // //           .showSnackBar(
// // //         const SnackBar(
// // //           content: Text(
// // //             'Please answer all questions before completing the audit.',
// // //           ),
// // //         ),
// // //       );
// // //       return;
// // //     }
// // //
// // //     await _saveCurrentSection();
// // //
// // //     if (!mounted) return;
// // //
// // //     Navigator.pushReplacement(
// // //       context,
// // //       MaterialPageRoute(
// // //         builder: (_) =>
// // //             AuditMilScreen(
// // //               audit: widget.audit,
// // //             ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   void _answer(
// // //       AuditChecklistItem item,
// // //       String value,
// // //       ) {
// // //     setState(() {
// // //       answers[item.id] = value;
// // //
// // //       if (value == 'Yes') {
// // //         descriptions.remove(item.id);
// // //         categories.remove(item.id);
// // //       }
// // //     });
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     final section =
// // //     sections[currentSectionIndex];
// // //
// // //     return Scaffold(
// // //       backgroundColor:
// // //       const Color(0xFFF5F7FB),
// // //       appBar: AppBar(
// // //         title: Text(
// // //           '${widget.audit.auditType} / $section',
// // //         ),
// // //         backgroundColor: Colors.white,
// // //         foregroundColor:
// // //         const Color(0xFF172033),
// // //         elevation: 0,
// // //       ),
// // //       body: Column(
// // //         children: [
// // //           _progressBar(),
// // //           Expanded(
// // //             child: ListView.builder(
// // //               padding:
// // //               const EdgeInsets.all(25),
// // //               itemCount: items.length,
// // //               itemBuilder:
// // //                   (context, index) {
// // //                 return _questionCard(
// // //                   items[index],
// // //                 );
// // //               },
// // //             ),
// // //           ),
// // //           _bottomBar(),
// // //         ],
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _progressBar() {
// // //     return Padding(
// // //       padding:
// // //       const EdgeInsets.fromLTRB(
// // //         25,
// // //         20,
// // //         25,
// // //         5,
// // //       ),
// // //       child: Row(
// // //         children: List.generate(
// // //           sections.length,
// // //               (index) {
// // //             final active =
// // //                 index ==
// // //                     currentSectionIndex;
// // //
// // //             return Expanded(
// // //               child: Container(
// // //                 margin:
// // //                 const EdgeInsets.symmetric(
// // //                   horizontal: 3,
// // //                 ),
// // //                 height: 7,
// // //                 decoration: BoxDecoration(
// // //                   color: index <=
// // //                       currentSectionIndex
// // //                       ? const Color(
// // //                     0xFF3155D9,
// // //                   )
// // //                       : Colors.grey.shade300,
// // //                   borderRadius:
// // //                   BorderRadius.circular(5),
// // //                 ),
// // //               ),
// // //             );
// // //           },
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _questionCard(
// // //       AuditChecklistItem item,
// // //       ) {
// // //     final answer =
// // //     answers[item.id];
// // //
// // //     return Card(
// // //       margin:
// // //       const EdgeInsets.only(bottom: 15),
// // //       elevation: 0,
// // //       shape:
// // //       RoundedRectangleBorder(
// // //         borderRadius:
// // //         BorderRadius.circular(16),
// // //         side: const BorderSide(
// // //           color: Color(0xFFE4E8F0),
// // //         ),
// // //       ),
// // //       child: Padding(
// // //         padding:
// // //         const EdgeInsets.all(20),
// // //         child: Column(
// // //           crossAxisAlignment:
// // //           CrossAxisAlignment.start,
// // //           children: [
// // //             Row(
// // //               crossAxisAlignment:
// // //               CrossAxisAlignment.start,
// // //               children: [
// // //                 Container(
// // //                   width: 38,
// // //                   height: 38,
// // //                   alignment:
// // //                   Alignment.center,
// // //                   decoration: BoxDecoration(
// // //                     color:
// // //                     const Color(
// // //                       0xFFEFF3FF,
// // //                     ),
// // //                     borderRadius:
// // //                     BorderRadius.circular(
// // //                       10,
// // //                     ),
// // //                   ),
// // //                   child: Text(
// // //                     '${item.number}',
// // //                     style:
// // //                     const TextStyle(
// // //                       fontWeight:
// // //                       FontWeight.w800,
// // //                       color:
// // //                       Color(0xFF3155D9),
// // //                     ),
// // //                   ),
// // //                 ),
// // //                 const SizedBox(width: 15),
// // //                 Expanded(
// // //                   child: Text(
// // //                     item.question,
// // //                     style:
// // //                     const TextStyle(
// // //                       fontSize: 15,
// // //                       fontWeight:
// // //                       FontWeight.w600,
// // //                     ),
// // //                   ),
// // //                 ),
// // //               ],
// // //             ),
// // //             const SizedBox(height: 18),
// // //             Row(
// // //               children: [
// // //                 _answerButton(
// // //                   item,
// // //                   'Yes',
// // //                 ),
// // //                 const SizedBox(width: 10),
// // //                 _answerButton(
// // //                   item,
// // //                   'No',
// // //                 ),
// // //               ],
// // //             ),
// // //             if (answer == 'No')
// // //               _findingFields(item),
// // //           ],
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _answerButton(
// // //       AuditChecklistItem item,
// // //       String value,
// // //       ) {
// // //     final selected =
// // //         answers[item.id] == value;
// // //
// // //     return Expanded(
// // //       child: OutlinedButton(
// // //         onPressed: () =>
// // //             _answer(item, value),
// // //         style:
// // //         OutlinedButton.styleFrom(
// // //           backgroundColor: selected
// // //               ? value == 'Yes'
// // //               ? Colors.green
// // //               .withOpacity(.10)
// // //               : Colors.red
// // //               .withOpacity(.10)
// // //               : Colors.white,
// // //           side: BorderSide(
// // //             color: selected
// // //                 ? value == 'Yes'
// // //                 ? Colors.green
// // //                 : Colors.red
// // //                 : Colors.grey.shade300,
// // //           ),
// // //         ),
// // //         child: Text(
// // //           value,
// // //           style: TextStyle(
// // //             color: selected
// // //                 ? value == 'Yes'
// // //                 ? Colors.green.shade700
// // //                 : Colors.red.shade700
// // //                 : Colors.grey.shade700,
// // //             fontWeight:
// // //             FontWeight.w700,
// // //           ),
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   Widget _findingFields(
// // //       AuditChecklistItem item,
// // //       ) {
// // //     return Padding(
// // //       padding:
// // //       const EdgeInsets.only(top: 18),
// // //       child: Column(
// // //         crossAxisAlignment:
// // //         CrossAxisAlignment.start,
// // //         children: [
// // //           TextField(
// // //             maxLines: 4,
// // //             onChanged: (value) {
// // //               descriptions[item.id] =
// // //                   value;
// // //             },
// // //             controller: TextEditingController(
// // //               text:
// // //               descriptions[item.id] ?? '',
// // //             )..selection =
// // //             TextSelection.collapsed(
// // //               offset:
// // //               (descriptions[item.id] ??
// // //                   '')
// // //                   .length,
// // //             ),
// // //             decoration:
// // //             const InputDecoration(
// // //               labelText:
// // //               'Description / Finding',
// // //               border:
// // //               OutlineInputBorder(),
// // //             ),
// // //           ),
// // //           const SizedBox(height: 15),
// // //           DropdownButtonFormField<
// // //               FindingCategory>(
// // //             value:
// // //             categories[item.id],
// // //             decoration:
// // //             const InputDecoration(
// // //               labelText:
// // //               'Finding Category',
// // //               border:
// // //               OutlineInputBorder(),
// // //             ),
// // //             items:
// // //             FindingCategory.values
// // //                 .map(
// // //                   (category) {
// // //                 return DropdownMenuItem(
// // //                   value: category,
// // //                   child: Row(
// // //                     children: [
// // //                       Container(
// // //                         width: 11,
// // //                         height: 11,
// // //                         decoration:
// // //                         BoxDecoration(
// // //                           color:
// // //                           _categoryColor(
// // //                             category,
// // //                           ),
// // //                           shape:
// // //                           BoxShape.circle,
// // //                         ),
// // //                       ),
// // //                       const SizedBox(
// // //                         width: 10,
// // //                       ),
// // //                       Text(
// // //                         category.value,
// // //                       ),
// // //                     ],
// // //                   ),
// // //                 );
// // //               },
// // //             ).toList(),
// // //             onChanged: (value) {
// // //               if (value == null) return;
// // //
// // //               setState(() {
// // //                 categories[item.id] = value;
// // //               });
// // //             },
// // //           ),
// // //         ],
// // //       ),
// // //     );
// // //   }
// // //
// // //   Color _categoryColor(
// // //       FindingCategory category,
// // //       ) {
// // //     switch (category) {
// // //       case FindingCategory.critical:
// // //         return Colors.red;
// // //       case FindingCategory.major:
// // //         return Colors.orange;
// // //       case FindingCategory.minor:
// // //         return Colors.green;
// // //     }
// // //   }
// // //
// // //   Widget _bottomBar() {
// // //     final last =
// // //         currentSectionIndex ==
// // //             sections.length - 1;
// // //
// // //     return Container(
// // //       padding:
// // //       const EdgeInsets.all(18),
// // //       decoration:
// // //       const BoxDecoration(
// // //         color: Colors.white,
// // //         border: Border(
// // //           top: BorderSide(
// // //             color: Color(0xFFE4E8F0),
// // //           ),
// // //         ),
// // //       ),
// // //       child: Row(
// // //         children: [
// // //           OutlinedButton.icon(
// // //             onPressed: saving
// // //                 ? null
// // //                 : _saveCurrentSection,
// // //             icon: const Icon(
// // //               Icons.save,
// // //             ),
// // //             label: const Text(
// // //               'Save Progress',
// // //             ),
// // //           ),
// // //           const Spacer(),
// // //           if (currentSectionIndex > 0)
// // //             TextButton(
// // //               onPressed: saving
// // //                   ? null
// // //                   : () {
// // //                 setState(() {
// // //                   currentSectionIndex--;
// // //                 });
// // //               },
// // //               child:
// // //               const Text('Previous'),
// // //             ),
// // //           const SizedBox(width: 10),
// // //           ElevatedButton.icon(
// // //             onPressed:
// // //             saving ? null : _next,
// // //             icon: Icon(
// // //               last
// // //                   ? Icons.check
// // //                   : Icons.arrow_forward,
// // //             ),
// // //             label: Text(
// // //               last
// // //                   ? 'Complete Audit'
// // //                   : 'Continue',
// // //             ),
// // //           ),
// // //         ],
// // //       ),
// // //     );
// // //   }
// // // }
// //
// //
// // import 'package:flutter/material.dart';
// //
// // import '../../models/audit/audit.dart';
// // import '../../models/audit/audit_checklist_item.dart';
// // import '../../models/audit/audit_finding.dart';
// // import '../../services/audit/audit_checklist_data.dart';
// // import '../../services/audit/audit_service.dart';
// // import 'audit_mil_screen.dart';
// //
// // class AuditChecklistScreen
// //     extends StatefulWidget {
// //   final Audit audit;
// //   final List<String>? sections;
// //
// //   const AuditChecklistScreen({
// //     super.key,
// //     required this.audit,
// //     this.sections,
// //   });
// //
// //   @override
// //   State<AuditChecklistScreen>
// //   createState() =>
// //       _AuditChecklistScreenState();
// // }
// //
// // class _AuditChecklistScreenState
// //     extends State<AuditChecklistScreen> {
// //   late List<String> sections;
// //
// //   int currentSectionIndex = 0;
// //
// //   final Map<String, String> answers = {};
// //   final Map<String, String> descriptions = {};
// //
// //   final Map<String, FindingCategory>
// //   categories = {};
// //
// //   bool loading = true;
// //   bool saving = false;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //
// //     if (widget.audit.auditType ==
// //         'Process Audit') {
// //       sections = List<String>.from(
// //         widget.sections ??
// //             AuditChecklistData
// //                 .processSections,
// //       );
// //     } else if (widget.audit.auditType ==
// //         'Product Audit') {
// //       sections = ['Product Audit'];
// //     } else {
// //       sections = ['QMS System Audit'];
// //     }
// //
// //     if (sections.isEmpty) {
// //       sections = [
// //         widget.audit.auditType,
// //       ];
// //     }
// //
// //     _loadSavedAnswers();
// //   }
// //
// //   List<AuditChecklistItem> get items {
// //     final section =
// //     sections[currentSectionIndex];
// //
// //     if (widget.audit.auditType ==
// //         'Process Audit') {
// //       return AuditChecklistData
// //           .processItemsFor(section);
// //     }
// //
// //     if (widget.audit.auditType ==
// //         'Product Audit') {
// //       return AuditChecklistData.product;
// //     }
// //
// //     return AuditChecklistData.system;
// //   }
// //
// //   Future<void> _loadSavedAnswers() async {
// //     try {
// //       final saved =
// //       await AuditService.getAnswers(
// //         widget.audit.auditId,
// //       );
// //
// //       for (final row in saved) {
// //         final id =
// //         row['checklist_item_id']
// //             ?.toString();
// //
// //         if (id == null ||
// //             id.isEmpty) {
// //           continue;
// //         }
// //
// //         final answer =
// //             row['answer']?.toString() ?? '';
// //
// //         answers[id] = answer;
// //
// //         descriptions[id] =
// //             row['description']
// //                 ?.toString() ??
// //                 '';
// //
// //         final category =
// //         row['finding_category'];
// //
// //         if (category != null &&
// //             category.toString().isNotEmpty) {
// //           categories[id] =
// //               FindingCategoryExtension
// //                   .fromString(
// //                 category.toString(),
// //               );
// //         }
// //       }
// //
// //       final savedAudit =
// //       await AuditService.getAudit(
// //         widget.audit.auditId,
// //       );
// //
// //       if (savedAudit != null &&
// //           savedAudit.currentSection !=
// //               null) {
// //         final index =
// //         sections.indexOf(
// //           savedAudit.currentSection!,
// //         );
// //
// //         if (index >= 0) {
// //           currentSectionIndex =
// //               index;
// //         }
// //       }
// //     } catch (e) {
// //       if (mounted) {
// //         _showMessage(
// //           'Unable to load saved audit progress.\n$e',
// //         );
// //       }
// //     } finally {
// //       if (mounted) {
// //         setState(() {
// //           loading = false;
// //         });
// //       }
// //     }
// //   }
// //
// //   Future<bool> _saveCurrentSection({
// //     bool showMessage = true,
// //   }) async {
// //     if (saving) {
// //       return false;
// //     }
// //
// //     setState(() {
// //       saving = true;
// //     });
// //
// //     try {
// //       for (final item in items) {
// //         final answer =
// //         answers[item.id];
// //
// //         if (answer == null ||
// //             answer.isEmpty) {
// //           continue;
// //         }
// //
// //         await AuditService.saveAnswer(
// //           auditId:
// //           widget.audit.auditId,
// //           section: item.section,
// //           checklistItemId: item.id,
// //           questionNumber: item.number,
// //           question: item.question,
// //           answer: answer,
// //           description:
// //           descriptions[item.id] ?? '',
// //           category: categories[item.id],
// //         );
// //       }
// //
// //       await AuditService
// //           .updateCurrentSection(
// //         auditId:
// //         widget.audit.auditId,
// //         section:
// //         sections[currentSectionIndex],
// //       );
// //
// //       if (showMessage &&
// //           mounted) {
// //         _showMessage(
// //           'Progress saved successfully.',
// //         );
// //       }
// //
// //       return true;
// //     } catch (e) {
// //       if (mounted) {
// //         _showMessage(
// //           'Unable to save progress.\n$e',
// //         );
// //       }
// //
// //       return false;
// //     } finally {
// //       if (mounted) {
// //         setState(() {
// //           saving = false;
// //         });
// //       }
// //     }
// //   }
// //
// //   bool _validateCurrentSection() {
// //     for (final item in items) {
// //       final answer =
// //       answers[item.id];
// //
// //       if (answer == null ||
// //           answer.isEmpty) {
// //         _showMessage(
// //           'Please answer question ${item.number}.',
// //         );
// //         return false;
// //       }
// //
// //       if (answer == 'No') {
// //         final description =
// //             descriptions[item.id]
// //                 ?.trim() ??
// //                 '';
// //
// //         final category =
// //         categories[item.id];
// //
// //         if (description.isEmpty) {
// //           _showMessage(
// //             'Please enter the description/finding for question ${item.number}.',
// //           );
// //           return false;
// //         }
// //
// //         if (category == null) {
// //           _showMessage(
// //             'Please select the finding category for question ${item.number}.',
// //           );
// //           return false;
// //         }
// //       }
// //     }
// //
// //     return true;
// //   }
// //
// //   Future<void> _next() async {
// //     if (!_validateCurrentSection()) {
// //       return;
// //     }
// //
// //     final saved =
// //     await _saveCurrentSection(
// //       showMessage: false,
// //     );
// //
// //     if (!saved || !mounted) {
// //       return;
// //     }
// //
// //     if (currentSectionIndex <
// //         sections.length - 1) {
// //       setState(() {
// //         currentSectionIndex++;
// //       });
// //
// //       await AuditService
// //           .updateCurrentSection(
// //         auditId:
// //         widget.audit.auditId,
// //         section:
// //         sections[currentSectionIndex],
// //       );
// //
// //       return;
// //     }
// //
// //     await _openMilScreen();
// //   }
// //
// //   Future<void> _openMilScreen() async {
// //     final saved =
// //     await _saveCurrentSection(
// //       showMessage: false,
// //     );
// //
// //     if (!saved || !mounted) {
// //       return;
// //     }
// //
// //     Navigator.pushReplacement(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) =>
// //             AuditMilScreen(
// //               audit: widget.audit,
// //             ),
// //       ),
// //     );
// //   }
// //
// //   void _answer(
// //       AuditChecklistItem item,
// //       String value,
// //       ) {
// //     setState(() {
// //       answers[item.id] = value;
// //
// //       if (value == 'Yes') {
// //         descriptions.remove(item.id);
// //         categories.remove(item.id);
// //       }
// //     });
// //   }
// //
// //   void _showMessage(String message) {
// //     ScaffoldMessenger.of(context)
// //         .showSnackBar(
// //       SnackBar(
// //         content: Text(message),
// //         behavior:
// //         SnackBarBehavior.floating,
// //       ),
// //     );
// //   }
// //
// //   Color _categoryColor(
// //       FindingCategory category) {
// //     switch (category) {
// //       case FindingCategory.critical:
// //         return Colors.red;
// //       case FindingCategory.major:
// //         return Colors.orange;
// //       case FindingCategory.minor:
// //         return Colors.green;
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     if (loading) {
// //       return Scaffold(
// //         backgroundColor:
// //         const Color(0xFFF5F7FB),
// //         body: const Center(
// //           child:
// //           CircularProgressIndicator(),
// //         ),
// //       );
// //     }
// //
// //     final section =
// //     sections[currentSectionIndex];
// //
// //     return Scaffold(
// //       backgroundColor:
// //       const Color(0xFFF5F7FB),
// //
// //       appBar: AppBar(
// //         title: Text(
// //           widget.audit.auditType,
// //           style: const TextStyle(
// //             fontWeight:
// //             FontWeight.w700,
// //           ),
// //         ),
// //         backgroundColor: Colors.white,
// //         foregroundColor:
// //         const Color(0xFF172033),
// //         elevation: 0,
// //
// //         actions: [
// //           Padding(
// //             padding:
// //             const EdgeInsets.only(
// //               right: 18,
// //             ),
// //             child: Center(
// //               child: Text(
// //                 '${currentSectionIndex + 1}/${sections.length}',
// //                 style:
// //                 const TextStyle(
// //                   fontWeight:
// //                   FontWeight.w700,
// //                   color:
// //                   Color(0xFF6B7280),
// //                 ),
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //
// //       body: Column(
// //         children: [
// //           _header(section),
// //           _progressBar(),
// //
// //           Expanded(
// //             child: ListView.builder(
// //               padding:
// //               const EdgeInsets.fromLTRB(
// //                 28,
// //                 15,
// //                 28,
// //                 30,
// //               ),
// //               itemCount: items.length,
// //               itemBuilder:
// //                   (context, index) {
// //                 return _questionCard(
// //                   items[index],
// //                 );
// //               },
// //             ),
// //           ),
// //
// //           _bottomBar(),
// //         ],
// //       ),
// //     );
// //   }
// //
// //   Widget _header(String section) {
// //     return Container(
// //       width: double.infinity,
// //       color: Colors.white,
// //
// //       padding:
// //       const EdgeInsets.fromLTRB(
// //         28,
// //         22,
// //         28,
// //         20,
// //       ),
// //
// //       child: Center(
// //         child: ConstrainedBox(
// //           constraints:
// //           const BoxConstraints(
// //             maxWidth: 1100,
// //           ),
// //
// //           child: Row(
// //             children: [
// //               Container(
// //                 width: 46,
// //                 height: 46,
// //                 decoration:
// //                 BoxDecoration(
// //                   color:
// //                   const Color(
// //                     0xFFEFF3FF,
// //                   ),
// //                   borderRadius:
// //                   BorderRadius.circular(
// //                     12,
// //                   ),
// //                 ),
// //                 child: const Icon(
// //                   Icons.fact_check_outlined,
// //                   color:
// //                   Color(0xFF3155D9),
// //                 ),
// //               ),
// //
// //               const SizedBox(width: 14),
// //
// //               Expanded(
// //                 child: Column(
// //                   crossAxisAlignment:
// //                   CrossAxisAlignment.start,
// //                   children: [
// //                     Text(
// //                       section,
// //                       style:
// //                       const TextStyle(
// //                         fontSize: 20,
// //                         fontWeight:
// //                         FontWeight.w800,
// //                       ),
// //                     ),
// //                     const SizedBox(
// //                       height: 4,
// //                     ),
// //                     const Text(
// //                       'Answer every checklist item. Select No to record a finding.',
// //                       style:
// //                       TextStyle(
// //                         color:
// //                         Color(0xFF6B7280),
// //                       ),
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _progressBar() {
// //     return Padding(
// //       padding:
// //       const EdgeInsets.fromLTRB(
// //         28,
// //         18,
// //         28,
// //         8,
// //       ),
// //
// //       child: Row(
// //         children: List.generate(
// //           sections.length,
// //               (index) {
// //             final completed =
// //                 index <
// //                     currentSectionIndex;
// //
// //             final active =
// //                 index ==
// //                     currentSectionIndex;
// //
// //             return Expanded(
// //               child: Container(
// //                 margin:
// //                 const EdgeInsets
// //                     .symmetric(
// //                   horizontal: 3,
// //                 ),
// //                 height: 7,
// //
// //                 decoration:
// //                 BoxDecoration(
// //                   color: completed ||
// //                       active
// //                       ? const Color(
// //                     0xFF3155D9,
// //                   )
// //                       : Colors.grey
// //                       .shade300,
// //                   borderRadius:
// //                   BorderRadius.circular(
// //                     5,
// //                   ),
// //                 ),
// //               ),
// //             );
// //           },
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _questionCard(
// //       AuditChecklistItem item) {
// //     final answer =
// //     answers[item.id];
// //
// //     return Card(
// //       margin:
// //       const EdgeInsets.only(
// //         bottom: 16,
// //       ),
// //       elevation: 0,
// //
// //       shape:
// //       RoundedRectangleBorder(
// //         borderRadius:
// //         BorderRadius.circular(
// //           16,
// //         ),
// //         side: const BorderSide(
// //           color: Color(0xFFE4E8F0),
// //         ),
// //       ),
// //
// //       child: Padding(
// //         padding:
// //         const EdgeInsets.all(22),
// //
// //         child: Column(
// //           crossAxisAlignment:
// //           CrossAxisAlignment.start,
// //
// //           children: [
// //             Row(
// //               crossAxisAlignment:
// //               CrossAxisAlignment.start,
// //
// //               children: [
// //                 Container(
// //                   width: 40,
// //                   height: 40,
// //
// //                   alignment:
// //                   Alignment.center,
// //
// //                   decoration:
// //                   BoxDecoration(
// //                     color:
// //                     const Color(
// //                       0xFFEFF3FF,
// //                     ),
// //                     borderRadius:
// //                     BorderRadius.circular(
// //                       10,
// //                     ),
// //                   ),
// //
// //                   child: Text(
// //                     '${item.number}',
// //                     style:
// //                     const TextStyle(
// //                       color:
// //                       Color(0xFF3155D9),
// //                       fontWeight:
// //                       FontWeight.w800,
// //                     ),
// //                   ),
// //                 ),
// //
// //                 const SizedBox(width: 15),
// //
// //                 Expanded(
// //                   child: Text(
// //                     item.question,
// //                     style:
// //                     const TextStyle(
// //                       fontSize: 15,
// //                       height: 1.45,
// //                       fontWeight:
// //                       FontWeight.w600,
// //                     ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             const SizedBox(height: 18),
// //
// //             Row(
// //               children: [
// //                 Expanded(
// //                   child: _answerButton(
// //                     item,
// //                     'Yes',
// //                   ),
// //                 ),
// //
// //                 const SizedBox(
// //                   width: 12,
// //                 ),
// //
// //                 Expanded(
// //                   child: _answerButton(
// //                     item,
// //                     'No',
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             if (answer == 'No')
// //               _findingFields(item),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _answerButton(
// //       AuditChecklistItem item,
// //       String value,
// //       ) {
// //     final selected =
// //         answers[item.id] == value;
// //
// //     final yes = value == 'Yes';
// //
// //     return OutlinedButton(
// //       onPressed: saving
// //           ? null
// //           : () => _answer(
// //         item,
// //         value,
// //       ),
// //
// //       style:
// //       OutlinedButton.styleFrom(
// //         minimumSize:
// //         const Size.fromHeight(
// //           48,
// //         ),
// //
// //         backgroundColor:
// //         selected
// //             ? (yes
// //             ? Colors.green
// //             .withOpacity(.10)
// //             : Colors.red
// //             .withOpacity(.10))
// //             : Colors.white,
// //
// //         side: BorderSide(
// //           width: selected ? 1.5 : 1,
// //           color: selected
// //               ? (yes
// //               ? Colors.green
// //               : Colors.red)
// //               : Colors.grey.shade300,
// //         ),
// //
// //         shape:
// //         RoundedRectangleBorder(
// //           borderRadius:
// //           BorderRadius.circular(
// //             10,
// //           ),
// //         ),
// //       ),
// //
// //       child: Text(
// //         value,
// //         style: TextStyle(
// //           color: selected
// //               ? (yes
// //               ? Colors.green.shade700
// //               : Colors.red.shade700)
// //               : Colors.grey.shade700,
// //           fontWeight:
// //           FontWeight.w700,
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _findingFields(
// //       AuditChecklistItem item) {
// //     return Padding(
// //       padding:
// //       const EdgeInsets.only(
// //         top: 18,
// //       ),
// //
// //       child: Container(
// //         padding:
// //         const EdgeInsets.all(18),
// //
// //         decoration:
// //         BoxDecoration(
// //           color:
// //           const Color(0xFFFFF8F8),
// //           borderRadius:
// //           BorderRadius.circular(
// //             12,
// //           ),
// //           border: Border.all(
// //             color:
// //             Colors.red.shade100,
// //           ),
// //         ),
// //
// //         child: Column(
// //           crossAxisAlignment:
// //           CrossAxisAlignment.start,
// //
// //           children: [
// //             Row(
// //               children: [
// //                 const Icon(
// //                   Icons.warning_amber_rounded,
// //                   color: Colors.red,
// //                 ),
// //                 const SizedBox(
// //                   width: 8,
// //                 ),
// //                 const Text(
// //                   'Finding Details',
// //                   style:
// //                   TextStyle(
// //                     fontWeight:
// //                     FontWeight.w800,
// //                     color: Colors.red,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //
// //             const SizedBox(height: 14),
// //
// //             TextFormField(
// //               initialValue:
// //               descriptions[item.id] ??
// //                   '',
// //               maxLines: 4,
// //
// //               onChanged: (value) {
// //                 descriptions[item.id] =
// //                     value;
// //               },
// //
// //               decoration:
// //               const InputDecoration(
// //                 labelText:
// //                 'Description / Finding',
// //                 hintText:
// //                 'Enter the finding description...',
// //                 border:
// //                 OutlineInputBorder(),
// //                 alignLabelWithHint: true,
// //               ),
// //             ),
// //
// //             const SizedBox(height: 14),
// //
// //             DropdownButtonFormField<
// //                 FindingCategory>(
// //               value:
// //               categories[item.id],
// //
// //               decoration:
// //               const InputDecoration(
// //                 labelText:
// //                 'Finding Category',
// //                 border:
// //                 OutlineInputBorder(),
// //               ),
// //
// //               items: FindingCategory
// //                   .values
// //                   .map(
// //                     (category) {
// //                   return DropdownMenuItem<
// //                       FindingCategory>(
// //                     value: category,
// //
// //                     child: Row(
// //                       children: [
// //                         Container(
// //                           width: 11,
// //                           height: 11,
// //                           decoration:
// //                           BoxDecoration(
// //                             color:
// //                             _categoryColor(
// //                               category,
// //                             ),
// //                             shape:
// //                             BoxShape
// //                                 .circle,
// //                           ),
// //                         ),
// //
// //                         const SizedBox(
// //                           width: 10,
// //                         ),
// //
// //                         Text(
// //                           category.value,
// //                           style:
// //                           const TextStyle(
// //                             fontWeight:
// //                             FontWeight.w600,
// //                           ),
// //                         ),
// //                       ],
// //                     ),
// //                   );
// //                 },
// //               ).toList(),
// //
// //               onChanged: saving
// //                   ? null
// //                   : (value) {
// //                 if (value ==
// //                     null) {
// //                   return;
// //                 }
// //
// //                 setState(() {
// //                   categories[
// //                   item.id] =
// //                       value;
// //                 });
// //               },
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _bottomBar() {
// //     final last =
// //         currentSectionIndex ==
// //             sections.length - 1;
// //
// //     return Container(
// //       padding:
// //       const EdgeInsets.fromLTRB(
// //         24,
// //         14,
// //         24,
// //         14,
// //       ),
// //
// //       decoration:
// //       const BoxDecoration(
// //         color: Colors.white,
// //         border: Border(
// //           top: BorderSide(
// //             color: Color(0xFFE4E8F0),
// //           ),
// //         ),
// //       ),
// //
// //       child: Center(
// //         child: ConstrainedBox(
// //           constraints:
// //           const BoxConstraints(
// //             maxWidth: 1100,
// //           ),
// //
// //           child: Row(
// //             children: [
// //               OutlinedButton.icon(
// //                 onPressed: saving
// //                     ? null
// //                     : () =>
// //                     _saveCurrentSection(),
// //
// //                 icon: const Icon(
// //                   Icons.save_outlined,
// //                 ),
// //
// //                 label: const Text(
// //                   'Save Progress',
// //                 ),
// //               ),
// //
// //               const Spacer(),
// //
// //               ElevatedButton.icon(
// //                 onPressed:
// //                 saving ? null : _next,
// //
// //                 icon: Icon(
// //                   last
// //                       ? Icons
// //                       .arrow_forward
// //                       : Icons
// //                       .arrow_forward,
// //                 ),
// //
// //                 label: Text(
// //                   last
// //                       ? 'Continue to MIL'
// //                       : 'Save & Next Section',
// //                 ),
// //
// //                 style:
// //                 ElevatedButton.styleFrom(
// //                   minimumSize:
// //                   const Size(
// //                     210,
// //                     48,
// //                   ),
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
//
// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_checklist_item.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_checklist_data.dart';
// import '../../services/audit/audit_service.dart';
//
// class AuditChecklistScreen
//     extends StatefulWidget {
//   final Audit audit;
//
//   // Exactly ONE category.
//   final String section;
//
//   const AuditChecklistScreen({
//     super.key,
//     required this.audit,
//     required this.section,
//   });
//
//   @override
//   State<AuditChecklistScreen>
//   createState() =>
//       _AuditChecklistScreenState();
// }
//
// class _AuditChecklistScreenState
//     extends State<AuditChecklistScreen> {
//   final Map<String, String> answers =
//   {};
//
//   final Map<String, String> descriptions =
//   {};
//
//   final Map<String, FindingCategory>
//   categories = {};
//
//   bool loading = true;
//   bool saving = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadSavedAnswers();
//   }
//
//   // ============================================================
//   // CHECKLIST ITEMS
//   // ============================================================
//
//   List<AuditChecklistItem>
//   get items {
//     switch (widget.audit.auditType) {
//       case 'Process Audit':
//         return AuditChecklistData
//             .processItemsFor(
//           widget.section,
//         );
//
//       case 'System Audit':
//         return AuditChecklistData.system;
//
//       case 'Product Audit':
//         return AuditChecklistData.product;
//
//       default:
//         return [];
//     }
//   }
//
//   // ============================================================
//   // STORAGE ID
//   // ============================================================
//
//   String _storageId(
//       AuditChecklistItem item) {
//     return AuditService
//         .checklistStorageId(
//       auditType:
//       widget.audit.auditType,
//       category:
//       widget.section,
//       itemId: item.id,
//     );
//   }
//
//   // ============================================================
//   // LOAD SAVED ANSWERS
//   // ============================================================
//
//   Future<void> _loadSavedAnswers() async {
//     try {
//       final saved =
//       await AuditService.getAnswersForCategory(
//         auditId:
//         widget.audit.auditId,
//         category:
//         widget.section,
//       );
//
//       for (final row in saved) {
//         final id =
//         row['checklist_item_id']
//             ?.toString();
//
//         if (id == null ||
//             id.isEmpty) {
//           continue;
//         }
//
//         answers[id] =
//             row['answer']
//                 ?.toString() ??
//                 '';
//
//         descriptions[id] =
//             row['description']
//                 ?.toString() ??
//                 '';
//
//         final category =
//         row['finding_category']
//             ?.toString();
//
//         if (category != null &&
//             category.isNotEmpty) {
//           categories[id] =
//               FindingCategoryExtension
//                   .fromString(
//                 category,
//               );
//         }
//       }
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           'Unable to load saved progress.\n$e',
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // VALIDATE CATEGORY
//   //
//   // Every question must be answered.
//   //
//   // If answer is No:
//   //   Description required
//   //   Finding category required
//   // ============================================================
//
//   bool _validateCategory() {
//     for (final item in items) {
//       final id =
//       _storageId(item);
//
//       final answer =
//       answers[id];
//
//       if (answer == null ||
//           answer.isEmpty) {
//         _showMessage(
//           'Please answer question ${item.number}.',
//         );
//
//         return false;
//       }
//
//       if (answer != 'Yes' &&
//           answer != 'No') {
//         _showMessage(
//           'Invalid answer for question ${item.number}.',
//         );
//
//         return false;
//       }
//
//       if (answer == 'No') {
//         final description =
//             descriptions[id]
//                 ?.trim() ??
//                 '';
//
//         final category =
//         categories[id];
//
//         if (description.isEmpty) {
//           _showMessage(
//             'Please enter the description/finding for question ${item.number}.',
//           );
//
//           return false;
//         }
//
//         if (category == null) {
//           _showMessage(
//             'Please select the finding category for question ${item.number}.',
//           );
//
//           return false;
//         }
//       }
//     }
//
//     return true;
//   }
//
//   // ============================================================
//   // SAVE CATEGORY
//   //
//   // Saving a category does NOT open MIL.
//   //
//   // It saves the category and returns to the category list.
//   // ============================================================
//
//   Future<void> _saveCategory({
//     required bool validate,
//   }) async {
//     if (saving) {
//       return;
//     }
//
//     if (validate &&
//         !_validateCategory()) {
//       return;
//     }
//
//     setState(() {
//       saving = true;
//     });
//
//     try {
//       for (final item in items) {
//         final id =
//         _storageId(item);
//
//         final answer =
//         answers[id];
//
//         // Only persist answered questions.
//         // This allows progress to exist even
//         // before the category is complete.
//         if (answer == null ||
//             answer.isEmpty) {
//           continue;
//         }
//
//         await AuditService.saveAnswer(
//           auditId:
//           widget.audit.auditId,
//           section:
//           widget.section,
//           checklistItemId:
//           id,
//           questionNumber:
//           item.number,
//           question:
//           item.question,
//           answer:
//           answer,
//           description:
//           descriptions[id] ??
//               '',
//           category:
//           categories[id],
//         );
//       }
//
//       await AuditService.updateCurrentSection(
//         auditId:
//         widget.audit.auditId,
//         section:
//         widget.section,
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       Navigator.pop(context);
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           'Unable to save category.\n$e',
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           saving = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // ANSWER
//   // ============================================================
//
//   void _answer(
//       AuditChecklistItem item,
//       String value) {
//     final id =
//     _storageId(item);
//
//     setState(() {
//       answers[id] = value;
//
//       if (value == 'Yes') {
//         descriptions.remove(id);
//         categories.remove(id);
//       }
//     });
//   }
//
//   // ============================================================
//   // FINDING CATEGORY COLOR
//   // ============================================================
//
//   Color _categoryColor(
//       FindingCategory category) {
//     switch (category) {
//       case FindingCategory.critical:
//         return Colors.red;
//
//       case FindingCategory.major:
//         return Colors.orange;
//
//       case FindingCategory.minor:
//         return Colors.green;
//     }
//   }
//
//   void _showMessage(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content: Text(message),
//         behavior:
//         SnackBarBehavior.floating,
//       ),
//     );
//   }
//
//   // ============================================================
//   // BUILD
//   // ============================================================
//
//   @override
//   Widget build(
//       BuildContext context) {
//     return Scaffold(
//       backgroundColor:
//       const Color(0xFFF5F7FB),
//
//       appBar: AppBar(
//         title: Text(
//           widget.section,
//           style:
//           const TextStyle(
//             fontWeight:
//             FontWeight.w700,
//           ),
//         ),
//
//         backgroundColor:
//         Colors.white,
//
//         foregroundColor:
//         const Color(0xFF172033),
//
//         elevation: 0,
//       ),
//
//       body: loading
//           ? const Center(
//         child:
//         CircularProgressIndicator(),
//       )
//           : Column(
//         children: [
//           _header(),
//
//           Expanded(
//             child:
//             ListView.builder(
//               padding:
//               const EdgeInsets.fromLTRB(
//                 24,
//                 10,
//                 24,
//                 24,
//               ),
//
//               itemCount:
//               items.length,
//
//               itemBuilder:
//                   (context, index) {
//                 return _questionCard(
//                   items[index],
//                 );
//               },
//             ),
//           ),
//
//           _bottomBar(),
//         ],
//       ),
//     );
//   }
//
//   // ============================================================
//   // HEADER
//   // ============================================================
//
//   Widget _header() {
//     final answeredCount =
//         items.where(
//               (item) {
//             final id =
//             _storageId(item);
//
//             final answer =
//             answers[id];
//
//             return answer == 'Yes' ||
//                 answer == 'No';
//           },
//         ).length;
//
//     final total =
//         items.length;
//
//     final progress =
//     total == 0
//         ? 0.0
//         : answeredCount / total;
//
//     return Container(
//       width:
//       double.infinity,
//
//       color:
//       Colors.white,
//
//       padding:
//       const EdgeInsets.fromLTRB(
//         24,
//         20,
//         24,
//         18,
//       ),
//
//       child: Center(
//         child: ConstrainedBox(
//           constraints:
//           const BoxConstraints(
//             maxWidth: 1100,
//           ),
//
//           child: Column(
//             crossAxisAlignment:
//             CrossAxisAlignment.start,
//
//             children: [
//               Text(
//                 widget.audit.auditType,
//                 style:
//                 const TextStyle(
//                   color:
//                   Color(0xFF6B7280),
//                   fontSize: 13,
//                   fontWeight:
//                   FontWeight.w600,
//                 ),
//               ),
//
//               const SizedBox(
//                 height: 4,
//               ),
//
//               Text(
//                 widget.section,
//                 style:
//                 const TextStyle(
//                   fontSize: 22,
//                   fontWeight:
//                   FontWeight.w800,
//                 ),
//               ),
//
//               const SizedBox(
//                 height: 14,
//               ),
//
//               Row(
//                 children: [
//                   Expanded(
//                     child:
//                     LinearProgressIndicator(
//                       value:
//                       progress,
//                       minHeight: 7,
//                       borderRadius:
//                       BorderRadius.circular(
//                         10,
//                       ),
//                     ),
//                   ),
//
//                   const SizedBox(
//                     width: 14,
//                   ),
//
//                   Text(
//                     '$answeredCount / $total answered',
//                     style:
//                     const TextStyle(
//                       fontWeight:
//                       FontWeight.w700,
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   // ============================================================
//   // QUESTION CARD
//   // ============================================================
//
//   Widget _questionCard(
//       AuditChecklistItem item) {
//     final id =
//     _storageId(item);
//
//     final answer =
//     answers[id];
//
//     final isNo =
//         answer == 'No';
//
//     return Card(
//       elevation: 0,
//
//       margin:
//       const EdgeInsets.only(
//         bottom: 14,
//       ),
//
//       shape:
//       RoundedRectangleBorder(
//         borderRadius:
//         BorderRadius.circular(16),
//
//         side:
//         const BorderSide(
//           color:
//           Color(0xFFE4E8F0),
//         ),
//       ),
//
//       child: Padding(
//         padding:
//         const EdgeInsets.all(20),
//
//         child: Column(
//           crossAxisAlignment:
//           CrossAxisAlignment.start,
//
//           children: [
//             Row(
//               crossAxisAlignment:
//               CrossAxisAlignment.start,
//
//               children: [
//                 Container(
//                   width: 38,
//                   height: 38,
//
//                   decoration:
//                   BoxDecoration(
//                     color:
//                     const Color(
//                       0xFFEFF3FF,
//                     ),
//                     borderRadius:
//                     BorderRadius.circular(
//                       10,
//                     ),
//                   ),
//
//                   child: Center(
//                     child: Text(
//                       '${item.number}',
//                       style:
//                       const TextStyle(
//                         fontWeight:
//                         FontWeight.w800,
//                         color:
//                         Color(
//                           0xFF3155D9,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 14,
//                 ),
//
//                 Expanded(
//                   child: Text(
//                     item.question,
//                     style:
//                     const TextStyle(
//                       fontSize: 16,
//                       height: 1.45,
//                       fontWeight:
//                       FontWeight.w600,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//
//             const SizedBox(
//               height: 18,
//             ),
//
//             Row(
//               children: [
//                 Expanded(
//                   child:
//                   _answerButton(
//                     label: 'Yes',
//                     selected:
//                     answer == 'Yes',
//                     icon:
//                     Icons.check_circle_outline,
//                     onTap:
//                     saving
//                         ? null
//                         : () => _answer(
//                       item,
//                       'Yes',
//                     ),
//                   ),
//                 ),
//
//                 const SizedBox(
//                   width: 12,
//                 ),
//
//                 Expanded(
//                   child:
//                   _answerButton(
//                     label: 'No',
//                     selected:
//                     answer == 'No',
//                     icon:
//                     Icons.cancel_outlined,
//                     onTap:
//                     saving
//                         ? null
//                         : () => _answer(
//                       item,
//                       'No',
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//
//             if (isNo) ...[
//               const SizedBox(
//                 height: 18,
//               ),
//
//               TextField(
//                 controller:
//                 TextEditingController(
//                   text:
//                   descriptions[id] ??
//                       '',
//                 ),
//                 maxLines: 4,
//
//                 onChanged:
//                     (value) {
//                   descriptions[id] =
//                       value;
//                 },
//
//                 decoration:
//                 const InputDecoration(
//                   labelText:
//                   'Description / Finding',
//                   hintText:
//                   'Describe the issue or finding...',
//                   border:
//                   OutlineInputBorder(),
//                   alignLabelWithHint:
//                   true,
//                 ),
//               ),
//
//               const SizedBox(
//                 height: 15,
//               ),
//
//               DropdownButtonFormField<
//                   FindingCategory>(
//                 value:
//                 categories[id],
//
//                 decoration:
//                 const InputDecoration(
//                   labelText:
//                   'Finding Category',
//                   border:
//                   OutlineInputBorder(),
//                 ),
//
//                 items:
//                 FindingCategory
//                     .values
//                     .map(
//                       (category) {
//                     return DropdownMenuItem<
//                         FindingCategory>(
//                       value:
//                       category,
//
//                       child: Row(
//                         children: [
//                           Container(
//                             width: 11,
//                             height: 11,
//
//                             decoration:
//                             BoxDecoration(
//                               color:
//                               _categoryColor(
//                                 category,
//                               ),
//                               shape:
//                               BoxShape.circle,
//                             ),
//                           ),
//
//                           const SizedBox(
//                             width: 10,
//                           ),
//
//                           Text(
//                             category.value,
//                             style:
//                             const TextStyle(
//                               fontWeight:
//                               FontWeight.w600,
//                             ),
//                           ),
//                         ],
//                       ),
//                     );
//                   },
//                 )
//                     .toList(),
//
//                 onChanged:
//                 saving
//                     ? null
//                     : (value) {
//                   if (value ==
//                       null) {
//                     return;
//                   }
//
//                   setState(() {
//                     categories[id] =
//                         value;
//                   });
//                 },
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _answerButton({
//     required String label,
//     required bool selected,
//     required IconData icon,
//     required VoidCallback? onTap,
//   }) {
//     return OutlinedButton.icon(
//       onPressed: onTap,
//
//       icon: Icon(
//         icon,
//         color: selected
//             ? const Color(
//           0xFF3155D9,
//         )
//             : const Color(
//           0xFF6B7280,
//         ),
//       ),
//
//       label: Text(
//         label,
//         style: TextStyle(
//           fontWeight:
//           FontWeight.w700,
//           color: selected
//               ? const Color(
//             0xFF3155D9,
//           )
//               : const Color(
//             0xFF374151,
//           ),
//         ),
//       ),
//
//       style:
//       OutlinedButton.styleFrom(
//         minimumSize:
//         const Size(
//           0,
//           48,
//         ),
//
//         side: BorderSide(
//           color: selected
//               ? const Color(
//             0xFF3155D9,
//           )
//               : const Color(
//             0xFFD7DCE5,
//           ),
//           width:
//           selected ? 1.5 : 1,
//         ),
//
//         backgroundColor:
//         selected
//             ? const Color(
//           0xFFEFF3FF,
//         )
//             : Colors.white,
//       ),
//     );
//   }
//
//   // ============================================================
//   // BOTTOM BAR
//   // ============================================================
//
//   Widget _bottomBar() {
//     return Container(
//       padding:
//       const EdgeInsets.fromLTRB(
//         24,
//         14,
//         24,
//         14,
//       ),
//
//       decoration:
//       const BoxDecoration(
//         color: Colors.white,
//
//         border:
//         Border(
//           top:
//           BorderSide(
//             color:
//             Color(0xFFE4E8F0),
//           ),
//         ),
//       ),
//
//       child: Center(
//         child: ConstrainedBox(
//           constraints:
//           const BoxConstraints(
//             maxWidth: 1100,
//           ),
//
//           child: Row(
//             children: [
//               OutlinedButton.icon(
//                 onPressed:
//                 saving
//                     ? null
//                     : () =>
//                     _saveCategory(
//                       validate: false,
//                     ),
//
//                 icon:
//                 const Icon(
//                   Icons.save_outlined,
//                 ),
//
//                 label:
//                 const Text(
//                   'Save Progress',
//                 ),
//               ),
//
//               const Spacer(),
//
//               ElevatedButton.icon(
//                 onPressed:
//                 saving
//                     ? null
//                     : () =>
//                     _saveCategory(
//                       validate: true,
//                     ),
//
//                 icon:
//                 saving
//                     ? const SizedBox(
//                   width: 19,
//                   height: 19,
//                   child:
//                   CircularProgressIndicator(
//                     strokeWidth: 2,
//                   ),
//                 )
//                     : const Icon(
//                   Icons.check,
//                 ),
//
//                 label:
//                 Text(
//                   saving
//                       ? 'Saving...'
//                       : 'Save & Return',
//                 ),
//
//                 style:
//                 ElevatedButton.styleFrom(
//                   minimumSize:
//                   const Size(
//                     190,
//                     48,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



// import 'dart:async';
//
// import 'package:flutter/material.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_checklist_item.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_checklist_data.dart';
// import '../../services/audit/audit_service.dart';
//
// class AuditChecklistScreen
//     extends StatefulWidget {
//   final Audit audit;
//
//   /// Exactly ONE category.
//   final String section;
//
//   const AuditChecklistScreen({
//     super.key,
//     required this.audit,
//     required this.section,
//   });
//
//   @override
//   State<AuditChecklistScreen>
//   createState() =>
//       _AuditChecklistScreenState();
// }
//
// class _AuditChecklistScreenState
//     extends State<AuditChecklistScreen> {
//   final Map<String, String>
//   answers = {};
//
//   final Map<String, String>
//   descriptions = {};
//
//   final Map<String, FindingCategory>
//   categories = {};
//
//   bool loading = true;
//   bool saving = false;
//
//   // ============================================================
//   // INIT
//   // ============================================================
//
//   @override
//   void initState() {
//     super.initState();
//
//     _loadCategory();
//   }
//   // Future<void> _loadCategory() async {
//   //   try {
//   //     await _loadSavedAnswers();
//   //   } catch (e) {
//   //     if (mounted) {
//   //       _showMessage(
//   //         'Unable to load category progress.\n$e',
//   //       );
//   //
//   //       setState(() {
//   //         loading = false;
//   //       });
//   //     }
//   //
//   //   } catch (e) {
//   //     if (mounted) {
//   //       _showMessage(
//   //         'Unable to load category progress.\n$e',
//   //       );
//   //
//   //       setState(() {
//   //         loading = false;
//   //       });
//   //     }
//   //   }
//   // }
//   Future<void> _loadCategory() async {
//     await _loadSavedAnswers();
//   }
//   // ============================================================
//   // ITEMS
//   // ============================================================
//
//   List<AuditChecklistItem>
//   get items {
//     switch (widget.audit.auditType) {
//       case 'Process Audit':
//         return AuditChecklistData
//             .processItemsFor(
//           widget.section,
//         );
//
//       case 'System Audit':
//         return AuditChecklistData
//             .system;
//
//       case 'Product Audit':
//         return AuditChecklistData
//             .product;
//
//       default:
//         return [];
//     }
//   }
//
//   // ============================================================
//   // STORAGE ID
//   // ============================================================
//
//   String _storageId(
//       AuditChecklistItem item) {
//     return AuditService
//         .checklistStorageId(
//       auditType:
//       widget.audit.auditType,
//       category:
//       widget.section,
//       itemId: item.id,
//     );
//   }
//
//   // ============================================================
//   // LOAD ANSWERS
//   // ============================================================
//
//   Future<void>
//   _loadSavedAnswers() async {
//     try {
//       final saved =
//       await AuditService
//           .getAnswersForCategory(
//         auditId:
//         widget.audit.auditId,
//         category:
//         widget.section,
//       );
//
//       for (final row
//       in saved) {
//         final id =
//             row['checklist_item_id']
//                 ?.toString() ??
//                 '';
//
//         if (id.isEmpty) {
//           continue;
//         }
//
//         answers[id] =
//             row['answer']
//                 ?.toString() ??
//                 '';
//
//         descriptions[id] =
//             row['description']
//                 ?.toString() ??
//                 '';
//
//         final category =
//         row['finding_category']
//             ?.toString();
//
//         if (category != null &&
//             category.isNotEmpty) {
//           categories[id] =
//               FindingCategoryExtension
//                   .fromString(
//                 category,
//               );
//         }
//       }
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           'Unable to load saved progress.\n$e',
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           loading = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // VALIDATE
//   // ============================================================
//
//   bool _validateCategory() {
//     for (final item in items) {
//       final id =
//       _storageId(item);
//
//       final answer =
//       answers[id];
//
//       if (answer == null ||
//           answer.isEmpty) {
//         _showMessage(
//           'Please answer question ${item.number}.',
//         );
//
//         return false;
//       }
//
//       if (answer != 'Yes' &&
//           answer != 'No') {
//         _showMessage(
//           'Invalid answer for question ${item.number}.',
//         );
//
//         return false;
//       }
//
//       if (answer == 'No') {
//         final description =
//             descriptions[id]
//                 ?.trim() ??
//                 '';
//
//         if (description.isEmpty) {
//           _showMessage(
//             'Please enter the finding for question ${item.number}.',
//           );
//
//           return false;
//         }
//
//         if (categories[id] ==
//             null) {
//           _showMessage(
//             'Please select the finding category for question ${item.number}.',
//           );
//
//           return false;
//         }
//       }
//     }
//
//     return true;
//   }
//
//   // ============================================================
//   // SAVE CATEGORY
//   // ============================================================
//
//   Future<void> _saveCategory() async {
//     if (saving) {
//       return;
//     }
//
//     if (!_validateCategory()) {
//       return;
//     }
//
//
//     setState(() {
//       saving = true;
//     });
//
//     try {
//       for (final item in items) {
//         final id = _storageId(item);
//
//         final answer = answers[id];
//
//         if (answer == null ||
//             answer.isEmpty) {
//           continue;
//         }
//
//         await AuditService.saveAnswer(
//           auditId: widget.audit.auditId,
//           section: widget.section,
//           checklistItemId: id,
//           questionNumber: item.number,
//           question: item.question,
//           answer: answer,
//           description:
//           descriptions[id] ?? '',
//           category: categories[id],
//         );
//       }
//
//       // ----------------------------------------------------------
//       // CATEGORY IS COMPLETE HERE
//       // ----------------------------------------------------------
//
//
//
//       await AuditService.updateCurrentSection(
//         auditId: widget.audit.auditId,
//         section: widget.section,
//       );
//
//       if (!mounted) {
//         return;
//       }
//
//       ScaffoldMessenger.of(context)
//           .showSnackBar(
//         const SnackBar(
//           content: Text(
//             'Category saved successfully.',
//           ),
//           behavior:
//           SnackBarBehavior.floating,
//         ),
//       );
//
//       Navigator.pop(context);
//     } catch (e) {
//       if (mounted) {
//         _showMessage(
//           'Unable to save category.\n$e',
//         );
//       }
//     } finally {
//       if (mounted) {
//         setState(() {
//           saving = false;
//         });
//       }
//     }
//   }
//
//   // ============================================================
//   // ANSWER
//   // ============================================================
//
//   void _answer(
//       AuditChecklistItem item,
//       String value) {
//     final id =
//     _storageId(item);
//
//     setState(() {
//       answers[id] = value;
//
//       if (value == 'Yes') {
//         descriptions
//             .remove(id);
//
//         categories
//             .remove(id);
//       }
//     });
//   }
//
//   // ============================================================
//   // TIMER TEXT
//   // ============================================================
//
//
//   // ============================================================
//   // CATEGORY COLOR
//   // ============================================================
//
//   Color _categoryColor(
//       FindingCategory category) {
//     switch (category) {
//       case FindingCategory.critical:
//         return Colors.red;
//
//       case FindingCategory.major:
//         return Colors.orange;
//
//       case FindingCategory.minor:
//         return Colors.green;
//     }
//   }
//
//   // ============================================================
//   // MESSAGE
//   // ============================================================
//
//   void _showMessage(
//       String message) {
//     ScaffoldMessenger.of(context)
//         .showSnackBar(
//       SnackBar(
//         content:
//         Text(message),
//         behavior:
//         SnackBarBehavior
//             .floating,
//       ),
//     );
//   }
//
//   // ============================================================
//   // DISPOSE
//   // ============================================================
//
//   @override
//   void dispose() {
//     super.dispose();
//   }
//
//   // ============================================================
//   // BUILD
//   // ============================================================
//
//   @override
//   Widget build(
//       BuildContext context) {
//     return Scaffold(
//         backgroundColor:
//         const Color(0xFFF5F7FB),
//
//         appBar: AppBar(
//           title: Text(
//             widget.section,
//             style:
//             const TextStyle(
//               fontWeight:
//               FontWeight.w700,
//             ),
//           ),
//
//           backgroundColor:
//           Colors.white,
//
//           foregroundColor:
//           const Color(
//             0xFF172033,
//           ),
//
//           elevation: 0,
//
//                   ),
//
//         body: loading
//             ? const Center(
//           child:
//           CircularProgressIndicator(),
//         )
//             : Column(
//           children: [
//             _header(),
//
//             Expanded(
//               child:
//               ListView.builder(
//                 padding:
//                 const EdgeInsets
//                     .all(25),
//                 itemCount:
//                 items.length,
//                 itemBuilder:
//                     (context,
//                     index) {
//                   return _questionCard(
//                     items[index],
//                   );
//                 },
//               ),
//             ),
//
//             _bottomBar(),
//           ],
//         ),
//     );
//   }
//
//   // ============================================================
//   // HEADER
//   // ============================================================
//
//   Widget _header() {
//     return Container(
//       width: double.infinity,
//       color: Colors.white,
//       padding:
//       const EdgeInsets.fromLTRB(
//         28,
//         20,
//         28,
//         18,
//       ),
//       child: Center(
//         child: ConstrainedBox(
//           constraints:
//           const BoxConstraints(
//             maxWidth: 1100,
//           ),
//           child: Row(
//             children: [
//               Container(
//                 width: 48,
//                 height: 48,
//                 decoration:
//                 BoxDecoration(
//                   color:
//                   const Color(
//                     0xFFEFF3FF,
//                   ),
//                   borderRadius:
//                   BorderRadius
//                       .circular(
//                     12,
//                   ),
//                 ),
//                 child:
//                 const Icon(
//                   Icons
//                       .fact_check_outlined,
//                   color:
//                   Color(
//                     0xFF3155D9,
//                   ),
//                 ),
//               ),
//
//               const SizedBox(
//                 width: 14,
//               ),
//
//               const Expanded(
//                 child: Column(
//                   crossAxisAlignment:
//                   CrossAxisAlignment
//                       .start,
//                   children: [
//                     Text(
//                       'Category Checklist',
//                       style:
//                       TextStyle(
//                         fontSize: 20,
//                         fontWeight:
//                         FontWeight
//                             .w800,
//                       ),
//                     ),
//                     SizedBox(
//                       height: 4,
//                     ),
//                     Text(
//                       'Answer every question. Select No to record a finding.',
//                       style:
//                       TextStyle(
//                         color:
//                         Color(
//                           0xFF6B7280,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   // ============================================================
//   // QUESTION CARD
//   // ============================================================
//
//   Widget _questionCard(
//       AuditChecklistItem item,
//       ) {
//     final answer = answers[_storageId(item)];
//     final id = _storageId(item);
//
//     return Card(
//       margin: const EdgeInsets.only(
//         bottom: 10,
//       ),
//       elevation: 0,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10),
//         side: const BorderSide(
//           color: Color(0xFFE4E8F0),
//         ),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.symmetric(
//           horizontal: 14,
//           vertical: 12,
//         ),
//         child: Row(
//           crossAxisAlignment:
//           CrossAxisAlignment.center,
//           children: [
//             Container(
//               width: 30,
//               height: 30,
//               alignment: Alignment.center,
//               decoration: BoxDecoration(
//                 color: const Color(0xFFEFF3FF),
//                 borderRadius:
//                 BorderRadius.circular(7),
//               ),
//               child: Text(
//                 '${item.number}',
//                 style: const TextStyle(
//                   fontSize: 12,
//                   fontWeight: FontWeight.w800,
//                   color: Color(0xFF3155D9),
//                 ),
//               ),
//             ),
//
//             const SizedBox(width: 10),
//
//             Expanded(
//               child: Text(
//                 item.question,
//                 style: const TextStyle(
//                   fontSize: 14,
//                   height: 1.3,
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//             ),
//
//             const SizedBox(width: 12),
//
//             _answerButton(
//               item: item,
//               label: 'Yes',
//               selected: answer == 'Yes',
//               icon: Icons.check_circle_outline,
//               onTap: saving
//                   ? null
//                   : () => _answer(
//                 item,
//                 'Yes',
//               ),
//             ),
//
//             const SizedBox(width: 6),
//
//             _answerButton(
//               item: item,
//               label: 'No',
//               selected: answer == 'No',
//               icon: Icons.cancel_outlined,
//               onTap: saving
//                   ? null
//                   : () => _answer(
//                 item,
//                 'No',
//               ),
//             ),
//
//             if (answer == 'No') ...[
//               const SizedBox(width: 8),
//
//               SizedBox(
//                 width: 240,
//                 height: 38,
//                 child: TextFormField(
//                   initialValue:
//                   descriptions[id] ?? '',
//                   onChanged: (value) {
//                     descriptions[id] = value;
//                   },
//                   maxLines: 1,
//                   style: const TextStyle(
//                     fontSize: 12,
//                   ),
//                   decoration:
//                   const InputDecoration(
//                     labelText: 'Description',
//                     hintText: 'Enter finding',
//                     isDense: true,
//                     contentPadding:
//                     EdgeInsets.symmetric(
//                       horizontal: 10,
//                       vertical: 9,
//                     ),
//                     border: OutlineInputBorder(),
//                   ),
//                 ),
//               ),
//
//               const SizedBox(width: 6),
//
//               SizedBox(
//                 width: 135,
//                 height: 38,
//                 child: DropdownButtonFormField<
//                     FindingCategory>(
//                   value: categories[id],
//                   isDense: true,
//                   decoration:
//                   const InputDecoration(
//                     labelText: 'Error Type',
//                     isDense: true,
//                     contentPadding:
//                     EdgeInsets.symmetric(
//                       horizontal: 10,
//                       vertical: 9,
//                     ),
//                     border: OutlineInputBorder(),
//                   ),
//                   items: FindingCategory.values
//                       .map(
//                         (category) {
//                       return DropdownMenuItem<
//                           FindingCategory>(
//                         value: category,
//                         child: Text(
//                           category.value,
//                           style:
//                           const TextStyle(
//                             fontSize: 12,
//                             fontWeight:
//                             FontWeight.w600,
//                           ),
//                         ),
//                       );
//                     },
//                   ).toList(),
//                   onChanged: saving
//                       ? null
//                       : (value) {
//                     if (value == null) {
//                       return;
//                     }
//
//                     setState(() {
//                       categories[id] =
//                           value;
//                     });
//                   },
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }
//
//   // ============================================================
//   // ANSWER BUTTON
//   // ============================================================
//
//   Widget _answerButton({
//     required AuditChecklistItem item,
//     required String label,
//     required bool selected,
//     required IconData icon,
//     required VoidCallback? onTap,
//   }) {
//     final isYes = label == 'Yes';
//
//     return SizedBox(
//       height: 34,
//       width: 72,
//       child: OutlinedButton.icon(
//         onPressed: onTap,
//         icon: Icon(
//           icon,
//           size: 14,
//         ),
//         label: Text(
//           label,
//           style: const TextStyle(
//             fontSize: 11,
//             fontWeight: FontWeight.w700,
//           ),
//         ),
//         style: OutlinedButton.styleFrom(
//           padding: const EdgeInsets.symmetric(
//             horizontal: 6,
//           ),
//           backgroundColor: selected
//               ? (isYes
//               ? Colors.green.shade50
//               : Colors.red.shade50)
//               : Colors.white,
//           foregroundColor: selected
//               ? (isYes
//               ? Colors.green.shade700
//               : Colors.red.shade700)
//               : const Color(0xFF4B5563),
//           side: BorderSide(
//             color: selected
//                 ? (isYes
//                 ? Colors.green
//                 : Colors.red)
//                 : const Color(0xFFD1D5DB),
//           ),
//           shape: RoundedRectangleBorder(
//             borderRadius:
//             BorderRadius.circular(7),
//           ),
//         ),
//       ),
//     );
//   }
//
//   // ============================================================
//   // BOTTOM BAR
//   // ============================================================
//
//   Widget _bottomBar() {
//     return Container(
//       padding:
//       const EdgeInsets.all(18),
//       decoration:
//       const BoxDecoration(
//         color: Colors.white,
//         border: Border(
//           top: BorderSide(
//             color:
//             Color(0xFFE4E8F0),
//           ),
//         ),
//       ),
//       child: Row(
//         children: [
//           OutlinedButton.icon(
//             onPressed:
//             saving
//                 ? null
//                 : _saveCategory,
//             icon: const Icon(
//               Icons.save_outlined,
//             ),
//             label: const Text(
//               'Save Progress',
//             ),
//           ),
//
//           const Spacer(),
//
//           ElevatedButton.icon(
//             onPressed:
//             saving
//                 ? null
//                 : _saveCategory,
//             icon: saving
//                 ? const SizedBox(
//               width: 18,
//               height: 18,
//               child:
//               CircularProgressIndicator(
//                 strokeWidth: 2,
//                 color: Colors.white,
//               ),
//             )
//                 : const Icon(
//               Icons.check,
//             ),
//             label: Text(
//               saving
//                   ? 'Saving...'
//                   : 'Save & Return',
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_checklist_item.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_checklist_data.dart';
import '../../services/audit/audit_service.dart';

class AuditChecklistScreen extends StatefulWidget {
  final Audit audit;

  /// Exactly ONE category.
  final String section;

  const AuditChecklistScreen({
    super.key,
    required this.audit,
    required this.section,
  });

  @override
  State<AuditChecklistScreen> createState() =>
      _AuditChecklistScreenState();
}

class _AuditChecklistScreenState
    extends State<AuditChecklistScreen> {
  final Map<String, String> answers = {};
  final Map<String, String> descriptions = {};
  final Map<String, FindingCategory> categories = {};

  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _loadSavedAnswers();
  }

  // ============================================================
  // CHECKLIST ITEMS
  // ============================================================

  List<AuditChecklistItem> get items {
    switch (widget.audit.auditType) {
      case 'Process Audit':
        return AuditChecklistData.processItemsFor(
          widget.section,
        );

      case 'System Audit':
        return AuditChecklistData.system;

      case 'Product Audit':
        return AuditChecklistData.product;

      default:
        return [];
    }
  }

  // ============================================================
  // DATABASE STORAGE ID
  // ============================================================

  String _storageId(AuditChecklistItem item) {
    return AuditService.checklistStorageId(
      auditType: widget.audit.auditType,
      category: widget.section,
      itemId: item.id,
    );
  }

  // ============================================================
  // LOAD SAVED ANSWERS
  // ============================================================

  Future<void> _loadSavedAnswers() async {
    try {
      final saved =
      await AuditService.getAnswersForCategory(
        auditId: widget.audit.auditId,
        category: widget.section,
      );

      for (final row in saved) {
        final id =
            row['checklist_item_id']?.toString() ?? '';

        if (id.isEmpty) {
          continue;
        }

        final answer =
            row['answer']?.toString() ?? '';

        answers[id] = answer;

        descriptions[id] =
            row['description']?.toString() ?? '';

        final categoryValue =
        row['finding_category']?.toString();

        if (categoryValue != null &&
            categoryValue.trim().isNotEmpty) {
          categories[id] =
              FindingCategoryExtension.fromString(
                categoryValue,
              );
        }
      }
    } catch (e) {
      if (mounted) {
        _showMessage(
          'Unable to load saved progress.\n$e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  // ============================================================
  // ANSWER
  // ============================================================

  void _answer(
      AuditChecklistItem item,
      String value,
      ) {
    final id = _storageId(item);

    setState(() {
      answers[id] = value;

      if (value == 'Yes') {
        descriptions.remove(id);
        categories.remove(id);
      }
    });
  }

  // ============================================================
  // VALIDATE
  // ============================================================

  bool _validateCategory() {
    for (final item in items) {
      final id = _storageId(item);
      final answer = answers[id];

      if (answer == null ||
          answer.trim().isEmpty) {
        _showMessage(
          'Please answer question ${item.number}.',
        );
        return false;
      }

      if (answer != 'Yes' &&
          answer != 'No') {
        _showMessage(
          'Invalid answer for question ${item.number}.',
        );
        return false;
      }

      if (answer == 'No') {
        final description =
            descriptions[id]?.trim() ?? '';

        if (description.isEmpty) {
          _showMessage(
            'Please enter the description for question ${item.number}.',
          );
          return false;
        }

        if (categories[id] == null) {
          _showMessage(
            'Please select the error type for question ${item.number}.',
          );
          return false;
        }
      }
    }

    return true;
  }

  // ============================================================
  // SAVE CATEGORY
  // ============================================================

  Future<void> _saveCategory() async {
    if (saving) {
      return;
    }

    if (!_validateCategory()) {
      return;
    }

    setState(() {
      saving = true;
    });

    try {
      for (final item in items) {
        final id = _storageId(item);
        final answer = answers[id];

        if (answer == null ||
            answer.trim().isEmpty) {
          continue;
        }

        await AuditService.saveAnswer(
          auditId: widget.audit.auditId,
          section: widget.section,
          checklistItemId: id,
          questionNumber: item.number,
          question: item.question,
          answer: answer,
          description: descriptions[id] ?? '',
          category: categories[id],
        );
      }

      await AuditService.updateCurrentSection(
        auditId: widget.audit.auditId,
        section: widget.section,
      );

      if (!mounted) {
        return;
      }

      _showMessage(
        'Category saved successfully.',
      );

      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        _showMessage(
          'Unable to save category.\n$e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          saving = false;
        });
      }
    }
  }

  // ============================================================
  // ERROR MESSAGE
  // ============================================================

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ============================================================
  // CATEGORY COLOR
  // ============================================================

  Color _categoryColor(
      FindingCategory category,
      ) {
    switch (category) {
      case FindingCategory.critical:
        return Colors.red;

      case FindingCategory.major:
        return Colors.orange;

      case FindingCategory.minor:
        return Colors.green;
    }
  }

  // ============================================================
  // CATEGORY ICON
  // ============================================================

  IconData _categoryIcon(
      FindingCategory category,
      ) {
    switch (category) {
      case FindingCategory.critical:
        return Icons.priority_high_rounded;

      case FindingCategory.major:
        return Icons.warning_amber_rounded;

      case FindingCategory.minor:
        return Icons.info_outline;
    }
  }

  // ============================================================
  // ANSWER BUTTON
  // ============================================================

  Widget _answerButton(
      AuditChecklistItem item,
      String value,
      ) {
    final id = _storageId(item);
    final selected = answers[id] == value;
    final yes = value == 'Yes';

    final selectedColor =
    yes ? Colors.green : Colors.red;

    return SizedBox(
      width: 72,
      height: 38,
      child: OutlinedButton(
        onPressed: saving
            ? null
            : () => _answer(item, value),
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.zero,
          backgroundColor: selected
              ? selectedColor.withOpacity(0.08)
              : Colors.white,
          side: BorderSide(
            color: selected
                ? selectedColor
                : const Color(0xFFD5DAE3),
            width: selected ? 1.4 : 1,
          ),
          shape: RoundedRectangleBorder(
            borderRadius:
            BorderRadius.circular(7),
          ),
        ),
        child: Row(
          mainAxisAlignment:
          MainAxisAlignment.center,
          children: [
            Icon(
              yes
                  ? Icons.check_circle_outline
                  : Icons.cancel_outlined,
              size: 16,
              color: selected
                  ? selectedColor
                  : const Color(0xFF6B7280),
            ),
            const SizedBox(width: 5),
            Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: selected
                    ? selectedColor
                    : const Color(0xFF4B5563),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // FINDING DETAILS
  // ============================================================

  Widget _findingFields(
      AuditChecklistItem item,
      ) {
    final id = _storageId(item);

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact =
            constraints.maxWidth < 700;

        final descriptionField =
        SizedBox(
          width: compact
              ? double.infinity
              : 420,
          height: 42,
          child: TextFormField(
            initialValue:
            descriptions[id] ?? '',
            maxLines: 1,
            onChanged: (value) {
              descriptions[id] = value;
            },
            decoration:
            const InputDecoration(
              labelText: 'Description',
              hintText: 'Enter finding',
              prefixIcon: Icon(
                Icons.description_outlined,
                size: 17,
              ),
              contentPadding:
              EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 8,
              ),
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),
        );

        final categoryField =
        SizedBox(
          width: compact
              ? double.infinity
              : 190,
          height: 42,
          child: DropdownButtonFormField<
              FindingCategory>(
            value: categories[id],
            isDense: true,
            decoration:
            const InputDecoration(
              labelText: 'Error Type',
              prefixIcon: Icon(
                Icons.flag_outlined,
                size: 17,
              ),
              contentPadding:
              EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 8,
              ),
              border: OutlineInputBorder(),
            ),
            items: FindingCategory.values
                .map(
                  (category) =>
                  DropdownMenuItem<
                      FindingCategory>(
                    value: category,
                    child: Row(
                      children: [
                        Icon(
                          _categoryIcon(
                            category,
                          ),
                          size: 15,
                          color:
                          _categoryColor(
                            category,
                          ),
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        Text(
                          category.value,
                          style:
                          const TextStyle(
                            fontSize: 13,
                            fontWeight:
                            FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
            )
                .toList(),
            onChanged: saving
                ? null
                : (value) {
              setState(() {
                if (value == null) {
                  categories
                      .remove(id);
                } else {
                  categories[id] =
                      value;
                }
              });
            },
          ),
        );

        if (compact) {
          return Padding(
            padding:
            const EdgeInsets.only(
              top: 10,
            ),
            child: Column(
              children: [
                descriptionField,
                const SizedBox(height: 8),
                categoryField,
              ],
            ),
          );
        }

        return Padding(
          padding:
          const EdgeInsets.only(
            left: 12,
          ),
          child: Row(
            children: [
              descriptionField,
              const SizedBox(width: 8),
              categoryField,
            ],
          ),
        );
      },
    );
  }

  // ============================================================
  // QUESTION CARD
  // ============================================================

  Widget _questionCard(
      AuditChecklistItem item,
      ) {
    final id = _storageId(item);
    final answer = answers[id];

    return Card(
      margin:
      const EdgeInsets.only(bottom: 10),
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius:
        BorderRadius.circular(10),
        side: const BorderSide(
          color: Color(0xFFE3E7EF),
        ),
      ),
      child: Padding(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        child: Column(
          children: [
            Row(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration:
                  BoxDecoration(
                    color:
                    const Color(
                      0xFFEFF3FF,
                    ),
                    borderRadius:
                    BorderRadius.circular(
                      7,
                    ),
                  ),
                  child: Text(
                    '${item.number}',
                    style:
                    const TextStyle(
                      color:
                      Color(0xFF3155D9),
                      fontSize: 12,
                      fontWeight:
                      FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.question,
                    style:
                    const TextStyle(
                      fontSize: 14,
                      height: 1.35,
                      fontWeight:
                      FontWeight.w600,
                      color:
                      Color(0xFF202938),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            LayoutBuilder(
              builder:
                  (context, constraints) {
                final compact =
                    constraints.maxWidth < 700;

                if (compact) {
                  return Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _answerButton(
                            item,
                            'Yes',
                          ),
                          const SizedBox(
                            width: 6,
                          ),
                          _answerButton(
                            item,
                            'No',
                          ),
                        ],
                      ),
                      if (answer == 'No')
                        _findingFields(item),
                    ],
                  );
                }

                return Row(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  children: [
                    _answerButton(
                      item,
                      'Yes',
                    ),
                    const SizedBox(
                      width: 6,
                    ),
                    _answerButton(
                      item,
                      'No',
                    ),
                    if (answer == 'No')
                      _findingFields(item),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _header() {
    final answered =
        answers.values
            .where(
              (value) =>
          value == 'Yes' ||
              value == 'No',
        )
            .length;

    final total = items.length;

    return Container(
      width: double.infinity,
      color: Colors.white,
      padding:
      const EdgeInsets.fromLTRB(
        24,
        18,
        24,
        14,
      ),
      child: Center(
        child: ConstrainedBox(
          constraints:
          const BoxConstraints(
            maxWidth: 1200,
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration:
                BoxDecoration(
                  color:
                  const Color(
                    0xFFEFF3FF,
                  ),
                  borderRadius:
                  BorderRadius.circular(
                    10,
                  ),
                ),
                child: const Icon(
                  Icons
                      .fact_check_outlined,
                  color:
                  Color(0xFF3155D9),
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.section,
                      style:
                      const TextStyle(
                        fontSize: 19,
                        fontWeight:
                        FontWeight.w800,
                        color:
                        Color(0xFF172033),
                      ),
                    ),
                    const SizedBox(
                      height: 3,
                    ),
                    Text(
                      'Answer every question. Select No to record a finding.',
                      style:
                      const TextStyle(
                        fontSize: 12,
                        color:
                        Color(0xFF6B7280),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration:
                BoxDecoration(
                  color:
                  const Color(
                    0xFFF3F4F6,
                  ),
                  borderRadius:
                  BorderRadius.circular(
                    20,
                  ),
                ),
                child: Text(
                  '$answered / $total',
                  style:
                  const TextStyle(
                    fontSize: 12,
                    fontWeight:
                    FontWeight.w700,
                    color:
                    Color(0xFF4B5563),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: Text(
          widget.audit.auditType,
          style: const TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor:
        const Color(0xFF172033),
        elevation: 0,
      ),

      body: loading
          ? const Center(
        child:
        CircularProgressIndicator(),
      )
          : Column(
        children: [
          _header(),

          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints:
                const BoxConstraints(
                  maxWidth: 1200,
                ),
                child: ListView.builder(
                  padding:
                  const EdgeInsets.fromLTRB(
                    18,
                    14,
                    18,
                    90,
                  ),
                  itemCount:
                  items.length,
                  itemBuilder:
                      (context, index) {
                    return _questionCard(
                      items[index],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),

      bottomNavigationBar:
      SafeArea(
        child: Container(
          height: 62,
          decoration:
          const BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(
                color: Color(0xFFE3E7EF),
              ),
            ),
          ),
          child: Center(
            child: ConstrainedBox(
              constraints:
              const BoxConstraints(
                maxWidth: 1200,
              ),
              child: Padding(
                padding:
                const EdgeInsets.symmetric(
                  horizontal: 18,
                ),
                child: Row(
                  children: [
                    OutlinedButton.icon(
                      onPressed:
                      saving
                          ? null
                          : _saveCategory,
                      icon: const Icon(
                        Icons
                            .save_outlined,
                        size: 17,
                      ),
                      label: const Text(
                        'Save Progress',
                      ),
                    ),
                    const Spacer(),
                    ElevatedButton.icon(
                      onPressed:
                      saving
                          ? null
                          : _saveCategory,
                      icon: saving
                          ? const SizedBox(
                        width: 16,
                        height: 16,
                        child:
                        CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                          : const Icon(
                        Icons.check,
                        size: 17,
                      ),
                      label: Text(
                        saving
                            ? 'Saving...'
                            : 'Save & Return',
                      ),
                      style:
                      ElevatedButton.styleFrom(
                        minimumSize:
                        const Size(
                          150,
                          40,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}