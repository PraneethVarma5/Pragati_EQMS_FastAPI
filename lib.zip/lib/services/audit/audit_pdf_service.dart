import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../pdf/audit/audit_mil_pdf.dart';
import '../../pdf/audit/audit_summary_pdf.dart';
import '../../pdf/audit/audit_all_summary_pdf.dart';
class AuditPdfService {
  AuditPdfService._();

  static Future<void> shareMilReport({
    required Audit audit,
    required List<AuditFinding> findings,
    required String milNumber,
  }) async {
    final Uint8List bytes =
    await AuditMilPdf.generate(
      audit: audit,
      findings: findings,
      milNumber: milNumber,
    );

    await Printing.sharePdf(
      bytes: bytes,
      filename:
      'MIL_Report_$milNumber.pdf',
    );
  }

  static Future<void> shareSummaryReport({
    required Audit audit,
    required List<AuditFinding> findings,
    required String milNumber,
  }) async {
    final Uint8List bytes =
    await AuditSummaryPdf.generate(
      audit: audit,
      findings: findings,
      milNumber: milNumber,
    );

    await Printing.sharePdf(
      bytes: bytes,
      filename:
      'Audit_Summary_$milNumber.pdf',
    );
  }
  static Future<void> shareAllAuditSummaries({
    required List<Audit> audits,
    required Map<String, List<AuditFinding>>
    findingsByAudit,
  }) async {
    final Uint8List bytes =
    await AuditAllSummaryPdf.generate(
      audits: audits,
      findingsByAudit: findingsByAudit,
    );

    await Printing.sharePdf(
      bytes: bytes,
      filename:
      'Audit_Summary_All_Completed_Audits.pdf',
    );
  }
}