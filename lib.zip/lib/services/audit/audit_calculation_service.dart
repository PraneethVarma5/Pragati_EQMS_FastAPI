// // import '../../models/audit/audit.dart';
// // import '../../models/audit/audit_finding.dart';
// //
// // class AuditCalculationService {
// //   AuditCalculationService._();
// //
// //   // ============================================================
// //   // AUDITED HOURS
// //   // ============================================================
// //
// //   static double auditedHours(Audit audit) {
// //     return audit.totalAuditedHours;
// //   }
// //
// //   // ============================================================
// //   // FINDING COUNTS
// //   // ============================================================
// //
// //   static int criticalCount(
// //       List<AuditFinding> findings) {
// //     return findings
// //         .where(
// //           (finding) =>
// //       finding.category ==
// //           FindingCategory.critical,
// //     )
// //         .length;
// //   }
// //
// //   static int majorCount(
// //       List<AuditFinding> findings) {
// //     return findings
// //         .where(
// //           (finding) =>
// //       finding.category ==
// //           FindingCategory.major,
// //     )
// //         .length;
// //   }
// //
// //   static int minorCount(
// //       List<AuditFinding> findings) {
// //     return findings
// //         .where(
// //           (finding) =>
// //       finding.category ==
// //           FindingCategory.minor,
// //     )
// //         .length;
// //   }
// //
// //   // ============================================================
// //   // CPH
// //   //
// //   // CPH = (Critical + Major) / Audited Hours
// //   // ============================================================
// //
// //   static double cph({
// //     required Audit audit,
// //     required List<AuditFinding> findings,
// //   }) {
// //     final hours =
// //     auditedHours(audit);
// //
// //     if (hours <= 0) {
// //       return 0;
// //     }
// //
// //     final critical =
// //     criticalCount(findings);
// //
// //     final major =
// //     majorCount(findings);
// //
// //     return (critical + major) / hours;
// //   }
// //
// //   // ============================================================
// //   // FORMAT ELAPSED TIME
// //   // ============================================================
// //
// //   static String formatDuration(
// //       double hours) {
// //     final totalSeconds =
// //     (hours * 3600).round();
// //
// //     final duration =
// //     Duration(
// //       seconds: totalSeconds,
// //     );
// //
// //     final h =
// //         duration.inHours;
// //
// //     final m =
// //     duration.inMinutes.remainder(60);
// //
// //     final s =
// //     duration.inSeconds.remainder(60);
// //
// //     return '${h.toString().padLeft(2, '0')}:'
// //         '${m.toString().padLeft(2, '0')}:'
// //         '${s.toString().padLeft(2, '0')}';
// //   }
// // }
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
//
// class AuditCalculationService {
//   AuditCalculationService._();
//
//   // ============================================================
//   // TOTAL AUDITED HOURS
//   // ============================================================
//
//   static double auditedHours(Audit audit) {
//     final hours = audit.totalTimeTakenHours;
//
//     if (hours < 0) {
//       return 0;
//     }
//
//     return hours;
//   }
//
//   // ============================================================
//   // FINDING COUNTS
//   // ============================================================
//
//   static int criticalCount(
//       List<AuditFinding> findings,
//       ) {
//     return findings.where(
//           (finding) =>
//       finding.category ==
//           FindingCategory.critical,
//     ).length;
//   }
//
//   static int majorCount(
//       List<AuditFinding> findings,
//       ) {
//     return findings.where(
//           (finding) =>
//       finding.category ==
//           FindingCategory.major,
//     ).length;
//   }
//
//   static int minorCount(
//       List<AuditFinding> findings,
//       ) {
//     return findings.where(
//           (finding) =>
//       finding.category ==
//           FindingCategory.minor,
//     ).length;
//   }
//
//   // ============================================================
//   // CPH
//   //
//   // CPH =
//   // (Critical + Major) / Total Audited Hours
//   // ============================================================
//
//   static double cph({
//     required Audit audit,
//     required List<AuditFinding> findings,
//   }) {
//     final hours = auditedHours(audit);
//
//     if (hours <= 0) {
//       return 0;
//     }
//
//     final critical =
//     criticalCount(findings);
//
//     final major =
//     majorCount(findings);
//
//     return (critical + major) / hours;
//   }
//
//   // ============================================================
//   // PROCESS / SYSTEM AUDIT SCORE
//   //
//   // Score =
//   // 100
//   // - 20 * Critical
//   // - 5  * Major
//   // - 2  * Minor
//   //
//   // Minimum displayed score = 0.
//   // ============================================================
//
//   static double auditScore({
//     required Audit audit,
//     required List<AuditFinding> findings,
//   }) {
//     if (audit.auditType != 'Process Audit' &&
//         audit.auditType != 'System Audit') {
//       return 0;
//     }
//
//     final critical =
//     criticalCount(findings);
//
//     final major =
//     majorCount(findings);
//
//     final minor =
//     minorCount(findings);
//
//     final score =
//         100 -
//             (20 * critical) -
//             (5 * major) -
//             (2 * minor);
//
//     return score < 0 ? 0 : score.toDouble();
//   }
//
//   // ============================================================
//   // FORMAT HOURS
//   // ============================================================
//
//   static String formatHours(
//       double hours,
//       ) {
//     return hours.toStringAsFixed(2);
//   }
//
//   // ============================================================
//   // FORMAT CPH
//   // ============================================================
//
//   static String formatCph(
//       double value,
//       ) {
//     return value.toStringAsFixed(2);
//   }
//
//   // ============================================================
//   // FORMAT SCORE
//   // ============================================================
//
//   static String formatScore(
//       double value,
//       ) {
//     return value.toStringAsFixed(2);
//   }
// }



import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';

class AuditCalculationService {
  AuditCalculationService._();

  // ============================================================
  // TOTAL AUDITED HOURS
  //
  // The auditor enters ONE overall audit duration
  // on the Audit Details screen.
  // ============================================================

  static double auditedHours(Audit audit) {
    final hours = audit.totalTimeTakenHours;

    if (hours <= 0) {
      return 0;
    }

    return hours;
  }

  // ============================================================
  // FINDING COUNTS
  // ============================================================

  static int criticalCount(
      List<AuditFinding> findings,
      ) {
    return findings.where(
          (finding) =>
      finding.category ==
          FindingCategory.critical,
    ).length;
  }

  static int majorCount(
      List<AuditFinding> findings,
      ) {
    return findings.where(
          (finding) =>
      finding.category ==
          FindingCategory.major,
    ).length;
  }

  static int minorCount(
      List<AuditFinding> findings,
      ) {
    return findings.where(
          (finding) =>
      finding.category ==
          FindingCategory.minor,
    ).length;
  }

  // ============================================================
  // CPH
  //
  // CPH =
  // (Critical + Major) / Total Audited Hours
  // ============================================================

  static double cph({
    required Audit audit,
    required List<AuditFinding> findings,
  }) {
    final hours = auditedHours(audit);

    if (hours <= 0) {
      return 0;
    }

    final critical = criticalCount(findings);
    final major = majorCount(findings);

    return (critical + major) / hours;
  }

  // ============================================================
  // PROCESS / SYSTEM AUDIT SCORE
  //
  // Score =
  // 100
  // - 20 * Critical
  // - 5  * Major
  // - 2  * Minor
  //
  // Score cannot be below 0.
  // ============================================================

  static double auditScore({
    required Audit audit,
    required List<AuditFinding> findings,
  }) {
    final isProcessOrSystem =
        audit.auditType == 'Process Audit' ||
            audit.auditType == 'System Audit';

    if (!isProcessOrSystem) {
      return 0;
    }

    final critical = criticalCount(findings);
    final major = majorCount(findings);
    final minor = minorCount(findings);

    final score =
        100 -
            (20 * critical) -
            (5 * major) -
            (2 * minor);

    return score < 0
        ? 0
        : score.toDouble();
  }

  // ============================================================
  // FORMAT HOURS
  // ============================================================

  static String formatHours(double hours) {
    return hours.toStringAsFixed(2);
  }

  // ============================================================
  // FORMAT CPH
  // ============================================================

  static String formatCph(double value) {
    return value.toStringAsFixed(2);
  }

  // ============================================================
  // FORMAT SCORE
  // ============================================================

  static String formatScore(double value) {
    return value.toStringAsFixed(2);
  }
}