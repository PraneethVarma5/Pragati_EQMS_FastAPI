// import 'package:supabase_flutter/supabase_flutter.dart';
// import 'package:uuid/uuid.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import 'audit_checklist_data.dart';
// class AuditService {
//   AuditService._();
//
//   static final SupabaseClient _client =
//       Supabase.instance.client;
//
//   static const Uuid _uuid = Uuid();
//
//   static Future<List<Map<String, dynamic>>> getAuditPlan() async {
//     final response = await _client
//         .from('audits')
//         .select()
//         .order('audit_date', ascending: false);
//
//     return List<Map<String, dynamic>>.from(response);
//   }
//
//   static Future<Audit> createAudit({
//     required String auditType,
//     required String vendor,
//     required String site,
//     required String lob,
//     required String program,
//     required String line,
//     required String apn,
//     required DateTime auditDate,
//     required String auditorName,
//   }) async {
//     final audit = Audit(
//       auditId: _uuid.v4(),
//       auditType: auditType,
//       vendor: vendor.trim(),
//       site: site.trim(),
//       lob: lob.trim(),
//       program: program.trim(),
//       line: line.trim(),
//       apn: apn.trim(),
//       auditDate: auditDate,
//       auditorName: auditorName.trim(),
//       startedAt: DateTime.now(),
//       status: 'In Progress',
//     );
//
//     await _client
//         .from('audits')
//         .insert(audit.toMap());
//
//     return audit;
//   }
//
//   static Future<void> saveAudit(Audit audit) async {
//     await _client
//         .from('audits')
//         .upsert(audit.toMap());
//   }
//
//   static Future<Audit?> getAudit(String auditId) async {
//     final result = await _client
//         .from('audits')
//         .select()
//         .eq('audit_id', auditId)
//         .maybeSingle();
//
//     if (result == null) return null;
//
//     return Audit.fromMap(result);
//   }
//
//   static Future<void> saveAnswer({
//     required String auditId,
//     required String section,
//     required String checklistItemId,
//     required int questionNumber,
//     required String question,
//     required String answer,
//     String description = '',
//     FindingCategory? category,
//   }) async {
//     await _client
//         .from('audit_checklist_answers')
//         .upsert(
//       {
//         'answer_id': _uuid.v4(),
//         'audit_id': auditId,
//         'section': section,
//         'checklist_item_id': checklistItemId,
//         'question_number': questionNumber,
//         'question': question,
//         'answer': answer,
//         'description': description,
//         'finding_category': category?.value,
//         'updated_at': DateTime.now().toIso8601String(),
//       },
//       onConflict: 'audit_id,checklist_item_id',
//     );
//   }
//
//   static Future<List<Map<String, dynamic>>> getAnswers(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_checklist_answers')
//         .select()
//         .eq('audit_id', auditId);
//
//     return List<Map<String, dynamic>>.from(response);
//   }
//
//   static Future<List<AuditFinding>> getFindings(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_findings')
//         .select()
//         .eq('audit_id', auditId);
//
//     return response
//         .map<AuditFinding>(
//           (row) => AuditFinding.fromMap(row),
//     )
//         .toList();
//   }
//
//   static Future<void> saveFinding(
//       AuditFinding finding,
//       ) async {
//     await _client
//         .from('audit_findings')
//         .upsert(finding.toMap());
//   }
//
//   static Future<void> completeAudit(
//       String auditId,
//       ) async {
//     await _client
//         .from('audits')
//         .update({
//       'status': 'Completed',
//       'finished_at':
//       DateTime.now().toIso8601String(),
//       'updated_at':
//       DateTime.now().toIso8601String(),
//     })
//         .eq('audit_id', auditId);
//   }
//
//   static Future<void> updateCurrentSection({
//     required String auditId,
//     required String section,
//   }) async {
//     await _client
//         .from('audits')
//         .update({
//       'current_section': section,
//       'updated_at':
//       DateTime.now().toIso8601String(),
//     })
//         .eq('audit_id', auditId);
//   }
//
//   static Future<String> generateMilNumber(
//       DateTime date,
//       ) async {
//     final prefix =
//         '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
//
//     final existing = await _client
//         .from('audits')
//         .select('mil_number')
//         .like(
//       'mil_number',
//       '$prefix-%',
//     );
//
//     int highest = 0;
//
//     for (final row in existing) {
//       final value =
//       row['mil_number']?.toString();
//
//       if (value == null) {
//         continue;
//       }
//
//       final parts =
//       value.split('-');
//
//       if (parts.isEmpty) {
//         continue;
//       }
//
//       final number =
//       int.tryParse(parts.last);
//
//       if (number != null &&
//           number > highest) {
//         highest = number;
//       }
//     }
//
//     return '$prefix-${highest + 1}';
//   }
//
//   static Future<void> assignMilNumber(
//       String auditId,
//       String milNumber,
//       ) async {
//     await _client
//         .from('audits')
//         .update({
//       'mil_number': milNumber,
//       'updated_at':
//       DateTime.now().toIso8601String(),
//     })
//         .eq('audit_id', auditId);
//   }
//   static List<String> categoriesForAuditType(
//       String auditType) {
//     switch (auditType) {
//       case 'Process Audit':
//         return AuditChecklistData.processSections;
//
//       case 'System Audit':
//         return AuditChecklistData.systemProcesses;
//
//       case 'Product Audit':
//         return const ['Product Audit'];
//
//       default:
//         return [];
//     }
//   }
//   static Future<Map<String, bool>> getCategoryStatus(
//       Audit audit) async {
//     final categories =
//     categoriesForAuditType(
//       audit.auditType,
//     );
//
//     final answers =
//     await getAnswers(audit.auditId);
//
//     final result = <String, bool>{};
//
//     for (final category in categories) {
//       final categoryAnswers =
//       answers.where(
//             (row) =>
//         row['section']?.toString() ==
//             category,
//       );
//
//       final expectedCount =
//       _expectedQuestionCount(
//         audit.auditType,
//         category,
//       );
//
//       if (expectedCount == 0) {
//         result[category] = false;
//         continue;
//       }
//
//       if (categoryAnswers.length !=
//           expectedCount) {
//         result[category] = false;
//         continue;
//       }
//
//       bool complete = true;
//
//       for (final row in categoryAnswers) {
//         final answer =
//         row['answer']?.toString();
//
//         if (answer == null ||
//             answer.isEmpty) {
//           complete = false;
//           break;
//         }
//
//         if (answer == 'No') {
//           final description =
//               row['description']
//                   ?.toString()
//                   .trim() ??
//                   '';
//
//           final findingCategory =
//               row['finding_category']
//                   ?.toString()
//                   .trim() ??
//                   '';
//
//           if (description.isEmpty ||
//               findingCategory.isEmpty) {
//             complete = false;
//             break;
//           }
//         }
//       }
//
//       result[category] = complete;
//     }
//
//     return result;
//   }
//   static int _expectedQuestionCount(
//       String auditType,
//       String category) {
//     switch (auditType) {
//       case 'Process Audit':
//         return AuditChecklistData
//             .processItemsFor(category)
//             .length;
//
//       case 'System Audit':
//         return AuditChecklistData
//             .system
//             .length;
//
//       case 'Product Audit':
//         return AuditChecklistData
//             .product
//             .length;
//
//       default:
//         return 0;
//     }
//   }
// }

//
// import 'package:supabase_flutter/supabase_flutter.dart';
// import 'package:uuid/uuid.dart';
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import 'audit_checklist_data.dart';
//
// class AuditService {
//   AuditService._();
//
//   static final SupabaseClient _client =
//       Supabase.instance.client;
//
//   static const Uuid _uuid = Uuid();
//
//   // ============================================================
//   // AUDIT PLAN
//   // ============================================================
//
//   static Future<List<Map<String, dynamic>>> getAuditPlan() async {
//     final response = await _client
//         .from('audits')
//         .select()
//         .order('audit_date', ascending: false);
//
//     return List<Map<String, dynamic>>.from(response);
//   }
//
//   // ============================================================
//   // CREATE AUDIT
//   // ============================================================
//
//   static Future<Audit> createAudit({
//     required String auditType,
//     required String vendor,
//     required String site,
//     required String lob,
//     required String program,
//     required String line,
//     required String apn,
//     required DateTime auditDate,
//     required String auditorName,
//   }) async {
//     final now = DateTime.now();
//
//     final audit = Audit(
//       auditId: _uuid.v4(),
//       auditType: auditType.trim(),
//       vendor: vendor.trim(),
//       site: site.trim(),
//       lob: lob.trim(),
//       program: program.trim(),
//       line: line.trim(),
//       apn: apn.trim(),
//       auditDate: auditDate,
//       auditorName: auditorName.trim(),
//       startedAt: now,
//       finishedAt: null,
//       status: 'In Progress',
//       currentSection: null,
//     );
//
//     await _client
//         .from('audits')
//         .insert(audit.toMap());
//
//     return audit;
//   }
//
//   // ============================================================
//   // SAVE AUDIT
//   // ============================================================
//
//   static Future<void> saveAudit(
//       Audit audit,
//       ) async {
//     await _client
//         .from('audits')
//         .upsert(audit.toMap());
//   }
//
//   // ============================================================
//   // GET ONE AUDIT
//   // ============================================================
//
//   static Future<Audit?> getAudit(
//       String auditId,
//       ) async {
//     final result = await _client
//         .from('audits')
//         .select()
//         .eq('audit_id', auditId)
//         .maybeSingle();
//
//     if (result == null) {
//       return null;
//     }
//
//     return Audit.fromMap(result);
//   }
//
//   // ============================================================
//   // AUDIT CATEGORIES
//   // ============================================================
//
//   static List<String> categoriesForAuditType(
//       String auditType,
//       ) {
//     switch (auditType) {
//       case 'Process Audit':
//         return List<String>.from(
//           AuditChecklistData.processSections,
//         );
//
//       case 'System Audit':
//         return List<String>.from(
//           AuditChecklistData.systemProcesses,
//         );
//
//       case 'Product Audit':
//         return const [
//           'Product Audit',
//         ];
//
//       default:
//         return [];
//     }
//   }
//
//   // ============================================================
//   // CHECKLIST ITEMS FOR CATEGORY
//   // ============================================================
//
//   static int expectedQuestionCount(
//       String auditType,
//       String category,
//       ) {
//     switch (auditType) {
//       case 'Process Audit':
//         return AuditChecklistData
//             .processItemsFor(category)
//             .length;
//
//       case 'System Audit':
//         return AuditChecklistData
//             .system
//             .length;
//
//       case 'Product Audit':
//         return AuditChecklistData
//             .product
//             .length;
//
//       default:
//         return 0;
//     }
//   }
//
//   // ============================================================
//   // ANSWER ID
//   //
//   // Process/Product already have unique checklist IDs.
//   //
//   // System questions are reused for every process, so the
//   // category is included in the persisted ID.
//   // ============================================================
//
//   static String checklistStorageId({
//     required String auditType,
//     required String category,
//     required String itemId,
//   }) {
//     if (auditType != 'System Audit') {
//       return itemId;
//     }
//
//     final categoryKey = category
//         .toLowerCase()
//         .replaceAll(
//       RegExp(r'[^a-z0-9]+'),
//       '_',
//     )
//         .replaceAll(
//       RegExp(r'_+'),
//       '_',
//     )
//         .replaceAll(
//       RegExp(r'^_|_$'),
//       '',
//     );
//
//     return 'system_${categoryKey}_$itemId';
//   }
//
//   // ============================================================
//   // SAVE CHECKLIST ANSWER
//   // ============================================================
//
//   static Future<void> saveAnswer({
//     required String auditId,
//     required String section,
//     required String checklistItemId,
//     required int questionNumber,
//     required String question,
//     required String answer,
//     String description = '',
//     FindingCategory? category,
//   }) async {
//     await _client
//         .from('audit_checklist_answers')
//         .upsert(
//       {
//         'answer_id': _uuid.v4(),
//         'audit_id': auditId,
//         'section': section,
//         'checklist_item_id': checklistItemId,
//         'question_number': questionNumber,
//         'question': question,
//         'answer': answer,
//         'description': description,
//         'finding_category': category?.value,
//         'updated_at':
//         DateTime.now().toIso8601String(),
//       },
//       onConflict:
//       'audit_id,checklist_item_id',
//     );
//   }
//
//   // ============================================================
//   // GET ALL ANSWERS FOR AUDIT
//   // ============================================================
//
//   static Future<List<Map<String, dynamic>>> getAnswers(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_checklist_answers')
//         .select()
//         .eq('audit_id', auditId);
//
//     return List<Map<String, dynamic>>.from(
//       response,
//     );
//   }
//
//   // ============================================================
//   // GET ANSWERS FOR ONE CATEGORY
//   // ============================================================
//
//   static Future<List<Map<String, dynamic>>>
//   getAnswersForCategory({
//     required String auditId,
//     required String category,
//   }) async {
//     final response = await _client
//         .from('audit_checklist_answers')
//         .select()
//         .eq('audit_id', auditId)
//         .eq('section', category);
//
//     return List<Map<String, dynamic>>.from(
//       response,
//     );
//   }
//
//   // ============================================================
//   // CATEGORY COMPLETION STATUS
//   //
//   // A category is completed ONLY when:
//   //
//   // 1. Every expected question has an answer.
//   // 2. Every "No" answer has a description.
//   // 3. Every "No" answer has a finding category.
//   // ============================================================
//
//   static Future<Map<String, bool>>
//   getCategoryStatus(
//       Audit audit,
//       ) async {
//     final categories =
//     categoriesForAuditType(
//       audit.auditType,
//     );
//
//     final answers =
//     await getAnswers(audit.auditId);
//
//     final result =
//     <String, bool>{};
//
//     for (final category in categories) {
//       final expectedCount =
//       expectedQuestionCount(
//         audit.auditType,
//         category,
//       );
//
//       final categoryAnswers =
//       answers.where(
//             (row) =>
//         row['section']?.toString() ==
//             category,
//       ).toList();
//
//       if (expectedCount == 0) {
//         result[category] = false;
//         continue;
//       }
//
//       if (categoryAnswers.length !=
//           expectedCount) {
//         result[category] = false;
//         continue;
//       }
//
//       bool complete = true;
//
//       for (final row in categoryAnswers) {
//         final answer =
//             row['answer']?.toString().trim() ??
//                 '';
//
//         if (answer != 'Yes' &&
//             answer != 'No') {
//           complete = false;
//           break;
//         }
//
//         if (answer == 'No') {
//           final description =
//               row['description']
//                   ?.toString()
//                   .trim() ??
//                   '';
//
//           final findingCategory =
//               row['finding_category']
//                   ?.toString()
//                   .trim() ??
//                   '';
//
//           if (description.isEmpty ||
//               findingCategory.isEmpty) {
//             complete = false;
//             break;
//           }
//         }
//       }
//
//       result[category] = complete;
//     }
//
//     return result;
//   }
//
//   // ============================================================
//   // CHECK WHETHER ALL CATEGORIES ARE COMPLETE
//   // ============================================================
//
//   static Future<bool> areAllCategoriesCompleted(
//       Audit audit,
//       ) async {
//     final categories =
//     categoriesForAuditType(
//       audit.auditType,
//     );
//
//     if (categories.isEmpty) {
//       return false;
//     }
//
//     final status =
//     await getCategoryStatus(audit);
//
//     return categories.every(
//           (category) =>
//       status[category] == true,
//     );
//   }
//
//   // ============================================================
//   // UPDATE CURRENT CATEGORY
//   // ============================================================
//
//   static Future<void> updateCurrentSection({
//     required String auditId,
//     required String section,
//   }) async {
//     await _client
//         .from('audits')
//         .update(
//       {
//         'current_section': section,
//         'updated_at':
//         DateTime.now().toIso8601String(),
//       },
//     )
//         .eq(
//       'audit_id',
//       auditId,
//     );
//   }
//
//   // ============================================================
//   // COMPLETE AUDIT
//   //
//   // This is called only after ALL categories are complete.
//   // finished_at is used for Total Audited Hours.
//   // ============================================================
//
//   static Future<void> completeAudit(
//       String auditId,
//       ) async {
//     final now =
//     DateTime.now().toIso8601String();
//
//     await _client
//         .from('audits')
//         .update(
//       {
//         'status': 'Completed',
//         'finished_at': now,
//         'current_section': null,
//         'updated_at': now,
//       },
//     )
//         .eq(
//       'audit_id',
//       auditId,
//     );
//   }
//
//   // ============================================================
//   // FINDINGS
//   // ============================================================
//
//   static Future<List<AuditFinding>>
//   getFindings(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_findings')
//         .select()
//         .eq('audit_id', auditId);
//
//     return response
//         .map<AuditFinding>(
//           (row) =>
//           AuditFinding.fromMap(
//             row,
//           ),
//     )
//         .toList();
//   }
//
//   static Future<void> saveFinding(
//       AuditFinding finding,
//       ) async {
//     await _client
//         .from('audit_findings')
//         .upsert(
//       finding.toMap(),
//     );
//   }
//
//   // ============================================================
//   // MIL NUMBER
//   // ============================================================
//
//   static Future<String> generateMilNumber(
//       DateTime date,
//       ) async {
//     final prefix =
//         '${date.year}-'
//         '${date.month.toString().padLeft(2, '0')}-'
//         '${date.day.toString().padLeft(2, '0')}';
//
//     final existing = await _client
//         .from('audits')
//         .select('mil_number')
//         .like(
//       'mil_number',
//       '$prefix-%',
//     );
//
//     int highest = 0;
//
//     for (final row in existing) {
//       final value =
//       row['mil_number']?.toString();
//
//       if (value == null) {
//         continue;
//       }
//
//       final parts =
//       value.split('-');
//
//       if (parts.isEmpty) {
//         continue;
//       }
//
//       final number =
//       int.tryParse(parts.last);
//
//       if (number != null &&
//           number > highest) {
//         highest = number;
//       }
//     }
//
//     return '$prefix-${highest + 1}';
//   }
//
//   static Future<void> assignMilNumber(
//       String auditId,
//       String milNumber,
//       ) async {
//     await _client
//         .from('audits')
//         .update(
//       {
//         'mil_number': milNumber,
//         'updated_at':
//         DateTime.now().toIso8601String(),
//       },
//     )
//         .eq(
//       'audit_id',
//       auditId,
//     );
//   }
// }

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import 'audit_checklist_data.dart';

class AuditService {
  AuditService._();

  static final SupabaseClient _client =
      Supabase.instance.client;

  static const Uuid _uuid = Uuid();

  // ============================================================
  // AUDIT PLAN
  // ============================================================

  static Future<List<Map<String, dynamic>>>
  getAuditPlan() async {
    final response = await _client
        .from('audits')
        .select()
        .order(
      'audit_date',
      ascending: false,
    );

    return List<Map<String, dynamic>>.from(
      response,
    );
  }

  // ============================================================
  // CREATE AUDIT
  // ============================================================

  // static Future<Audit> createAudit({
  //   required String auditType,
  //   required String vendor,
  //   required String site,
  //   required String lob,
  //   required String program,
  //   required String line,
  //   required String apn,
  //   required DateTime auditDate,
  //   required String auditorName,
  //   required double totalTimeTakenHours,
  // }) async {
  //   final now =
  //   DateTime.now();
  //
  //   final audit = Audit(
  //     auditId: _uuid.v4(),
  //     auditType: auditType.trim(),
  //     vendor: vendor.trim(),
  //     site: site.trim(),
  //     lob: lob.trim(),
  //     program: program.trim(),
  //     line: line.trim(),
  //     apn: apn.trim(),
  //     auditDate: auditDate,
  //     auditorName: auditorName.trim(),
  //
  //     // Audit creation/start timestamp.
  //     // This is NOT used for CPH.
  //     startedAt: now,
  //
  //     // Set only when all categories are completed.
  //     finishedAt: null,
  //
  //     // ONE overall duration entered by the auditor
  //     // on Audit Details.
  //     totalTimeTakenHours: totalTimeTakenHours,
  //
  //     status: 'In Progress',
  //
  //     currentSection: null,
  //   );
  //
  //   await _client
  //       .from('audits')
  //       .insert(
  //     audit.toMap(),
  //   );
  //
  //   return audit;
  // }
  static Future<Audit> createAudit({
    required String auditType,
    required String vendor,
    required String site,
    required String lob,
    required String program,
    required String line,
    required String apn,
    required DateTime auditDate,
    required String auditorName,
    required double totalTimeTakenHours,
  }) async {
    final now = DateTime.now();

    if (totalTimeTakenHours <= 0) {
      throw Exception(
        'Time Taken must be greater than 0 hours.',
      );
    }

    final audit = Audit(
      auditId: _uuid.v4(),
      auditType: auditType.trim(),
      vendor: vendor.trim(),
      site: site.trim(),
      lob: lob.trim(),
      program: program.trim(),
      line: line.trim(),
      apn: apn.trim(),
      auditDate: auditDate,
      auditorName: auditorName.trim(),

      startedAt: now,
      finishedAt: null,

      // IMPORTANT:
      // Store the single overall time entered
      // by the auditor on Audit Details.
      totalTimeTakenHours:
      totalTimeTakenHours,

      status: 'In Progress',

      currentSection: null,
    );

    await _client
        .from('audits')
        .insert(
      audit.toMap(),
    );

    return audit;
  }
  // ============================================================
  // GET AUDIT
  // ============================================================

  static Future<Audit?> getAudit(
      String auditId) async {
    final result = await _client
        .from('audits')
        .select()
        .eq(
      'audit_id',
      auditId,
    )
        .maybeSingle();

    if (result == null) {
      return null;
    }

    return Audit.fromMap(result);
  }

  // ============================================================
  // SAVE AUDIT
  // ============================================================

  static Future<void> saveAudit(
      Audit audit) async {
    await _client
        .from('audits')
        .upsert(
      audit.toMap(),
    );
  }

  // ============================================================
  // CATEGORIES
  // ============================================================

  static List<String>
  categoriesForAuditType(
      String auditType) {
    switch (auditType) {
      case 'Process Audit':
        return List<String>.from(
          AuditChecklistData
              .processSections,
        );

      case 'System Audit':
        return List<String>.from(
          AuditChecklistData
              .systemProcesses,
        );

      case 'Product Audit':
        return const [
          'Product Audit',
        ];

      default:
        return [];
    }
  }

  // ============================================================
  // EXPECTED QUESTIONS
  // ============================================================

  static int expectedQuestionCount(
      String auditType,
      String category) {
    switch (auditType) {
      case 'Process Audit':
        return AuditChecklistData
            .processItemsFor(
          category,
        )
            .length;

      case 'System Audit':
        return AuditChecklistData
            .system
            .length;

      case 'Product Audit':
        return AuditChecklistData
            .product
            .length;

      default:
        return 0;
    }
  }

  // ============================================================
  // STORAGE CHECKLIST ID
  // ============================================================

  static String checklistStorageId({
    required String auditType,
    required String category,
    required String itemId,
  }) {
    if (auditType !=
        'System Audit') {
      return itemId;
    }

    final categoryKey =
    category
        .toLowerCase()
        .replaceAll(
      RegExp(
        r'[^a-z0-9]+',
      ),
      '_',
    )
        .replaceAll(
      RegExp(r'_+'),
      '_',
    )
        .replaceAll(
      RegExp(
        r'^_|_$',
      ),
      '',
    );

    return 'system_${categoryKey}_$itemId';
  }

  // ============================================================
  // SAVE CHECKLIST ANSWER
  // ============================================================

  static Future<void> saveAnswer({
    required String auditId,
    required String section,
    required String checklistItemId,
    required int questionNumber,
    required String question,
    required String answer,
    String description = '',
    FindingCategory? category,
  }) async {
    final now = DateTime.now();

    // ----------------------------------------------------------
    // SAVE CHECKLIST ANSWER
    // ----------------------------------------------------------

    await _client
        .from('audit_checklist_answers')
        .upsert(
      {
        'answer_id': _uuid.v4(),
        'audit_id': auditId,
        'section': section,
        'checklist_item_id': checklistItemId,
        'question_number': questionNumber,
        'question': question,
        'answer': answer,
        'description': description.trim(),
        'finding_category': category?.value,
        'updated_at': now.toIso8601String(),
      },
      onConflict:
      'audit_id,checklist_item_id',
    );

    // ----------------------------------------------------------
    // GET THE ACTUAL ANSWER ROW
    // ----------------------------------------------------------

    final saved = await _client
        .from('audit_checklist_answers')
        .select(
      'answer_id,description,finding_category',
    )
        .eq('audit_id', auditId)
        .eq(
      'checklist_item_id',
      checklistItemId,
    )
        .single();

    final answerId =
        saved['answer_id']?.toString() ?? '';

    if (answerId.isEmpty) {
      throw Exception(
        'Unable to identify saved checklist answer.',
      );
    }

    // ----------------------------------------------------------
    // NO = CREATE / UPDATE FINDING
    // ----------------------------------------------------------

    if (answer == 'No') {
      if (category == null) {
        throw Exception(
          'Finding category is required for every No answer.',
        );
      }

      final issue =
      description.trim();

      if (issue.isEmpty) {
        throw Exception(
          'Finding description is required for every No answer.',
        );
      }

      final finding =
      AuditFinding(
        id: answerId,
        auditId: auditId,
        section: section,
        checklistItemId: checklistItemId,
        questionNumber: questionNumber,
        question: question,
        answer: 'No',
        description: issue,
        category: category,
        issue: issue,
      );

      await saveFinding(finding);

      return;
    }

    // ----------------------------------------------------------
    // YES = DELETE ANY OLD FINDING
    // ----------------------------------------------------------

    await _client
        .from('audit_findings')
        .delete()
        .eq('audit_id', auditId)
        .eq(
      'checklist_item_id',
      checklistItemId,
    );
  }
  // ============================================================
  // GET ALL ANSWERS
  // ============================================================

  static Future<
      List<Map<String, dynamic>>>
  getAnswers(
      String auditId) async {
    final response = await _client
        .from(
      'audit_checklist_answers',
    )
        .select()
        .eq(
      'audit_id',
      auditId,
    );

    return List<Map<String, dynamic>>.from(
      response,
    );
  }

  // ============================================================
  // GET ANSWERS FOR CATEGORY
  // ============================================================

  static Future<
      List<Map<String, dynamic>>>
  getAnswersForCategory({
    required String auditId,
    required String category,
  }) async {
    final response = await _client
        .from(
      'audit_checklist_answers',
    )
        .select()
        .eq(
      'audit_id',
      auditId,
    )
        .eq(
      'section',
      category,
    );

    return List<Map<String, dynamic>>.from(
      response,
    );
  }

  // ============================================================
  // CATEGORY STATUS
  // ============================================================

  static Future<Map<String, bool>>
  getCategoryStatus(
      Audit audit) async {
    final categories =
    categoriesForAuditType(
      audit.auditType,
    );

    final answers =
    await getAnswers(
      audit.auditId,
    );

    final result =
    <String, bool>{};

    for (final category
    in categories) {
      final expected =
      expectedQuestionCount(
        audit.auditType,
        category,
      );

      final categoryAnswers =
      answers
          .where(
            (row) =>
        row['section']
            ?.toString() ==
            category,
      )
          .toList();

      if (expected == 0 ||
          categoryAnswers.length !=
              expected) {
        result[category] = false;
        continue;
      }

      bool complete = true;

      for (final row
      in categoryAnswers) {
        final answer =
            row['answer']
                ?.toString()
                .trim() ??
                '';

        if (answer != 'Yes' &&
            answer != 'No') {
          complete = false;
          break;
        }

        if (answer == 'No') {
          final description =
              row['description']
                  ?.toString()
                  .trim() ??
                  '';

          final categoryValue =
              row['finding_category']
                  ?.toString()
                  .trim() ??
                  '';

          if (description.isEmpty ||
              categoryValue.isEmpty) {
            complete = false;
            break;
          }
        }
      }

      result[category] =
          complete;
    }

    return result;
  }

  // ============================================================
  // ALL CATEGORIES COMPLETE
  // ============================================================

  static Future<bool>
  areAllCategoriesCompleted(
      Audit audit) async {
    final categories =
    categoriesForAuditType(
      audit.auditType,
    );

    if (categories.isEmpty) {
      return false;
    }

    final status =
    await getCategoryStatus(
      audit,
    );

    return categories.every(
          (category) =>
      status[category] == true,
    );
  }

  // ============================================================
  // TIMER: RESUME
  // ============================================================

  // static Future<void>
  // resumeAuditTimer(
  //     String auditId) async {
  //   final audit =
  //   await getAudit(
  //     auditId,
  //   );
  //
  //   if (audit == null) {
  //     throw Exception(
  //       'Audit not found.',
  //     );
  //   }
  //
  //   if (audit.status ==
  //       'Completed') {
  //     return;
  //   }
  //
  //   // Already running.
  //   if (audit.activeStartedAt !=
  //       null) {
  //     return;
  //   }
  //
  //   final now =
  //   DateTime.now();
  //
  //   await _client
  //       .from('audits')
  //       .update(
  //     {
  //       'active_started_at':
  //       now.toIso8601String(),
  //       'status':
  //       'In Progress',
  //       'updated_at':
  //       now.toIso8601String(),
  //     },
  //   )
  //       .eq(
  //     'audit_id',
  //     auditId,
  //   );
  // }

  // ============================================================
  // TIMER: PAUSE / SAVE
  // ============================================================

  // static Future<void>
  // pauseAuditTimer(
  //     String auditId) async {
  //   final audit =
  //   await getAudit(
  //     auditId,
  //   );
  //
  //   if (audit == null) {
  //     throw Exception(
  //       'Audit not found.',
  //     );
  //   }
  //
  //   if (audit.activeStartedAt ==
  //       null) {
  //     return;
  //   }
  //
  //   final now =
  //   DateTime.now();
  //
  //   var additionalSeconds =
  //       now
  //           .difference(
  //         audit.activeStartedAt!,
  //       )
  //           .inSeconds;
  //
  //   if (additionalSeconds <
  //       0) {
  //     additionalSeconds = 0;
  //   }
  //
  //   final totalSeconds =
  //       audit.elapsedSeconds +
  //           additionalSeconds;
  //
  //   await _client
  //       .from('audits')
  //       .update(
  //     {
  //       'elapsed_seconds':
  //       totalSeconds,
  //       'active_started_at':
  //       null,
  //       'updated_at':
  //       now.toIso8601String(),
  //     },
  //   )
  //       .eq(
  //     'audit_id',
  //     auditId,
  //   );
  // }

//   // ============================================================
// // GET CATEGORY TIME
// // ============================================================
//
//   static Future<double> getCategoryTime({
//     required String auditId,
//     required String category,
//   }) async {
//     final response = await _client
//         .from('audit_category_progress')
//         .select('time_taken_hours')
//         .eq('audit_id', auditId)
//         .eq('category', category)
//         .maybeSingle();
//
//     if (response == null) {
//       return 0;
//     }
//
//     return (response['time_taken_hours'] as num?)
//         ?.toDouble() ??
//         0;
//   }
//
// // ============================================================
// // SAVE CATEGORY TIME
// // ============================================================
//
//   static Future<void> saveCategoryTime({
//     required String auditId,
//     required String category,
//     required double timeTakenHours,
//     required bool completed,
//   }) async {
//     final now = DateTime.now();
//
//     await _client
//         .from('audit_category_progress')
//         .upsert(
//       {
//         'progress_id': _uuid.v4(),
//         'audit_id': auditId,
//         'category': category,
//         'time_taken_hours': timeTakenHours,
//         'completed': completed,
//         'completed_at':
//         completed ? now.toIso8601String() : null,
//         'updated_at': now.toIso8601String(),
//       },
//       onConflict: 'audit_id,category',
//     );
//
//     await _updateTotalAuditHours(auditId);
//   }
//
// // ============================================================
// // UPDATE TOTAL AUDIT HOURS
// // ============================================================
//
//   static Future<void> _updateTotalAuditHours(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_category_progress')
//         .select('time_taken_hours')
//         .eq('audit_id', auditId);
//
//     double total = 0;
//
//     for (final row in response) {
//       total +=
//           (row['time_taken_hours'] as num?)
//               ?.toDouble() ??
//               0;
//     }
//
//     await _client
//         .from('audits')
//         .update(
//       {
//         'total_time_taken_hours': total,
//         'updated_at':
//         DateTime.now().toIso8601String(),
//       },
//     )
//         .eq('audit_id', auditId);
//   }
//
// // ============================================================
// // GET ALL CATEGORY TIMES
// // ============================================================
//
//   static Future<Map<String, double>>
//   getCategoryTimes(
//       String auditId,
//       ) async {
//     final response = await _client
//         .from('audit_category_progress')
//         .select(
//       'category,time_taken_hours',
//     )
//         .eq('audit_id', auditId);
//
//     final result = <String, double>{};
//
//     for (final row in response) {
//       final category =
//           row['category']?.toString() ?? '';
//
//       if (category.isEmpty) {
//         continue;
//       }
//
//       result[category] =
//           (row['time_taken_hours'] as num?)
//               ?.toDouble() ??
//               0;
//     }
//
//     return result;
//   }

  // ============================================================
  // UPDATE CURRENT CATEGORY
  // ============================================================

  static Future<void>
  updateCurrentSection({
    required String auditId,
    required String section,
  }) async {
    await _client
        .from('audits')
        .update(
      {
        'current_section':
        section,
        'updated_at':
        DateTime.now()
            .toIso8601String(),
      },
    )
        .eq(
      'audit_id',
      auditId,
    );
  }

  // ============================================================
  // COMPLETE AUDIT
  //
  // ONLY after every category is complete.
  // ============================================================

  static Future<void> completeAudit(
      String auditId,
      ) async {
    final audit =
    await getAudit(
      auditId,
    );

    if (audit == null) {
      throw Exception(
        'Audit not found.',
      );
    }

    final allComplete =
    await areAllCategoriesCompleted(
      audit,
    );

    if (!allComplete) {
      throw Exception(
        'Cannot complete audit until all categories are completed.',
      );
    }

    final now = DateTime.now();

    // Time is already stored from the individual
    // category Time Taken fields.
    //
    // Do NOT calculate elapsed time from
    // startedAt / finishedAt.
    await _client
        .from('audits')
        .update(
      {
        'status': 'Completed',

        'finished_at':
        now.toIso8601String(),

        'current_section': null,

        'updated_at':
        now.toIso8601String(),
      },
    )
        .eq(
      'audit_id',
      auditId,
    );
  }
  // ============================================================
  // FINDINGS
  // ============================================================

  static Future<List<AuditFinding>>
  getFindings(
      String auditId) async {
    // IMPORTANT:
    // Do NOT select description or answer here.
    //
    // audit_findings does not contain those columns.

    final response =
    await _client
        .from(
      'audit_findings',
    )
        .select(
      '''
              finding_id,
              audit_id,
              answer_id,
              section,
              checklist_item_id,
              question_number,
              question,
              issue,
              finding_category,
              root_cause,
              corrective_action,
              dri_name,
              mail_id,
              deadline,
              overall_status,
              created_at,
              updated_at
              ''',
    )
        .eq(
      'audit_id',
      auditId,
    )
        .order(
      'question_number',
      ascending: true,
    );

    return response
        .map<AuditFinding>(
          (row) =>
          AuditFinding.fromMap(
            Map<String, dynamic>.from(
              row,
            ),
          ),
    )
        .toList();
  }

  // ============================================================
  // SAVE FINDING
  // ============================================================

  static Future<void>
  saveFinding(
      AuditFinding finding) async {
    final data =
    finding.toMap();

    data['updated_at'] =
        DateTime.now()
            .toIso8601String();

    await _client
        .from(
      'audit_findings',
    )
        .upsert(
      data,
    );
  }

  // ============================================================
  // MIL NUMBER
  // ============================================================

  static Future<String>
  generateMilNumber(
      DateTime date) async {
    final prefix =
        '${date.year}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';

    final existing =
    await _client
        .from('audits')
        .select(
      'mil_number',
    )
        .like(
      'mil_number',
      '$prefix-%',
    );

    int highest = 0;

    for (final row
    in existing) {
      final value =
      row['mil_number']
          ?.toString();

      if (value == null) {
        continue;
      }

      final parts =
      value.split('-');

      if (parts.isEmpty) {
        continue;
      }

      final number =
      int.tryParse(
        parts.last,
      );

      if (number != null &&
          number > highest) {
        highest = number;
      }
    }

    return '$prefix-${highest + 1}';
  }

  static Future<void>
  assignMilNumber(
      String auditId,
      String milNumber) async {
    await _client
        .from('audits')
        .update(
      {
        'mil_number':
        milNumber,
        'updated_at':
        DateTime.now()
            .toIso8601String(),
      },
    )
        .eq(
      'audit_id',
      auditId,
    );
  }
  // ============================================================
// MIL STATUS
// ============================================================

  static Future<void> setMilStatus(
      String auditId,
      String status,
      ) async {
    await _client
        .from('audits')
        .update(
      {
        'mil_status': status,
        'updated_at':
        DateTime.now().toIso8601String(),
      },
    )
        .eq(
      'audit_id',
      auditId,
    );
  }

  // ============================================================
// GET MIL STATUS
//
// MIL STATUS IS DERIVED FROM CURRENT MIL FINDINGS
//
// Rules:
//   - No MIL number       -> Not Generated
//   - Any issue is Open   -> Open
//   - All issues Closed   -> Closed
// ============================================================

  static Future<String> getMilStatus(
      String auditId,
      ) async {
    // ----------------------------------------------------------
    // First check whether a MIL has actually been generated.
    // ----------------------------------------------------------

    final auditRow = await _client
        .from('audits')
        .select('mil_number')
        .eq(
      'audit_id',
      auditId,
    )
        .maybeSingle();

    final milNumber =
    auditRow?['mil_number']
        ?.toString()
        .trim();

    if (milNumber == null ||
        milNumber.isEmpty) {
      return 'Not Generated';
    }

    // ----------------------------------------------------------
    // Load the current MIL findings.
    // ----------------------------------------------------------

    final rows = await _client
        .from('audit_findings')
        .select(
      'finding_id, overall_status',
    )
        .eq(
      'audit_id',
      auditId,
    );

    // ----------------------------------------------------------
    // No findings means there is no open issue.
    // Therefore the generated MIL is Closed.
    // ----------------------------------------------------------

    if (rows.isEmpty) {
      await _updateStoredMilStatus(
        auditId: auditId,
        status: 'Closed',
      );

      return 'Closed';
    }

    // ----------------------------------------------------------
    // If ANY finding is not Closed,
    // MIL remains Open.
    // ----------------------------------------------------------

    final hasOpenFinding = rows.any(
          (row) {
        final status =
        row['overall_status']
            ?.toString()
            .trim()
            .toLowerCase();

        return status != 'closed';
      },
    );

    final status =
    hasOpenFinding
        ? 'Open'
        : 'Closed';

    // ----------------------------------------------------------
    // Keep the database status synchronized too.
    // ----------------------------------------------------------

    await _updateStoredMilStatus(
      auditId: auditId,
      status: status,
    );

    return status;
  }

// ============================================================
// INTERNAL MIL STATUS SYNC
// ============================================================

  static Future<void> _updateStoredMilStatus({
    required String auditId,
    required String status,
  }) async {
    await _client
        .from('audits')
        .update({
      'mil_status': status,
      'updated_at':
      DateTime.now().toIso8601String(),
    })
        .eq(
      'audit_id',
      auditId,
    );
  }
  static Future<void> closeMil(
      String auditId,
      ) async {
    final findings =
    await getFindings(auditId);

    final hasOpenFinding =
    findings.any(
          (finding) =>
      finding.overallStatus
          .trim()
          .toLowerCase() !=
          'closed',
    );

    if (hasOpenFinding) {
      throw Exception(
        'MIL cannot be closed while findings are still open.',
      );
    }

    await setMilStatus(
      auditId,
      'Closed',
    );
  }
}