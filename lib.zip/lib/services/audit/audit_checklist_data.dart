import '../../models/audit/audit_checklist_item.dart';

class AuditChecklistData {
  AuditChecklistData._();

  static const List<String> processSections = [
    'Incoming Raw Material / Raw material warehouse',
    'Manufacturing',
    '100% Cosmetic Inspection',
    'FQC + OQC',
  ];

  static const List<AuditChecklistItem> incomingRawMaterial = [
    AuditChecklistItem(
      id: 'process_incoming_01',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 1,
      question: 'Inspectors are trained & certified',
    ),
    AuditChecklistItem(
      id: 'process_incoming_02',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 2,
      question:
      'Measurement equipment are calibrated and store in good condition',
    ),
    AuditChecklistItem(
      id: 'process_incoming_03',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 3,
      question:
      'Raw material from the qualified source / Ok2use list',
    ),
    AuditChecklistItem(
      id: 'process_incoming_04',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 4,
      question:
      'Raw material comes in with certificate/COC report from sub-vendor',
    ),
    AuditChecklistItem(
      id: 'process_incoming_05',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 5,
      question:
      'IQC inspection plan/SOP are available in incoming inspection area',
    ),
    AuditChecklistItem(
      id: 'process_incoming_06',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 6,
      question:
      'IQC inspection carried out per inspection plan',
    ),
    AuditChecklistItem(
      id: 'process_incoming_07',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 7,
      question:
      'Proper actions taken if any "fail" detected',
    ),
    AuditChecklistItem(
      id: 'process_incoming_08',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 8,
      question:
      'Raw material stored in required temp/humidity condition',
    ),
    AuditChecklistItem(
      id: 'process_incoming_09',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 9,
      question: 'Material are within shelf-life',
    ),
    AuditChecklistItem(
      id: 'process_incoming_10',
      section: 'Incoming Raw Material / Raw material warehouse',
      number: 10,
      question:
      'Materials are clear identification & mix avoidance',
    ),
  ];

  static const List<AuditChecklistItem> manufacturing = [
    AuditChecklistItem(
      id: 'process_manufacturing_01',
      section: 'Manufacturing',
      number: 1,
      question:
      'Machine/tool/fixture are qualified',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_02',
      section: 'Manufacturing',
      number: 2,
      question:
      'Tool life defined in machine and actually controlled',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_03',
      section: 'Manufacturing',
      number: 3,
      question:
      'Direct and indirect material match with BOM, ok2use list and within shelf-life',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_04',
      section: 'Manufacturing',
      number: 4,
      question:
      'SOP available and parameters/control item specified at each station and aligned with approved DFM/MIP/PQP',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_05',
      section: 'Manufacturing',
      number: 5,
      question:
      'Operation method follow SOP requirement',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_06',
      section: 'Manufacturing',
      number: 6,
      question:
      'Process parameters meet SOP definition and record available',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_07',
      section: 'Manufacturing',
      number: 7,
      question:
      'Maintenance carried out and record available',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_08',
      section: 'Manufacturing',
      number: 8,
      question:
      'Quality personnel and critical process personnel are trained & certified',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_09',
      section: 'Manufacturing',
      number: 9,
      question:
      'IPQC inspection plan available at each station and aligned with approved PQP/MSOP',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_10',
      section: 'Manufacturing',
      number: 10,
      question:
      'Measurement tool and gages all calibrated and within expiration',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_11',
      section: 'Manufacturing',
      number: 11,
      question:
      'IPQC/FQC Inspection carried out per plan/SOP and data record available',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_12',
      section: 'Manufacturing',
      number: 12,
      question:
      'IPQC inspection covers all running machine/line/tool etc',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_13',
      section: 'Manufacturing',
      number: 13,
      question:
      'IPQC inspection completed on time (before next sample collected)',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_14',
      section: 'Manufacturing',
      number: 14,
      question:
      'In-process limit sample available for cosmetic control',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_15',
      section: 'Manufacturing',
      number: 15,
      question:
      'Proper actions taken if any "fail" detected',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_16',
      section: 'Manufacturing',
      number: 16,
      question:
      'No risky handling which may cause cosmetic/dimensional NG',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_17',
      section: 'Manufacturing',
      number: 17,
      question:
      'Label or barcode applied to track parts and prevent "skipping" process',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_18',
      section: 'Manufacturing',
      number: 18,
      question:
      'Only IPQC PASS parts can be flowed to next station',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_19',
      section: 'Manufacturing',
      number: 19,
      question:
      'Good 5S in process or storing area to prevent mixing up',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_20',
      section: 'Manufacturing',
      number: 20,
      question:
      'Parts properly packed during transportation to prevent damage/contamination',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_21',
      section: 'Manufacturing',
      number: 21,
      question:
      'Is there any Non-POR process',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_22',
      section: 'Manufacturing',
      number: 22,
      question:
      'Is there any unauthorized reworking process',
    ),
    AuditChecklistItem(
      id: 'process_manufacturing_23',
      section: 'Manufacturing',
      number: 23,
      question:
      'Is there any unapproved outsourcing for any process',
    ),
  ];

  static const List<AuditChecklistItem> cosmeticInspection = [
    AuditChecklistItem(
      id: 'process_cosmetic_01',
      section: '100% Cosmetic Inspection',
      number: 1,
      question:
      'SOP available at the 100% inspection station',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_02',
      section: '100% Cosmetic Inspection',
      number: 2,
      question:
      'Light source / illumination meet requirements',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_03',
      section: '100% Cosmetic Inspection',
      number: 3,
      question:
      'Inspection carried out per SOP',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_04',
      section: '100% Cosmetic Inspection',
      number: 4,
      question:
      'Limit samples available on inspection line',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_05',
      section: '100% Cosmetic Inspection',
      number: 5,
      question:
      'Inspectors all are qualified (passed training and ARR)',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_06',
      section: '100% Cosmetic Inspection',
      number: 6,
      question:
      'Customer feedback passed on to inspection & NG pictures hang on inspection line',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_07',
      section: '100% Cosmetic Inspection',
      number: 7,
      question:
      'Layout well designed at inspection and storing area to prevent mixing up',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_08',
      section: '100% Cosmetic Inspection',
      number: 8,
      question:
      'Good 5S in inspection and storing area to prevent mixing up',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_09',
      section: '100% Cosmetic Inspection',
      number: 9,
      question:
      'Label or barcode applied to track parts and prevent "skipping" process',
    ),
    AuditChecklistItem(
      id: 'process_cosmetic_10',
      section: '100% Cosmetic Inspection',
      number: 10,
      question:
      'NG parts are moved away timely',
    ),
  ];

  static const List<AuditChecklistItem> fqcOqc = [
    AuditChecklistItem(
      id: 'process_fqc_01',
      section: 'FQC + OQC',
      number: 1,
      question:
      'Measurement equipment are calibrated and store in good condition',
    ),
    AuditChecklistItem(
      id: 'process_fqc_02',
      section: 'FQC + OQC',
      number: 2,
      question:
      'FQC/OQC personnel are trained & certified',
    ),
    AuditChecklistItem(
      id: 'process_fqc_03',
      section: 'FQC + OQC',
      number: 3,
      question:
      'FQC/OQC inspection plan available and aligned to the approved PQP',
    ),
    AuditChecklistItem(
      id: 'process_fqc_04',
      section: 'FQC + OQC',
      number: 4,
      question:
      'Inspection carried out per FQC/OQC plan and data record available',
    ),
    AuditChecklistItem(
      id: 'process_fqc_05',
      section: 'FQC + OQC',
      number: 5,
      question:
      'Proper action taken when any OOS detected',
    ),
    AuditChecklistItem(
      id: 'process_fqc_06',
      section: 'FQC + OQC',
      number: 6,
      question:
      'Only FQC PASS parts can be flowed to warehouse',
    ),
    AuditChecklistItem(
      id: 'process_fqc_07',
      section: 'FQC + OQC',
      number: 7,
      question:
      'Can track back to Production / IPQC / FQC/OQC inspector if any NG found from particular lot',
    ),
    AuditChecklistItem(
      id: 'process_fqc_08',
      section: 'FQC + OQC',
      number: 8,
      question:
      'OQC samples are kept for >3 months in case any feedback from downstream',
    ),
    AuditChecklistItem(
      id: 'process_fqc_09',
      section: 'FQC + OQC',
      number: 9,
      question:
      'FG shipping follows FIFO rule',
    ),
    AuditChecklistItem(
      id: 'process_fqc_10',
      section: 'FQC + OQC',
      number: 10,
      question:
      'Clear identification of NG/OK part/box/area',
    ),
  ];

  static List<AuditChecklistItem> processItemsFor(
      String section,
      ) {
    switch (section) {
      case 'Incoming Raw Material / Raw material warehouse':
        return incomingRawMaterial;

      case 'Manufacturing':
        return manufacturing;

      case '100% Cosmetic Inspection':
        return cosmeticInspection;

      case 'FQC + OQC':
        return fqcOqc;

      default:
        return [];
    }
  }

  static const List<AuditChecklistItem> product = [
    AuditChecklistItem(
      id: 'product_01',
      section: 'Product Audit',
      number: 1,
      question: 'Cosmetic',
    ),
    AuditChecklistItem(
      id: 'product_02',
      section: 'Product Audit',
      number: 2,
      question: 'FAI',
    ),
    AuditChecklistItem(
      id: 'product_03',
      section: 'Product Audit',
      number: 3,
      question:
      'Cpk meets the target for all SPC dimensions or similarly with LQ approval',
    ),
    AuditChecklistItem(
      id: 'product_04',
      section: 'Product Audit',
      number: 4,
      question:
      'Teardown meets product performance',
    ),
    AuditChecklistItem(
      id: 'product_05',
      section: 'Product Audit',
      number: 5,
      question:
      'Gluing path is aligned with PDFM & approved sample',
    ),
    AuditChecklistItem(
      id: 'product_06',
      section: 'Product Audit',
      number: 6,
      question:
      'Materials are aligned with BOM, drawing and Ok2use list',
    ),
    AuditChecklistItem(
      id: 'product_07',
      section: 'Product Audit',
      number: 7,
      question:
      'Materials are within spec & shelf-life',
    ),
    AuditChecklistItem(
      id: 'product_08',
      section: 'Product Audit',
      number: 8,
      question:
      'Reliability test (P1,P2,P3), destructive test (Push/Pull, T-peel force, shearing test, mechanical test, etc meet requirement or similarly with LQ approval',
    ),
    AuditChecklistItem(
      id: 'product_09',
      section: 'Product Audit',
      number: 9,
      question:
      'Clearly traceability from FG to semi-FG to raw material batch',
    ),
  ];

  static const List<AuditChecklistItem> system = [
    AuditChecklistItem(
      id: 'system_01',
      section: 'QMS System Audit',
      number: 1,
      question:
      'Is procedure/document in place for use?',
    ),
    AuditChecklistItem(
      id: 'system_02',
      section: 'QMS System Audit',
      number: 2,
      question:
      'Is procedure approved by authorized person?',
    ),
    AuditChecklistItem(
      id: 'system_03',
      section: 'QMS System Audit',
      number: 3,
      question:
      'Is procedure well trained for relevant staffs?',
    ),
    AuditChecklistItem(
      id: 'system_04',
      section: 'QMS System Audit',
      number: 4,
      question:
      'Is procedure implemented fully and correctly?',
    ),
    AuditChecklistItem(
      id: 'system_05',
      section: 'QMS System Audit',
      number: 5,
      question:
      'Is procedure reviewed regularly to maintain the effectiveness?',
    ),
    AuditChecklistItem(
      id: 'system_06',
      section: 'QMS System Audit',
      number: 6,
      question:
      'Is procedure applied across the sites consistently?',
    ),
  ];

  static const List<String> systemProcesses = [
    'Training & Certification process',
    'Internal audit process',
    'Corrective & Preventive action process',
    'Control of non-conforming product process',
    'FIFO & FEFO process',
    'Control & Calibration of measuring equipment',
    'Control & Maintenance of production equipment/ machine/ fixture/ tool',
    'Change management',
    'Data integrity',
    'Quality data management (record, storage, analysis, improvement)',
  ];
}