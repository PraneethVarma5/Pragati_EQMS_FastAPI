import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import 'dcc_session.dart';

class DccApiClient {
  DccApiClient._();

  static String get baseUrl {
    final value = (dotenv.env['EQMS_API_BASE_URL'] ?? '').trim();
    if (value.isEmpty) {
      throw Exception('EQMS_API_BASE_URL is missing from the Flutter root .env file.');
    }
    return value.replaceAll(RegExp(r'/+$'), '');
  }

  static Map<String, String> _headers({bool authenticated = true}) {
    final headers = <String, String>{'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (authenticated) {
      final token = DccSession.currentUser?.sessionToken ?? '';
      if (token.isEmpty) throw Exception('Your DCC session has expired. Please log in again.');
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  static Future<dynamic> get(String path, {bool authenticated = true, Map<String, String>? query}) async {
    final uri = Uri.parse('$baseUrl/api/v1/dcc$path').replace(queryParameters: query);
    return _decode(await http.get(uri, headers: _headers(authenticated: authenticated)));
  }

  static Future<dynamic> post(String path, {Object? body, bool authenticated = true}) async {
    final uri = Uri.parse('$baseUrl/api/v1/dcc$path');
    return _decode(await http.post(uri, headers: _headers(authenticated: authenticated), body: jsonEncode(body ?? {})));
  }

  static Future<dynamic> patch(String path, {Object? body}) async {
    final uri = Uri.parse('$baseUrl/api/v1/dcc$path');
    return _decode(await http.patch(uri, headers: _headers(), body: jsonEncode(body ?? {})));
  }

  static Future<dynamic> delete(String path) async {
    final uri = Uri.parse('$baseUrl/api/v1/dcc$path');
    return _decode(await http.delete(uri, headers: _headers()));
  }

  static dynamic _decode(http.Response response) {
    dynamic data;
    try { data = response.body.isEmpty ? null : jsonDecode(response.body); }
    catch (_) { throw Exception('FastAPI returned a non-JSON response (${response.statusCode}). Check EQMS_API_BASE_URL and backend routing.'); }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final detail = data is Map ? (data['detail'] ?? data['message']) : null;
      throw Exception(detail?.toString() ?? 'DCC API request failed (${response.statusCode}).');
    }
    return data;
  }
}
