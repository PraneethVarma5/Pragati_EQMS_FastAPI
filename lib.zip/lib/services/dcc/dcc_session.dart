import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../models/dcc/dcc_user.dart';
import '../session_activity.dart';

class DccSession {
  static DccUser? currentUser;

  static const String _sessionKey =
      'dcc_active_session';

  static void setUser(DccUser user) {
    currentUser = user;

    _saveSession(user);

    // A fresh login always gets a full idle window, even if the
    // browser had been sitting idle before this login happened.
    // ignore: discarded_futures
    SessionActivity.reset();
  }

  static Future<void> _saveSession(
      DccUser user,
      ) async {
    final prefs =
    await SharedPreferences.getInstance();

    await prefs.setString(
      _sessionKey,
      jsonEncode({
        'id': user.id,
        'name': user.name,
        'email': user.email,
        'role': user.role,
        'hodName': user.hodName,
        'hodEmail': user.hodEmail,
        'active': user.active,
      }),
    );
  }

  static Future<bool> restoreSession() async {
    try {
      final prefs =
      await SharedPreferences.getInstance();

      final raw =
      prefs.getString(_sessionKey);

      if (raw == null ||
          raw.trim().isEmpty) {
        return false;
      }

      final data =
      Map<String, dynamic>.from(
        jsonDecode(raw) as Map,
      );

      final user = DccUser(
        id: data['id']?.toString() ?? '',
        name: data['name']?.toString() ?? '',
        email: data['email']?.toString() ?? '',
        role: data['role']?.toString() ?? '',
        hodName: data['hodName']?.toString() ?? '',
        hodEmail: data['hodEmail']?.toString() ?? '',
        active: data['active'] == true,
        password: '',
      );

      if (user.email.trim().isEmpty ||
          user.role.trim().isEmpty) {
        await clear();
        return false;
      }

      // Session data is still on disk (survives a refresh), but if
      // nobody has touched the app in 30+ minutes it's been idle
      // too long — log them out instead of silently restoring.
      if (await SessionActivity.isExpired()) {
        await clear();
        return false;
      }

      currentUser = user;

      return true;
    } catch (_) {
      await clear();
      return false;
    }
  }

  static Future<void> clear() async {
    currentUser = null;

    final prefs =
    await SharedPreferences.getInstance();

    await prefs.remove(_sessionKey);
  }

  static bool get isLoggedIn {
    return currentUser != null;
  }
}