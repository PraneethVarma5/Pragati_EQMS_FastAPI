import 'package:flutter/material.dart';

import '../services/arr_auth_service.dart';
import '../services/arr_session.dart';
import '../screens/arr_login_screen.dart';

/// Wraps every /ARR/* screen. If the ARR module hasn't been
/// unlocked yet, shows the ARR login screen instead of the
/// requested screen. Once unlocked, the session persists across a
/// page reload (mirrors AdminGuard / DccGuard) — it only asks
/// again after 30 minutes of no activity anywhere in the app (see
/// SessionActivity), or after an explicit logout.
///
/// /ARR/admin/* routes are wrapped in BOTH this AND AdminGuard —
/// the admin area needs its own separate password on top of the
/// general ARR one.
class ArrGuard extends StatefulWidget {
  final Widget child;

  const ArrGuard({super.key, required this.child});

  @override
  State<ArrGuard> createState() => _ArrGuardState();
}

class _ArrGuardState extends State<ArrGuard> {
  late bool _unlocked = ArrSession.isUnlocked;

  void _onUnlocked() {
    setState(() {
      _unlocked = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_unlocked) {
      return widget.child;
    }

    return ArrLoginScreen(onUnlocked: _onUnlocked);
  }
}
