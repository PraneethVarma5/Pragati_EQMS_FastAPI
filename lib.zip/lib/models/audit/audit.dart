// // class Audit {
// //   final String auditId;
// //
// //   String? milNumber;
// //
// //   String auditType;
// //
// //   String vendor;
// //   String site;
// //   String lob;
// //   String program;
// //   String line;
// //   String apn;
// //
// //   DateTime auditDate;
// //   String auditorName;
// //
// //   DateTime? startedAt;
// //   DateTime? finishedAt;
// //
// //   String status;
// //
// //   String? currentSection;
// //
// //   Audit({
// //     required this.auditId,
// //     this.milNumber,
// //     required this.auditType,
// //     required this.vendor,
// //     required this.site,
// //     required this.lob,
// //     required this.program,
// //     required this.line,
// //     required this.apn,
// //     required this.auditDate,
// //     required this.auditorName,
// //     this.startedAt,
// //     this.finishedAt,
// //     this.status = 'Draft',
// //     this.currentSection,
// //   });
// //
// //   double? get totalAuditedHours {
// //     if (startedAt == null || finishedAt == null) {
// //       return null;
// //     }
// //
// //     final difference = finishedAt!.difference(startedAt!);
// //
// //     return difference.inSeconds / 3600;
// //   }
// //
// //   Map<String, dynamic> toMap() {
// //     return {
// //       'audit_id': auditId,
// //       'mil_number': milNumber,
// //       'audit_type': auditType,
// //       'vendor': vendor,
// //       'site': site,
// //       'lob': lob,
// //       'program': program,
// //       'line': line,
// //       'apn': apn,
// //       'audit_date': auditDate.toIso8601String(),
// //       'auditor_name': auditorName,
// //       'started_at': startedAt?.toIso8601String(),
// //       'finished_at': finishedAt?.toIso8601String(),
// //       'status': status,
// //       'current_section': currentSection,
// //     };
// //   }
// //
// //   factory Audit.fromMap(Map<String, dynamic> map) {
// //     return Audit(
// //       auditId: map['audit_id'].toString(),
// //       milNumber: map['mil_number']?.toString(),
// //       auditType: map['audit_type']?.toString() ?? '',
// //       vendor: map['vendor']?.toString() ?? '',
// //       site: map['site']?.toString() ?? '',
// //       lob: map['lob']?.toString() ?? '',
// //       program: map['program']?.toString() ?? '',
// //       line: map['line']?.toString() ?? '',
// //       apn: map['apn']?.toString() ?? '',
// //       auditDate: DateTime.tryParse(
// //         map['audit_date']?.toString() ?? '',
// //       ) ??
// //           DateTime.now(),
// //       auditorName:
// //       map['auditor_name']?.toString() ?? '',
// //       startedAt: map['started_at'] == null
// //           ? null
// //           : DateTime.tryParse(
// //         map['started_at'].toString(),
// //       ),
// //       finishedAt: map['finished_at'] == null
// //           ? null
// //           : DateTime.tryParse(
// //         map['finished_at'].toString(),
// //       ),
// //       status: map['status']?.toString() ?? 'Draft',
// //       currentSection:
// //       map['current_section']?.toString(),
// //     );
// //   }
// // }
// //
// // class Audit {
// //   final String auditId;
// //
// //   String? milNumber;
// //
// //   String auditType;
// //
// //   String vendor;
// //   String site;
// //   String lob;
// //   String program;
// //   String line;
// //   String apn;
// //
// //   DateTime auditDate;
// //   String auditorName;
// //
// //   DateTime? startedAt;
// //   DateTime? finishedAt;
// //
// //   String status;
// //
// //   String? currentSection;
// //
// //   Audit({
// //     required this.auditId,
// //     this.milNumber,
// //     required this.auditType,
// //     required this.vendor,
// //     required this.site,
// //     required this.lob,
// //     required this.program,
// //     required this.line,
// //     required this.apn,
// //     required this.auditDate,
// //     required this.auditorName,
// //     this.startedAt,
// //     this.finishedAt,
// //     this.status = 'Draft',
// //     this.currentSection,
// //   });
// //
// //   // ============================================================
// //   // TOTAL AUDITED HOURS
// //   // ============================================================
// //
// //   double? get totalAuditedHours {
// //     if (startedAt == null ||
// //         finishedAt == null) {
// //       return null;
// //     }
// //
// //     final difference =
// //     finishedAt!
// //         .difference(
// //       startedAt!,
// //     );
// //
// //     return difference.inSeconds /
// //         3600;
// //   }
// //
// //   // ============================================================
// //   // MAP
// //   // ============================================================
// //
// //   Map<String, dynamic> toMap() {
// //     return {
// //       'audit_id': auditId,
// //       'mil_number': milNumber,
// //       'audit_type': auditType,
// //       'vendor': vendor,
// //       'site': site,
// //       'lob': lob,
// //       'program': program,
// //       'line': line,
// //       'apn': apn,
// //
// //       // Supabase date column is DATE.
// //       'audit_date':
// //       '${auditDate.year}-'
// //           '${auditDate.month.toString().padLeft(2, '0')}-'
// //           '${auditDate.day.toString().padLeft(2, '0')}',
// //
// //       'auditor_name':
// //       auditorName,
// //
// //       'started_at':
// //       startedAt
// //           ?.toIso8601String(),
// //
// //       'finished_at':
// //       finishedAt
// //           ?.toIso8601String(),
// //
// //       'status': status,
// //
// //       'current_section':
// //       currentSection,
// //     };
// //   }
// //
// //   // ============================================================
// //   // FROM MAP
// //   // ============================================================
// //
// //   factory Audit.fromMap(
// //       Map<String, dynamic> map) {
// //     return Audit(
// //       auditId:
// //       map['audit_id']
// //           ?.toString() ??
// //           '',
// //
// //       milNumber:
// //       map['mil_number']
// //           ?.toString(),
// //
// //       auditType:
// //       map['audit_type']
// //           ?.toString() ??
// //           '',
// //
// //       vendor:
// //       map['vendor']
// //           ?.toString() ??
// //           '',
// //
// //       site:
// //       map['site']
// //           ?.toString() ??
// //           '',
// //
// //       lob:
// //       map['lob']
// //           ?.toString() ??
// //           '',
// //
// //       program:
// //       map['program']
// //           ?.toString() ??
// //           '',
// //
// //       line:
// //       map['line']
// //           ?.toString() ??
// //           '',
// //
// //       apn:
// //       map['apn']
// //           ?.toString() ??
// //           '',
// //
// //       auditDate:
// //       DateTime.tryParse(
// //         map['audit_date']
// //             ?.toString() ??
// //             '',
// //       ) ??
// //           DateTime.now(),
// //
// //       auditorName:
// //       map['auditor_name']
// //           ?.toString() ??
// //           '',
// //
// //       startedAt:
// //       map['started_at'] == null
// //           ? null
// //           : DateTime.tryParse(
// //         map['started_at']
// //             .toString(),
// //       ),
// //
// //       finishedAt:
// //       map['finished_at'] == null
// //           ? null
// //           : DateTime.tryParse(
// //         map['finished_at']
// //             .toString(),
// //       ),
// //
// //       status:
// //       map['status']
// //           ?.toString() ??
// //           'Draft',
// //
// //       currentSection:
// //       map['current_section']
// //           ?.toString(),
// //     );
// //   }
// // }
// class Audit {
//   final String auditId;
//
//   String? milNumber;
//
//   String auditType;
//
//   String vendor;
//   String site;
//   String lob;
//   String program;
//   String line;
//   String apn;
//
//   DateTime auditDate;
//   String auditorName;
//
//   /// Time when the audit was created/started.
//   DateTime? startedAt;
//
//   /// Time when all audit categories were completed.
//   DateTime? finishedAt;
//
//   /// Total manually entered time across all categories.
//   double totalTimeTakenHours;
//
//   String status;
//
//   String? currentSection;
//
//   Audit({
//     required this.auditId,
//     this.milNumber,
//     required this.auditType,
//     required this.vendor,
//     required this.site,
//     required this.lob,
//     required this.program,
//     required this.line,
//     required this.apn,
//     required this.auditDate,
//     required this.auditorName,
//     this.startedAt,
//     this.finishedAt,
//     this.totalTimeTakenHours = 0,
//     this.status = 'Draft',
//     this.currentSection,
//   });
//
//   // ============================================================
//   // TOTAL AUDITED HOURS
//   // ============================================================
//
//   double get totalAuditedHours {
//     return totalTimeTakenHours;
//   }
//   // ============================================================
//   // MAP
//   // ============================================================
//
//   Map<String, dynamic> toMap() {
//     return {
//       'audit_id': auditId,
//       'mil_number': milNumber,
//       'audit_type': auditType,
//       'vendor': vendor,
//       'site': site,
//       'lob': lob,
//       'program': program,
//       'line': line,
//       'apn':
//       '${auditDate.year}-'
//           '${auditDate.month.toString().padLeft(2, '0')}-'
//           '${auditDate.day.toString().padLeft(2, '0')}',
//       'audit_date':
//       '${auditDate.year}-'
//           '${auditDate.month.toString().padLeft(2, '0')}-'
//           '${auditDate.day.toString().padLeft(2, '0')}',
//       'auditor_name': auditorName,
//       'started_at':
//       startedAt?.toIso8601String(),
//       'finished_at':
//       finishedAt?.toIso8601String(),
//       'total_time_taken_hours':
//       totalTimeTakenHours,
//       'status': status,
//       'current_section': currentSection,
//     };
//   }
//
//   // ============================================================
//   // FROM MAP
//   // ============================================================
//
//   factory Audit.fromMap(
//       Map<String, dynamic> map) {
//     return Audit(
//       auditId:
//       map['audit_id']
//           ?.toString() ??
//           '',
//
//       milNumber:
//       map['mil_number']
//           ?.toString(),
//
//       auditType:
//       map['audit_type']
//           ?.toString() ??
//           '',
//
//       vendor:
//       map['vendor']
//           ?.toString() ??
//           '',
//
//       site:
//       map['site']
//           ?.toString() ??
//           '',
//
//       lob:
//       map['lob']
//           ?.toString() ??
//           '',
//
//       program:
//       map['program']
//           ?.toString() ??
//           '',
//
//       line:
//       map['line']
//           ?.toString() ??
//           '',
//
//       apn:
//       map['apn']
//           ?.toString() ??
//           '',
//
//       auditDate:
//       DateTime.tryParse(
//         map['audit_date']
//             ?.toString() ??
//             '',
//       ) ??
//           DateTime.now(),
//
//       auditorName:
//       map['auditor_name']
//           ?.toString() ??
//           '',
//
//       startedAt:
//       map['started_at'] == null
//           ? null
//           : DateTime.tryParse(
//         map['started_at']
//             .toString(),
//       ),
//
//       finishedAt:
//       map['finished_at'] == null
//           ? null
//           : DateTime.tryParse(
//         map['finished_at']
//             .toString(),
//       ),
//
//       totalTimeTakenHours:
//       (map['total_time_taken_hours'] as num?)
//           ?.toDouble() ??
//           0,
//
//       status:
//       map['status']
//           ?.toString() ??
//           'Draft',
//
//       currentSection:
//       map['current_section']
//           ?.toString(),
//     );
//   }
// }

// class Audit {
//   final String auditId;
//
//   String? milNumber;
//
//   String auditType;
//
//   String vendor;
//   String site;
//   String lob;
//   String program;
//   String line;
//   String apn;
//
//   DateTime auditDate;
//   String auditorName;
//
//   DateTime? startedAt;
//   DateTime? finishedAt;
//
//   /// Total manually entered audit time in hours.
//   ///
//   /// This is the sum of the time entered for
//   /// each completed category.
//   double totalTimeTakenHours;
//
//   String status;
//
//   String? currentSection;
//
//   Audit({
//     required this.auditId,
//     this.milNumber,
//     required this.auditType,
//     required this.vendor,
//     required this.site,
//     required this.lob,
//     required this.program,
//     required this.line,
//     required this.apn,
//     required this.auditDate,
//     required this.auditorName,
//     this.startedAt,
//     this.finishedAt,
//     this.totalTimeTakenHours = 0,
//     this.status = 'Draft',
//     this.currentSection,
//   });
//
//   /// Total audited hours.
//   ///
//   /// Time is entered manually per category.
//   /// It is NOT calculated from startedAt / finishedAt.
//   double get totalAuditedHours {
//     return totalTimeTakenHours;
//   }
//
//   Map<String, dynamic> toMap() {
//     return {
//       'audit_id': auditId,
//       'mil_number': milNumber,
//       'audit_type': auditType,
//       'vendor': vendor,
//       'site': site,
//       'lob': lob,
//       'program': program,
//       'line': line,
//       'apn': apn,
//       'audit_date':
//       auditDate.toIso8601String(),
//       'auditor_name': auditorName,
//       'started_at':
//       startedAt?.toIso8601String(),
//       'finished_at':
//       finishedAt?.toIso8601String(),
//
//       'total_time_taken_hours':
//       totalTimeTakenHours,
//
//       'status': status,
//       'current_section': currentSection,
//     };
//   }
//
//   factory Audit.fromMap(
//       Map<String, dynamic> map,
//       ) {
//     return Audit(
//       auditId:
//       map['audit_id'].toString(),
//
//       milNumber:
//       map['mil_number']?.toString(),
//
//       auditType:
//       map['audit_type']?.toString() ??
//           '',
//
//       vendor:
//       map['vendor']?.toString() ??
//           '',
//
//       site:
//       map['site']?.toString() ??
//           '',
//
//       lob:
//       map['lob']?.toString() ??
//           '',
//
//       program:
//       map['program']?.toString() ??
//           '',
//
//       line:
//       map['line']?.toString() ??
//           '',
//
//       apn:
//       map['apn']?.toString() ??
//           '',
//
//       auditDate:
//       DateTime.tryParse(
//         map['audit_date']
//             ?.toString() ??
//             '',
//       ) ??
//           DateTime.now(),
//
//       auditorName:
//       map['auditor_name']
//           ?.toString() ??
//           '',
//
//       startedAt:
//       map['started_at'] == null
//           ? null
//           : DateTime.tryParse(
//         map['started_at']
//             .toString(),
//       ),
//
//       finishedAt:
//       map['finished_at'] == null
//           ? null
//           : DateTime.tryParse(
//         map['finished_at']
//             .toString(),
//       ),
//
//       totalTimeTakenHours:
//       (map['total_time_taken_hours']
//       as num?)
//           ?.toDouble() ??
//           0,
//
//       status:
//       map['status']?.toString() ??
//           'Draft',
//
//       currentSection:
//       map['current_section']
//           ?.toString(),
//     );
//   }
// }

class Audit {
  final String auditId;

  String? milNumber;

  String auditType;

  String vendor;
  String site;
  String lob;
  String program;
  String line;
  String apn;

  DateTime auditDate;
  String auditorName;

  /// Timestamp when the audit was created/started.
  ///
  /// This is kept for audit history only.
  /// It is NOT used to calculate audited hours.
  DateTime? startedAt;

  /// Timestamp when all checklist categories were completed.
  ///
  /// This is kept for audit history only.
  /// It is NOT used to calculate audited hours.
  DateTime? finishedAt;

  /// ONE overall audit duration entered manually
  /// by the auditor on the Audit Details screen.
  ///
  /// Example:
  /// Time Taken = 2.00 hours
  ///
  /// This value is used directly for:
  /// - Audited Hours
  /// - CPH
  /// - Audit reports
  /// - Audit Home
  double totalTimeTakenHours;

  String status;

  /// Current category being worked on.
  String? currentSection;

  Audit({
    required this.auditId,
    this.milNumber,
    required this.auditType,
    required this.vendor,
    required this.site,
    required this.lob,
    required this.program,
    required this.line,
    required this.apn,
    required this.auditDate,
    required this.auditorName,
    this.startedAt,
    this.finishedAt,
    this.totalTimeTakenHours = 0,
    this.status = 'Draft',
    this.currentSection,
  });

  // ============================================================
  // AUDITED HOURS
  // ============================================================

  /// Returns the manually entered overall audit time.
  ///
  /// NEVER calculates duration from startedAt / finishedAt.
  double get totalAuditedHours {
    return totalTimeTakenHours < 0
        ? 0
        : totalTimeTakenHours;
  }

  // ============================================================
  // TO MAP
  // ============================================================

  Map<String, dynamic> toMap() {
    return {
      'audit_id': auditId,

      'mil_number': milNumber,

      'audit_type': auditType,

      'vendor': vendor,

      'site': site,

      'lob': lob,

      'program': program,

      'line': line,

      'apn': apn,

      'audit_date':
      '${auditDate.year}-'
          '${auditDate.month.toString().padLeft(2, '0')}-'
          '${auditDate.day.toString().padLeft(2, '0')}',

      'auditor_name': auditorName,

      // These are informational timestamps only.
      'started_at':
      startedAt?.toIso8601String(),

      'finished_at':
      finishedAt?.toIso8601String(),

      // IMPORTANT:
      // This is the ONLY value used for audited hours.
      'total_time_taken_hours':
      totalTimeTakenHours,

      'status': status,

      'current_section': currentSection,
    };
  }

  // ============================================================
  // FROM MAP
  // ============================================================

  factory Audit.fromMap(
      Map<String, dynamic> map,
      ) {
    final rawTime =
    map['total_time_taken_hours'];

    double parsedTime = 0;

    if (rawTime is num) {
      parsedTime = rawTime.toDouble();
    } else if (rawTime != null) {
      parsedTime =
          double.tryParse(
            rawTime.toString(),
          ) ??
              0;
    }

    if (parsedTime < 0) {
      parsedTime = 0;
    }

    return Audit(
      auditId:
      map['audit_id']?.toString() ??
          '',

      milNumber:
      map['mil_number']?.toString(),

      auditType:
      map['audit_type']?.toString() ??
          '',

      vendor:
      map['vendor']?.toString() ??
          '',

      site:
      map['site']?.toString() ??
          '',

      lob:
      map['lob']?.toString() ??
          '',

      program:
      map['program']?.toString() ??
          '',

      line:
      map['line']?.toString() ??
          '',

      apn:
      map['apn']?.toString() ??
          '',

      auditDate:
      DateTime.tryParse(
        map['audit_date']
            ?.toString() ??
            '',
      ) ??
          DateTime.now(),

      auditorName:
      map['auditor_name']
          ?.toString() ??
          '',

      startedAt:
      map['started_at'] == null
          ? null
          : DateTime.tryParse(
        map['started_at']
            .toString(),
      ),

      finishedAt:
      map['finished_at'] == null
          ? null
          : DateTime.tryParse(
        map['finished_at']
            .toString(),
      ),

      totalTimeTakenHours:
      parsedTime,

      status:
      map['status']?.toString() ??
          'Draft',

      currentSection:
      map['current_section']
          ?.toString(),
    );
  }
}