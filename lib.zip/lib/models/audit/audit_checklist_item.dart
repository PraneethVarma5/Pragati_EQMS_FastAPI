class AuditChecklistItem {
  final String id;
  final String section;
  final int number;
  final String question;

  const AuditChecklistItem({
    required this.id,
    required this.section,
    required this.number,
    required this.question,
  });
}