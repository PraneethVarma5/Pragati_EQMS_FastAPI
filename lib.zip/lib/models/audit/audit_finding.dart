// enum FindingCategory {
//   critical,
//   major,
//   minor,
// }
//
// extension FindingCategoryExtension on FindingCategory {
//   String get value {
//     switch (this) {
//       case FindingCategory.critical:
//         return 'Critical';
//       case FindingCategory.major:
//         return 'Major';
//       case FindingCategory.minor:
//         return 'Minor';
//     }
//   }
//
//   static FindingCategory fromString(String value) {
//     switch (value.toLowerCase()) {
//       case 'critical':
//         return FindingCategory.critical;
//       case 'major':
//         return FindingCategory.major;
//       case 'minor':
//         return FindingCategory.minor;
//       default:
//         return FindingCategory.minor;
//     }
//   }
// }
//
// class AuditFinding {
//   final String id;
//   final String auditId;
//   final String section;
//   final String checklistItemId;
//   final int questionNumber;
//   final String question;
//   final String answer;
//   final String description;
//
//   FindingCategory? category;
//
//   String issue;
//   String rootCause;
//   String correctiveAction;
//   String driName;
//   String mailId;
//   DateTime? deadline;
//   String overallStatus;
//
//   AuditFinding({
//     required this.id,
//     required this.auditId,
//     required this.section,
//     required this.checklistItemId,
//     required this.questionNumber,
//     required this.question,
//     required this.answer,
//     required this.description,
//     this.category,
//     this.issue = '',
//     this.rootCause = '',
//     this.correctiveAction = '',
//     this.driName = '',
//     this.mailId = '',
//     this.deadline,
//     this.overallStatus = 'Open',
//   });
//
//   Map<String, dynamic> toMap() {
//     return {
//       'finding_id': id,
//       'audit_id': auditId,
//       'section': section,
//       'checklist_item_id': checklistItemId,
//       'question_number': questionNumber,
//       'question': question,
//       'answer': answer,
//       'description': description,
//       'finding_category': category?.value,
//       'issue': issue,
//       'root_cause': rootCause,
//       'corrective_action': correctiveAction,
//       'dri_name': driName,
//       'mail_id': mailId,
//       'deadline': deadline?.toIso8601String(),
//       'overall_status': overallStatus,
//     };
//   }
//
//   factory AuditFinding.fromMap(Map<String, dynamic> map) {
//     return AuditFinding(
//       id: map['finding_id'].toString(),
//       auditId: map['audit_id'].toString(),
//       section: map['section']?.toString() ?? '',
//       checklistItemId:
//       map['checklist_item_id']?.toString() ?? '',
//       questionNumber:
//       (map['question_number'] as num?)?.toInt() ?? 0,
//       question: map['question']?.toString() ?? '',
//       answer: map['answer']?.toString() ?? 'No',
//       description:
//       map['description']?.toString() ?? '',
//       category: map['finding_category'] == null
//           ? null
//           : FindingCategoryExtension.fromString(
//         map['finding_category'].toString(),
//       ),
//       issue: map['issue']?.toString() ?? '',
//       rootCause: map['root_cause']?.toString() ?? '',
//       correctiveAction:
//       map['corrective_action']?.toString() ?? '',
//       driName: map['dri_name']?.toString() ?? '',
//       mailId: map['mail_id']?.toString() ?? '',
//       deadline: map['deadline'] == null
//           ? null
//           : DateTime.tryParse(
//         map['deadline'].toString(),
//       ),
//       overallStatus:
//       map['overall_status']?.toString() ?? 'Open',
//     );
//   }
// }

// enum FindingCategory {
//   critical,
//   major,
//   minor,
// }
//
// extension FindingCategoryExtension
// on FindingCategory {
//   String get value {
//     switch (this) {
//       case FindingCategory.critical:
//         return 'Critical';
//
//       case FindingCategory.major:
//         return 'Major';
//
//       case FindingCategory.minor:
//         return 'Minor';
//     }
//   }
//
//   static FindingCategory fromString(
//       String value) {
//     switch (
//     value.trim().toLowerCase()) {
//       case 'critical':
//         return FindingCategory.critical;
//
//       case 'major':
//         return FindingCategory.major;
//
//       case 'minor':
//         return FindingCategory.minor;
//
//       default:
//         return FindingCategory.minor;
//     }
//   }
// }
//
// class AuditFinding {
//   final String id;
//   final String auditId;
//
//   final String section;
//   final String checklistItemId;
//
//   final int questionNumber;
//   final String question;
//
//   // Kept in the model because a finding originates
//   // from a "No" checklist answer.
//   //
//   // IMPORTANT:
//   // It is NOT persisted to audit_findings because
//   // the database table has no answer column.
//   final String answer;
//
//   final String description;
//
//   FindingCategory? category;
//
//   String issue;
//   String rootCause;
//   String correctiveAction;
//   String driName;
//   String mailId;
//
//   DateTime? deadline;
//
//   String overallStatus;
//
//   AuditFinding({
//     required this.id,
//     required this.auditId,
//     required this.section,
//     required this.checklistItemId,
//     required this.questionNumber,
//     required this.question,
//     required this.answer,
//     required this.description,
//     this.category,
//     this.issue = '',
//     this.rootCause = '',
//     this.correctiveAction = '',
//     this.driName = '',
//     this.mailId = '',
//     this.deadline,
//     this.overallStatus = 'Open',
//   });
//
//   Map<String, dynamic> toMap() {
//     return {
//       'finding_id': id,
//       'audit_id': auditId,
//       'section': section,
//       'checklist_item_id':
//       checklistItemId,
//       'question_number':
//       questionNumber,
//       'question': question,
//
//       // DO NOT send "answer".
//       //
//       // audit_findings does not contain
//       // an answer column.
//
//       'description': description,
//
//       'finding_category':
//       category?.value,
//
//       'issue': issue,
//       'root_cause': rootCause,
//       'corrective_action':
//       correctiveAction,
//       'dri_name': driName,
//       'mail_id': mailId,
//       'deadline':
//       deadline?.toIso8601String(),
//       'overall_status':
//       overallStatus,
//     };
//   }
//
//   factory AuditFinding.fromMap(
//       Map<String, dynamic> map) {
//     return AuditFinding(
//       id: map['finding_id']
//           ?.toString() ??
//           '',
//
//       auditId: map['audit_id']
//           ?.toString() ??
//           '',
//
//       section: map['section']
//           ?.toString() ??
//           '',
//
//       checklistItemId:
//       map['checklist_item_id']
//           ?.toString() ??
//           '',
//
//       questionNumber:
//       (map['question_number']
//       as num?)
//           ?.toInt() ??
//           0,
//
//       question:
//       map['question']
//           ?.toString() ??
//           '',
//
//       // audit_findings has no answer column.
//       //
//       // Findings are generated only from "No"
//       // checklist answers, so the value is known.
//       answer: 'No',
//
//       description:
//       map['description']
//           ?.toString() ??
//           '',
//
//       category:
//       map['finding_category'] ==
//           null
//           ? null
//           : FindingCategoryExtension
//           .fromString(
//         map['finding_category']
//             .toString(),
//       ),
//
//       issue:
//       map['issue']
//           ?.toString() ??
//           '',
//
//       rootCause:
//       map['root_cause']
//           ?.toString() ??
//           '',
//
//       correctiveAction:
//       map['corrective_action']
//           ?.toString() ??
//           '',
//
//       driName:
//       map['dri_name']
//           ?.toString() ??
//           '',
//
//       mailId:
//       map['mail_id']
//           ?.toString() ??
//           '',
//
//       deadline:
//       map['deadline'] == null
//           ? null
//           : DateTime.tryParse(
//         map['deadline']
//             .toString(),
//       ),
//
//       overallStatus:
//       map['overall_status']
//           ?.toString() ??
//           'Open',
//     );
//   }
// }

enum FindingCategory {
  critical,
  major,
  minor,
}

extension FindingCategoryExtension
on FindingCategory {
  String get value {
    switch (this) {
      case FindingCategory.critical:
        return 'Critical';

      case FindingCategory.major:
        return 'Major';

      case FindingCategory.minor:
        return 'Minor';
    }
  }

  static FindingCategory
  fromString(String value) {
    switch (
    value.trim().toLowerCase()) {
      case 'critical':
        return FindingCategory.critical;

      case 'major':
        return FindingCategory.major;

      case 'minor':
        return FindingCategory.minor;

      default:
        return FindingCategory.minor;
    }
  }
}

class AuditFinding {
  final String id;
  final String auditId;

  final String section;
  final String checklistItemId;

  final int questionNumber;
  final String question;

  /// Always "No" because findings originate
  /// from failed checklist answers.
  final String answer;

  /// Original checklist description.
  ///
  /// This is kept in memory for the UI/PDF,
  /// but is NOT written to audit_findings.
  final String description;

  FindingCategory? category;

  String issue;
  String rootCause;
  String correctiveAction;
  String driName;
  String mailId;

  DateTime? deadline;

  String overallStatus;

  AuditFinding({
    required this.id,
    required this.auditId,
    required this.section,
    required this.checklistItemId,
    required this.questionNumber,
    required this.question,
    required this.answer,
    required this.description,
    this.category,
    this.issue = '',
    this.rootCause = '',
    this.correctiveAction = '',
    this.driName = '',
    this.mailId = '',
    this.deadline,
    this.overallStatus = 'Open',
  });

  // ============================================================
  // MAP FOR audit_findings
  //
  // IMPORTANT:
  // Only columns that actually exist in the database
  // are sent.
  // ============================================================

  Map<String, dynamic> toMap() {
    final effectiveIssue =
    issue.trim().isNotEmpty
        ? issue.trim()
        : description.trim();

    return {
      'finding_id': id,
      'audit_id': auditId,
      'section': section,
      'checklist_item_id':
      checklistItemId,
      'question_number':
      questionNumber,
      'question': question,

      // Description is stored as issue.
      //
      // audit_findings has "issue",
      // NOT "description".
      'issue': effectiveIssue,

      'finding_category':
      category?.value,

      'root_cause':
      rootCause.trim(),

      'corrective_action':
      correctiveAction.trim(),

      'dri_name':
      driName.trim(),

      'mail_id':
      mailId.trim(),

      'deadline':
      deadline == null
          ? null
          : '${deadline!.year}-'
          '${deadline!.month.toString().padLeft(2, '0')}-'
          '${deadline!.day.toString().padLeft(2, '0')}',

      'overall_status':
      overallStatus,

      'updated_at':
      DateTime.now()
          .toIso8601String(),
    };
  }

  // ============================================================
  // FROM DATABASE
  // ============================================================

  factory AuditFinding.fromMap(
      Map<String, dynamic> map) {
    final issue =
        map['issue']
            ?.toString() ??
            '';

    return AuditFinding(
      id:
      map['finding_id']
          ?.toString() ??
          '',

      auditId:
      map['audit_id']
          ?.toString() ??
          '',

      section:
      map['section']
          ?.toString() ??
          '',

      checklistItemId:
      map['checklist_item_id']
          ?.toString() ??
          '',

      questionNumber:
      (map['question_number']
      as num?)
          ?.toInt() ??
          0,

      question:
      map['question']
          ?.toString() ??
          '',

      answer: 'No',

      // DB stores the issue, so use it
      // as the description fallback too.
      description: issue,

      category:
      map['finding_category'] ==
          null
          ? null
          : FindingCategoryExtension
          .fromString(
        map['finding_category']
            .toString(),
      ),

      issue: issue,

      rootCause:
      map['root_cause']
          ?.toString() ??
          '',

      correctiveAction:
      map['corrective_action']
          ?.toString() ??
          '',

      driName:
      map['dri_name']
          ?.toString() ??
          '',

      mailId:
      map['mail_id']
          ?.toString() ??
          '',

      deadline:
      map['deadline'] == null
          ? null
          : DateTime.tryParse(
        map['deadline']
            .toString(),
      ),

      overallStatus:
      map['overall_status']
          ?.toString() ??
          'Open',
    );
  }
}