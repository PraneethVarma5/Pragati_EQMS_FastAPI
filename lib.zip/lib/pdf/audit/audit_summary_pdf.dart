// import 'dart:typed_data';
//
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
//
// import '../../models/audit/audit.dart';
// import '../../models/audit/audit_finding.dart';
// import '../../services/audit/audit_calculation_service.dart';
//
// class AuditSummaryPdf {
//   AuditSummaryPdf._();
//
//   static Future<Uint8List> generate({
//     required Audit audit,
//     required List<AuditFinding> findings,
//     required String milNumber,
//   }) async {
//     final pdf = pw.Document();
//
//     final critical =
//         findings.where(
//               (f) =>
//           f.category ==
//               FindingCategory.critical,
//         ).length;
//
//     final major =
//         findings.where(
//               (f) =>
//           f.category ==
//               FindingCategory.major,
//         ).length;
//
//     final minor =
//         findings.where(
//               (f) =>
//           f.category ==
//               FindingCategory.minor,
//         ).length;
//
//     final hours =
//     AuditCalculationService
//         .auditedHours(audit);
//
//     final cph =
//     AuditCalculationService.cph(
//       audit: audit,
//       findings: findings,
//     );
//
//     final score =
//     AuditCalculationService.auditScore(
//       audit: audit,
//       findings: findings,
//     );
//
//     pdf.addPage(
//       pw.MultiPage(
//         pageFormat: PdfPageFormat.a4.landscape,
//         margin:
//         const pw.EdgeInsets.all(25),
//         build: (context) {
//           return [
//             pw.Center(
//               child: pw.Text(
//                 'Audit Summary',
//                 style: pw.TextStyle(
//                   fontSize: 22,
//                   fontWeight:
//                   pw.FontWeight.bold,
//                 ),
//               ),
//             ),
//             pw.SizedBox(height: 20),
//
//             pw.Table(
//               border:
//               pw.TableBorder.all(),
//               children: [
//                 _row(
//                   'MIL Number',
//                   milNumber,
//                 ),
//                 _row(
//                   'Audit Type',
//                   audit.auditType,
//                 ),
//                 _row(
//                   'Audited Date',
//                   audit.auditDate
//                       .toString()
//                       .split(' ')
//                       .first,
//                 ),
//                 _row(
//                   'Vendor',
//                   audit.vendor,
//                 ),
//                 _row(
//                   'Site',
//                   audit.site,
//                 ),
//                 _row(
//                   'LOB',
//                   audit.lob,
//                 ),
//                 _row(
//                   'Program',
//                   audit.program,
//                 ),
//                 _row(
//                   'Line',
//                   audit.line,
//                 ),
//                 _row(
//                   'APN',
//                   audit.apn,
//                 ),
//                 _row(
//                   'Auditor',
//                   audit.auditorName,
//                 ),
//                 _row(
//                   'Status',
//                   audit.status,
//                 ),
//                 _row(
//                   'Started Time',
//                   audit.startedAt
//                       ?.toLocal()
//                       .toString() ??
//                       '',
//                 ),
//                 _row(
//                   'Finished Time',
//                   audit.finishedAt
//                       ?.toLocal()
//                       .toString() ??
//                       '',
//                 ),
//                 _row(
//                   'Total Audited Hours',
//                   hours.toStringAsFixed(2),
//                 ),
//                 _row(
//                   'Critical Findings',
//                   '$critical',
//                 ),
//                 _row(
//                   'Major Findings',
//                   '$major',
//                 ),
//                 _row(
//                   'Minor Findings',
//                   '$minor',
//                 ),
//
//                 _row(
//                   'CPH',
//                   cph.toStringAsFixed(2),
//                 ),
//                 if (audit.auditType == 'Process Audit' ||
//                     audit.auditType == 'System Audit')
//                   _row(
//                     'Audit Score',
//                     score.toStringAsFixed(2),
//                   ),
//               ],
//             ),
//
//             pw.SizedBox(height: 25),
//
//             pw.Text(
//               'Findings',
//               style: pw.TextStyle(
//                 fontSize: 16,
//                 fontWeight:
//                 pw.FontWeight.bold,
//               ),
//             ),
//
//             pw.SizedBox(height: 10),
//
//             pw.Table.fromTextArray(
//               border:
//               pw.TableBorder.all(),
//               headers: const [
//                 'No.',
//                 'Section',
//                 'Question',
//                 'Category',
//                 'Status',
//               ],
//               data: findings
//                   .asMap()
//                   .entries
//                   .map(
//                     (entry) {
//                   final f =
//                       entry.value;
//
//                   return [
//                     '${entry.key + 1}',
//                     f.section,
//                     f.question,
//                     f.category?.value ??
//                         '',
//                     f.overallStatus,
//                   ];
//                 },
//               ).toList(),
//             ),
//           ];
//         },
//       ),
//     );
//
//     return pdf.save();
//   }
//
//   static pw.TableRow _row(
//       String label,
//       String value,
//       ) {
//     return pw.TableRow(
//       children: [
//         pw.Padding(
//           padding:
//           const pw.EdgeInsets.all(6),
//           child: pw.Text(
//             label,
//             style: pw.TextStyle(
//               fontWeight:
//               pw.FontWeight.bold,
//               fontSize: 9,
//             ),
//           ),
//         ),
//         pw.Padding(
//           padding:
//           const pw.EdgeInsets.all(6),
//           child: pw.Text(
//             value,
//             style:
//             const pw.TextStyle(
//               fontSize: 9,
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_calculation_service.dart';

class AuditSummaryPdf {
  AuditSummaryPdf._();

  // ============================================================
  // SINGLE AUDIT SUMMARY
  // ============================================================

  static Future<Uint8List> generate({
    required Audit audit,
    required List<AuditFinding> findings,
    required String milNumber,
  }) async {
    final pdf = pw.Document();

    final critical =
    AuditCalculationService
        .criticalCount(
      findings,
    );

    final major =
    AuditCalculationService
        .majorCount(
      findings,
    );

    final minor =
    AuditCalculationService
        .minorCount(
      findings,
    );

    final hours =
    AuditCalculationService
        .auditedHours(
      audit,
    );

    final cph =
    AuditCalculationService.cph(
      audit: audit,
      findings: findings,
    );

    final score =
    AuditCalculationService
        .auditScore(
      audit: audit,
      findings: findings,
    );

    pdf.addPage(
      pw.MultiPage(
        pageFormat:
        PdfPageFormat.a4.landscape,
        margin:
        const pw.EdgeInsets.all(25),
        build: (context) {
          return [
            pw.Center(
              child: pw.Text(
                'Audit Summary',
                style: pw.TextStyle(
                  fontSize: 22,
                  fontWeight:
                  pw.FontWeight.bold,
                ),
              ),
            ),

            pw.SizedBox(
              height: 20,
            ),

            pw.Table(
              border:
              pw.TableBorder.all(),
              children: [
                _row(
                  'MIL Number',
                  milNumber,
                ),
                _row(
                  'Audit Type',
                  audit.auditType,
                ),
                _row(
                  'Audited Date',
                  _date(audit.auditDate),
                ),
                _row(
                  'Vendor',
                  audit.vendor,
                ),
                _row(
                  'Site',
                  audit.site,
                ),
                _row(
                  'LOB',
                  audit.lob,
                ),
                _row(
                  'Program',
                  audit.program,
                ),
                _row(
                  'Line',
                  audit.line,
                ),
                _row(
                  'APN',
                  audit.apn,
                ),
                _row(
                  'Auditor',
                  audit.auditorName,
                ),
                _row(
                  'Status',
                  audit.status,
                ),
                _row(
                  'Total Audited Hours',
                  hours.toStringAsFixed(2),
                ),
                _row(
                  'Critical Findings',
                  '$critical',
                ),
                _row(
                  'Major Findings',
                  '$major',
                ),
                _row(
                  'Minor Findings',
                  '$minor',
                ),
                _row(
                  'CPH',
                  cph.toStringAsFixed(2),
                ),

                if (audit.auditType ==
                    'Process Audit' ||
                    audit.auditType ==
                        'System Audit')
                  _row(
                    'Audit Score',
                    score.toStringAsFixed(2),
                  ),
              ],
            ),

            pw.SizedBox(
              height: 25,
            ),

            pw.Text(
              'Findings',
              style: pw.TextStyle(
                fontSize: 16,
                fontWeight:
                pw.FontWeight.bold,
              ),
            ),

            pw.SizedBox(
              height: 10,
            ),

            if (findings.isEmpty)
              pw.Text(
                'No findings recorded.',
              )
            else
              pw.Table.fromTextArray(
                border:
                pw.TableBorder.all(),
                headers: const [
                  'No.',
                  'Section',
                  'Question',
                  'Category',
                  'Status',
                ],
                data: findings
                    .asMap()
                    .entries
                    .map(
                      (entry) {
                    final finding =
                        entry.value;

                    return [
                      '${entry.key + 1}',
                      finding.section,
                      finding.question,
                      finding.category
                          ?.value ??
                          '',
                      finding.overallStatus,
                    ];
                  },
                ).toList(),
              ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  // ============================================================
  // ALL AUDITS SUMMARY
  // ============================================================

  static Future<Uint8List> generateAll({
    required List<Audit> audits,
    required Map<String, List<AuditFinding>>
    findingsByAudit,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat:
        PdfPageFormat.a4.landscape,
        margin:
        const pw.EdgeInsets.all(20),
        build: (context) {
          return [
            pw.Center(
              child: pw.Text(
                'Audit Summary - All Audits',
                style: pw.TextStyle(
                  fontSize: 21,
                  fontWeight:
                  pw.FontWeight.bold,
                ),
              ),
            ),

            pw.SizedBox(
              height: 8,
            ),

            pw.Center(
              child: pw.Text(
                'Complete Audit Plan Summary',
                style: const pw.TextStyle(
                  fontSize: 10,
                ),
              ),
            ),

            pw.SizedBox(
              height: 18,
            ),

            pw.Table.fromTextArray(
              border:
              pw.TableBorder.all(),
              cellAlignment:
              pw.Alignment.centerLeft,
              headerStyle:
              pw.TextStyle(
                fontWeight:
                pw.FontWeight.bold,
                fontSize: 8,
              ),
              cellStyle:
              const pw.TextStyle(
                fontSize: 7,
              ),
              headers: const [
                'MIL',
                'Type',
                'Date',
                'Vendor',
                'Site',
                'Auditor',
                'Status',
                'Hours',
                'Critical',
                'Major',
                'Minor',
                'CPH',
                'Score',
                'MIL Status',
              ],
              data: audits.map(
                    (audit) {
                  final findings =
                      findingsByAudit[
                      audit.auditId] ??
                          [];

                  final critical =
                  AuditCalculationService
                      .criticalCount(
                    findings,
                  );

                  final major =
                  AuditCalculationService
                      .majorCount(
                    findings,
                  );

                  final minor =
                  AuditCalculationService
                      .minorCount(
                    findings,
                  );

                  final cph =
                  AuditCalculationService
                      .cph(
                    audit: audit,
                    findings: findings,
                  );

                  final score =
                  AuditCalculationService
                      .auditScore(
                    audit: audit,
                    findings: findings,
                  );

                  return [
                    audit.milNumber ?? '-',
                    audit.auditType,
                    _date(audit.auditDate),
                    audit.vendor,
                    audit.site,
                    audit.auditorName,
                    audit.status,
                    audit.totalTimeTakenHours
                        .toStringAsFixed(2),
                    '$critical',
                    '$major',
                    '$minor',
                    cph.toStringAsFixed(2),
                    audit.auditType ==
                        'Process Audit' ||
                        audit.auditType ==
                            'System Audit'
                        ? score
                        .toStringAsFixed(2)
                        : '-',
                    'Open',
                  ];
                },
              ).toList(),
            ),

            pw.SizedBox(
              height: 18,
            ),

            pw.Text(
              'Calculation Rules',
              style: pw.TextStyle(
                fontSize: 12,
                fontWeight:
                pw.FontWeight.bold,
              ),
            ),

            pw.SizedBox(
              height: 5,
            ),

            pw.Text(
              'CPH = (Critical Findings + Major Findings) / Total Audited Hours',
              style: const pw.TextStyle(
                fontSize: 9,
              ),
            ),

            pw.SizedBox(
              height: 3,
            ),

            pw.Text(
              'Process/System Audit Score = 100 - (20 × Critical) - (5 × Major) - (2 × Minor)',
              style: const pw.TextStyle(
                fontSize: 9,
              ),
            ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  // ============================================================
  // TABLE ROW
  // ============================================================

  static pw.TableRow _row(
      String label,
      String value,
      ) {
    return pw.TableRow(
      children: [
        pw.Padding(
          padding:
          const pw.EdgeInsets.all(6),
          child: pw.Text(
            label,
            style: pw.TextStyle(
              fontWeight:
              pw.FontWeight.bold,
              fontSize: 9,
            ),
          ),
        ),
        pw.Padding(
          padding:
          const pw.EdgeInsets.all(6),
          child: pw.Text(
            value,
            style:
            const pw.TextStyle(
              fontSize: 9,
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // DATE
  // ============================================================

  static String _date(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }
}