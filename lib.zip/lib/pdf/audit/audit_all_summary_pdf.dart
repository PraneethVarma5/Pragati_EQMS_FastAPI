import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';
import '../../services/audit/audit_calculation_service.dart';

class AuditAllSummaryPdf {
  AuditAllSummaryPdf._();

  static Future<Uint8List> generate({
    required List<Audit> audits,
    required Map<String, List<AuditFinding>>
    findingsByAudit,
  }) async {
    final pdf = pw.Document();

    final completedAudits = audits
        .where(
          (audit) =>
      audit.status == 'Completed',
    )
        .toList();

    completedAudits.sort(
          (a, b) =>
          b.auditDate.compareTo(
            a.auditDate,
          ),
    );

    pdf.addPage(
      pw.MultiPage(
        pageFormat:
        PdfPageFormat.a4.landscape,
        margin:
        const pw.EdgeInsets.all(20),
        build: (context) {
          return [
            pw.Center(
              child: pw.Text(
                'Audit Summary',
                style: pw.TextStyle(
                  fontSize: 22,
                  fontWeight:
                  pw.FontWeight.bold,
                ),
              ),
            ),

            pw.SizedBox(height: 6),

            pw.Center(
              child: pw.Text(
                'Completed Audit Register',
                style: const pw.TextStyle(
                  fontSize: 11,
                ),
              ),
            ),

            pw.SizedBox(height: 18),

            if (completedAudits.isEmpty)
              pw.Center(
                child: pw.Padding(
                  padding:
                  const pw.EdgeInsets.all(
                    30,
                  ),
                  child: pw.Text(
                    'No completed audits found.',
                    style:
                    const pw.TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ),
              )
            else
              pw.Table.fromTextArray(
                border:
                pw.TableBorder.all(
                  color: PdfColors.grey600,
                ),
                headerStyle:
                pw.TextStyle(
                  fontSize: 8,
                  fontWeight:
                  pw.FontWeight.bold,
                ),
                cellStyle:
                const pw.TextStyle(
                  fontSize: 7,
                ),
                cellPadding:
                const pw.EdgeInsets.all(
                  5,
                ),
                headers: const [
                  'MIL',
                  'Audit Type',
                  'Date',
                  'Vendor',
                  'Site',
                  'LOB',
                  'Program',
                  'Line',
                  'APN',
                  'Auditor',
                  'Status',
                  'Hours',
                  'Critical',
                  'Major',
                  'Minor',
                  'CPH',
                  'Score',
                  'MIL Status',
                ],
                data: completedAudits
                    .map(
                      (audit) {
                    final findings =
                        findingsByAudit[
                        audit.auditId] ??
                            [];

                    final critical =
                    AuditCalculationService
                        .criticalCount(
                      findings,
                    );

                    final major =
                    AuditCalculationService
                        .majorCount(
                      findings,
                    );

                    final minor =
                    AuditCalculationService
                        .minorCount(
                      findings,
                    );

                    final hours =
                    AuditCalculationService
                        .auditedHours(
                      audit,
                    );

                    final cph =
                    AuditCalculationService
                        .cph(
                      audit: audit,
                      findings: findings,
                    );

                    final score =
                    AuditCalculationService
                        .auditScore(
                      audit: audit,
                      findings: findings,
                    );

                    return [
                      audit.milNumber ?? '-',
                      audit.auditType,
                      _date(
                        audit.auditDate,
                      ),
                      audit.vendor,
                      audit.site,
                      audit.lob,
                      audit.program,
                      audit.line,
                      audit.apn,
                      audit.auditorName,
                      audit.status,
                      hours.toStringAsFixed(2),
                      '$critical',
                      '$major',
                      '$minor',
                      cph.toStringAsFixed(2),
                      audit.auditType ==
                          'Process Audit' ||
                          audit.auditType ==
                              'System Audit'
                          ? score
                          .toStringAsFixed(2)
                          : '-',
                      '-',
                    ];
                  },
                )
                    .toList(),
              ),

            pw.SizedBox(height: 20),

            pw.Text(
              'Generated from completed audits available in Audit Management.',
              style: const pw.TextStyle(
                fontSize: 8,
              ),
            ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  static String _date(
      DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }
}