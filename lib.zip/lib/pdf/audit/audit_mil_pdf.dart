
import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../models/audit/audit.dart';
import '../../models/audit/audit_finding.dart';

class AuditMilPdf {
  AuditMilPdf._();

  static Future<Uint8List> generate({
    required Audit audit,
    required List<AuditFinding> findings,
    required String milNumber,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin:
        const pw.EdgeInsets.all(20),
        build: (context) {
          return [
            pw.Center(
              child: pw.Text(
                'Major Issue List',
                style: pw.TextStyle(
                  fontSize: 20,
                  fontWeight:
                  pw.FontWeight.bold,
                ),
              ),
            ),
            pw.SizedBox(height: 15),

            pw.Table(
              border:
              pw.TableBorder.all(),
              columnWidths: const {
                0: pw.FixedColumnWidth(35),
                1: pw.FlexColumnWidth(2),
                2: pw.FlexColumnWidth(1),
                3: pw.FlexColumnWidth(1.5),
                4: pw.FlexColumnWidth(1.5),
                5: pw.FlexColumnWidth(1),
                6: pw.FlexColumnWidth(1.5),
                7: pw.FlexColumnWidth(1),
                8: pw.FlexColumnWidth(1.2),
              },
              children: [
                _headerRow(),
                ...findings.asMap().entries.map(
                      (entry) {
                    final index =
                        entry.key;
                    final finding =
                        entry.value;

                    return pw.TableRow(
                      children: [
                        _cell(
                          '${index + 1}',
                        ),
                        _cell(
                          finding.issue.isNotEmpty
                              ? finding.issue
                              : finding.description,
                        ),
                        _cell(
                          finding.category
                              ?.value ??
                              '',
                        ),
                        _cell(
                          finding.rootCause,
                        ),
                        _cell(
                          finding
                              .correctiveAction,
                        ),
                        _cell(
                          finding.driName,
                        ),
                        _cell(
                          finding.mailId,
                        ),
                        _cell(
                          finding.deadline
                              ?.toString()
                              .split(
                            ' ',
                          )
                              .first ??
                              '',
                        ),
                        _cell(
                          finding
                              .overallStatus,
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  static pw.TableRow _headerRow() {
    final headers = [
      'No.',
      'Issue',
      'Finding Category',
      'Root Cause',
      'Corrective Action',
      'DRI Name',
      'Mail ID',
      'Deadline',
      'Overall Status',
    ];

    return pw.TableRow(
      children: headers
          .map(
            (header) => pw.Container(
          padding:
          const pw.EdgeInsets.all(5),
          child: pw.Text(
            header,
            style: pw.TextStyle(
              fontWeight:
              pw.FontWeight.bold,
              fontSize: 8,
            ),
          ),
        ),
      )
          .toList(),
    );
  }

  static pw.Widget _cell(String value) {
    return pw.Padding(
      padding:
      const pw.EdgeInsets.all(5),
      child: pw.Text(
        value,
        style: const pw.TextStyle(
          fontSize: 8,
        ),
      ),
    );
  }
}