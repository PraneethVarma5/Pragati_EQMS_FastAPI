import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../models/dcc/dcc_user.dart';

class DccSession {
  static DccUser? currentUser;

  static const String _sessionKey =
      'dcc_active_session';

  static void setUser(DccUser user) {
    currentUser = user;

    _saveSession(user);
  }

  static Future<void> _saveSession(
      DccUser user,
      ) async {
    final prefs =
    await SharedPreferences.getInstance();

    await prefs.setString(
      _sessionKey,
      jsonEncode({
        'id': user.id,
        'name': user.name,
        'email': user.email,
        'role': user.role,
        'hodName': user.hodName,
        'hodEmail': user.hodEmail,
        'active': user.active,
      }),
    );
  }

  static Future<bool> restoreSession() async {
    try {
      final prefs =
      await SharedPreferences.getInstance();

      final raw =
      prefs.getString(_sessionKey);

      if (raw == null ||
          raw.trim().isEmpty) {
        return false;
      }

      final data =
      Map<String, dynamic>.from(
        jsonDecode(raw) as Map,
      );

      final user = DccUser(
        id: data['id']?.toString() ?? '',
        name: data['name']?.toString() ?? '',
        email: data['email']?.toString() ?? '',
        role: data['role']?.toString() ?? '',
        hodName: data['hodName']?.toString() ?? '',
        hodEmail: data['hodEmail']?.toString() ?? '',
        active: data['active'] == true,
        password: '',
      );

      if (user.email.trim().isEmpty ||
          user.role.trim().isEmpty) {
        await clear();
        return false;
      }

      currentUser = user;

      return true;
    } catch (_) {
      await clear();
      return false;
    }
  }

  static Future<void> clear() async {
    currentUser = null;

    final prefs =
    await SharedPreferences.getInstance();

    await prefs.remove(_sessionKey);
  }

  static bool get isLoggedIn {
    return currentUser != null;
  }
}