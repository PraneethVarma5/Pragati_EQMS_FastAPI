import 'package:flutter/material.dart';

import '../../../models/dcc/dcc_document_request.dart';
import '../../../models/dcc/dcc_master_data.dart';
import '../../../services/dcc/dcc_document_request_service.dart';
import '../../../services/dcc/dcc_master_data_service.dart';
import '../../../services/dcc/dcc_notification_service.dart';
import '../../../services/dcc/dcc_session.dart';


class DccDocumentRequestsScreen
    extends StatefulWidget {
  const DccDocumentRequestsScreen({
    super.key,
  });

  @override
  State<DccDocumentRequestsScreen> createState() =>
      _DccDocumentRequestsScreenState();
}

class _DccDocumentRequestsScreenState
    extends State<DccDocumentRequestsScreen> {
  late Future<List<DccDocumentRequest>>
  _requestsFuture;

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  void _loadRequests() {
    _requestsFuture =
        DccDocumentRequestService
            .getPendingRequests();
  }

  Future<void> _refresh() async {
    setState(() {
      _loadRequests();
    });

    await _requestsFuture;
  }

  void _openRequest(
      DccDocumentRequest request,
      ) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            DccDocumentRequestDetailScreen(
              request: request,
            ),
      ),
    ).then((_) {
      _refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        title: const Text(
          'Document Requests',
          style: TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: FutureBuilder<
          List<DccDocumentRequest>>(
        future: _requestsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState ==
              ConnectionState.waiting) {
            return const Center(
              child:
              CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Failed to load requests\n'
                    '${snapshot.error}',
              ),
            );
          }

          final requests =
              snapshot.data ?? [];

          if (requests.isEmpty) {
            return const Center(
              child: Text(
                'No pending document requests.',
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(
                24,
                20,
                24,
                24,
              ),
              itemCount: requests.length,
              itemBuilder:
                  (context, index) {
                final request =
                requests[index];

                return Card(
                  margin: const EdgeInsets.only(bottom: 14),
                  elevation: 1,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: Colors.grey.shade200,
                    ),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => _openRequest(request),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius:
                              BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.description_outlined,
                              color: Colors.blue.shade700,
                              size: 24,
                            ),
                          ),

                          const SizedBox(width: 14),

                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Text(
                                  request.documentName,
                                  maxLines: 2,
                                  overflow:
                                  TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight:
                                    FontWeight.w600,
                                  ),
                                ),

                                const SizedBox(height: 8),

                                Row(
                                  children: [
                                    Icon(
                                      Icons.person_outline,
                                      size: 16,
                                      color:
                                      Colors.grey.shade600,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        request.userName,
                                        overflow:
                                        TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color:
                                          Colors.grey.shade700,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 4),

                                Row(
                                  children: [
                                    Icon(
                                      Icons.email_outlined,
                                      size: 16,
                                      color:
                                      Colors.grey.shade600,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        request.userEmail,
                                        overflow:
                                        TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color:
                                          Colors.grey.shade700,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(width: 12),

                          Container(
                            padding:
                            const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.orange.shade50,
                              borderRadius:
                              BorderRadius.circular(20),
                            ),
                            child: Text(
                              'Pending',
                              style: TextStyle(
                                color: Colors.orange.shade800,
                                fontSize: 12,
                                fontWeight:
                                FontWeight.w600,
                              ),
                            ),
                          ),

                          const SizedBox(width: 8),

                          Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.grey.shade500,
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
class DccDocumentRequestDetailScreen
    extends StatefulWidget {
  final DccDocumentRequest request;

  const DccDocumentRequestDetailScreen({
    super.key,
    required this.request,
  });

  @override
  State<DccDocumentRequestDetailScreen>
  createState() =>
      _DccDocumentRequestDetailScreenState();
}

class _DccDocumentRequestDetailScreenState
    extends State<DccDocumentRequestDetailScreen> {
  late final TextEditingController
  _documentNameController;

  late final TextEditingController
  _documentNoController;

  late final TextEditingController
  _documentTypeController;

  late final TextEditingController
  _departmentController;

  late final TextEditingController
  _candidateNameController;

  late final TextEditingController
  _candidateEmailController;

  bool _saving = false;

  @override
  void initState() {
    super.initState();

    final request = widget.request;

    _documentNameController =
        TextEditingController(
          text: request.documentName,
        );

    _documentNoController =
        TextEditingController(
          text: request.documentNo ?? '',
        );

    _documentTypeController =
        TextEditingController(
          text: request.documentType ?? '',
        );

    _departmentController =
        TextEditingController(
          text: request.department ?? '',
        );

    _candidateNameController =
        TextEditingController(
          text: request.candidateName ??
              request.userName,
        );

    _candidateEmailController =
        TextEditingController(
          text: request.candidateEmail ??
              request.userEmail,
        );
  }

  @override
  void dispose() {
    _documentNameController.dispose();
    _documentNoController.dispose();
    _documentTypeController.dispose();
    _departmentController.dispose();
    _candidateNameController.dispose();
    _candidateEmailController.dispose();
    super.dispose();
  }

  Future<void> _saveAndNotify() async {
    if (_documentNoController.text
        .trim()
        .isEmpty) {
      _showError('Enter document number');
      return;
    }

    if (_documentNameController.text
        .trim()
        .isEmpty) {
      _showError('Enter document name');
      return;
    }

    if (_documentTypeController.text
        .trim()
        .isEmpty) {
      _showError('Enter document type');
      return;
    }

    if (_departmentController.text
        .trim()
        .isEmpty) {
      _showError('Enter department');
      return;
    }

    if (_candidateNameController.text
        .trim()
        .isEmpty) {
      _showError('Enter candidate name');
      return;
    }

    if (_candidateEmailController.text
        .trim()
        .isEmpty) {
      _showError('Enter candidate email');
      return;
    }

    setState(() {
      _saving = true;
    });

    try {
      final currentUser =
          DccSession.currentUser;

      final documentNo =
      _documentNoController.text.trim();

      final documentName =
      _documentNameController.text.trim();

      final documentType =
      _documentTypeController.text.trim();

      final department =
      _departmentController.text.trim();

      final candidateName =
      _candidateNameController.text.trim();

      final candidateEmail =
      _candidateEmailController.text
          .trim()
          .toLowerCase();

      // 1. Save DCC-entered details against the request.
      await DccDocumentRequestService
          .updateDccDetails(
        requestId: widget.request.id,
        documentNo: documentNo,
        documentName: documentName,
        documentType: documentType,
        department: department,
        candidateName: candidateName,
        candidateEmail: candidateEmail,
      );

      // 2. Add the document to Master Data.
      await DccMasterDataService.upsertEntry(
        DccMasterData(
          documentNo: documentNo,
          documentName: documentName,
          documentType: documentType,
          department: department,
          candidateName: candidateName,
          candidateEmail: candidateEmail,
          createdByName:
          currentUser?.name ?? '',
          createdByEmail:
          currentUser?.email ?? '',
        ),
      );

      // 3. Create the user's in-app upload notification.
      await DccNotificationService
          .createDocumentUploadNotification(
        userEmail: candidateEmail,
        documentRequestId:
        widget.request.id,
        documentName: documentName,
      );

      // 4. Only mark the request as NOTIFIED
      // after Master Data and notification succeed.
      await DccDocumentRequestService
          .markAsNotified(
        widget.request.id,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Document details saved and user notified.',
          ),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      _showError(
        'Failed to save request: $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  InputDecoration _decoration(
      String label,
      ) {
    return InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
    );
  }

  Widget _field(
      TextEditingController controller,
      String label, {
        bool readOnly = false,
      }) {
    return Padding(
      padding:
      const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        readOnly: readOnly,
        decoration:
        _decoration(label),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Review Document Request',
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            const Text(
              'User Request',
              style: TextStyle(
                fontSize: 20,
                fontWeight:
                FontWeight.bold,
              ),
            ),

            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding:
                const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Description',
                      style:
                      const TextStyle(
                        fontWeight:
                        FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      widget.request.description,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            const Text(
              'Master Data Details',
              style: TextStyle(
                fontSize: 20,
                fontWeight:
                FontWeight.bold,
              ),
            ),

            const SizedBox(height: 16),

            _field(
              _documentNoController,
              'Document No',
            ),

            _field(
              _documentNameController,
              'Document Name',
            ),

            _field(
              _documentTypeController,
              'Document Type',
            ),

            _field(
              _departmentController,
              'Department',
            ),

            _field(
              _candidateNameController,
              'Candidate Name',
            ),

            _field(
              _candidateEmailController,
              'Candidate Email',
            ),

            const SizedBox(height: 8),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed:
                _saving
                    ? null
                    : _saveAndNotify,
                icon: const Icon(
                  Icons.notifications_active,
                ),
                label: Text(
                  _saving
                      ? 'Saving...'
                      : 'Save & Notify User',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}