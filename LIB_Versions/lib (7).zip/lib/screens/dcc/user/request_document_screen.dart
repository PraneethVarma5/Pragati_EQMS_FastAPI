import 'package:flutter/material.dart';

import '../../../services/dcc/dcc_document_request_service.dart';

class RequestDocumentScreen extends StatefulWidget {
  const RequestDocumentScreen({super.key});

  @override
  State<RequestDocumentScreen> createState() =>
      _RequestDocumentScreenState();
}

class _RequestDocumentScreenState
    extends State<RequestDocumentScreen> {
  final _formKey = GlobalKey<FormState>();

  final _documentNameController =
  TextEditingController();

  final _userNameController =
  TextEditingController();

  final _userEmailController =
  TextEditingController();

  final _descriptionController =
  TextEditingController();

  bool _saving = false;

  @override
  void dispose() {
    _documentNameController.dispose();
    _userNameController.dispose();
    _userEmailController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _submitRequest() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _saving = true;
    });

    try {
      await DccDocumentRequestService.createRequest(
        documentName:
        _documentNameController.text,
        userName:
        _userNameController.text,
        userEmail:
        _userEmailController.text,
        description:
        _descriptionController.text,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Document request sent to DCC.',
          ),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Failed to submit request: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  InputDecoration _decoration(String label) {
    return InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Request New Document',
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller:
                _documentNameController,
                decoration:
                _decoration('Document Name'),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Enter document name';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller:
                _userNameController,
                decoration:
                _decoration('Your Name'),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Enter your name';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller:
                _userEmailController,
                keyboardType:
                TextInputType.emailAddress,
                decoration:
                _decoration('Your Email'),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Enter email';
                  }

                  final emailRegex = RegExp(
                    r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                  );

                  if (!emailRegex
                      .hasMatch(value.trim())) {
                    return 'Enter a valid email';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller:
                _descriptionController,
                maxLines: 5,
                decoration:
                _decoration('Description'),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Enter description';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed:
                  _saving ? null : _submitRequest,
                  child: _saving
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child:
                    CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                      : const Text(
                    'Send Request to DCC',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}