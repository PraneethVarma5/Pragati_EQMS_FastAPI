import 'package:flutter/material.dart';

import '../../../models/dcc/dcc_master_data.dart';
import '../../../services/dcc/dcc_master_data_service.dart';
import '../../../services/dcc/dcc_session.dart';

const List<String> kDccDocumentTypes = ['SOP', 'Manual', 'Procedure'];

class DccMasterDataScreen extends StatefulWidget {
  const DccMasterDataScreen({super.key});

  @override
  State<DccMasterDataScreen> createState() => _DccMasterDataScreenState();
}

class _DccMasterDataScreenState extends State<DccMasterDataScreen> {
  List<DccMasterData> _entries = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);

    try {
      final entries = await DccMasterDataService.getAllEntries();
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unable to load master data: $e')),
      );
    }
  }

  List<DccMasterData> get _filtered {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) return _entries;

    return _entries.where((e) {
      return e.documentNo.toLowerCase().contains(query) ||
          e.documentName.toLowerCase().contains(query);
    }).toList();
  }

  void _showEntryDialog({DccMasterData? existing}) {
    final formKey = GlobalKey<FormState>();
    final docNoController =
    TextEditingController(text: existing?.documentNo ?? '');
    final docNameController =
    TextEditingController(text: existing?.documentName ?? '');
    final departmentController =
    TextEditingController(text: existing?.department ?? '');
    final candidateNameController =
    TextEditingController(text: existing?.candidateName ?? '');
    final candidateEmailController =
    TextEditingController(text: existing?.candidateEmail ?? '');
    String docType = existing?.documentType.isNotEmpty == true
        ? existing!.documentType
        : kDccDocumentTypes.first;
    bool submitting = false;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            Future<void> submit() async {
              if (!formKey.currentState!.validate()) return;

              setDialogState(() => submitting = true);

              try {
                final currentUser = DccSession.currentUser;

                await DccMasterDataService.upsertEntry(
                  DccMasterData(
                    documentNo: docNoController.text.trim(),
                    documentName: docNameController.text.trim(),
                    documentType: docType,
                    department: departmentController.text.trim(),
                    candidateName: candidateNameController.text.trim(),
                    candidateEmail:
                    candidateEmailController.text.trim().toLowerCase(),
                    createdByName: currentUser?.name ?? '',
                    createdByEmail: currentUser?.email ?? '',
                  ),
                );

                if (!dialogContext.mounted) return;
                Navigator.pop(dialogContext);

                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Master data saved.')),
                  );
                  _load();
                }
              } catch (e) {
                if (!dialogContext.mounted) return;
                setDialogState(() => submitting = false);
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  SnackBar(content: Text('Could not save: $e')),
                );
              }
            }

            return AlertDialog(
              title: Text(
                existing == null ? 'Add Master Data' : 'Edit Master Data',
              ),
              content: SizedBox(
                width: 420,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextFormField(
                          controller: docNoController,
                          enabled: existing == null,
                          decoration: const InputDecoration(
                            labelText: 'Document No',
                          ),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Required'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: docNameController,
                          decoration: const InputDecoration(
                            labelText: 'Document Name',
                          ),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Required'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        DropdownButtonFormField<String>(
                          initialValue: docType,
                          decoration: const InputDecoration(
                            labelText: 'Document Type',
                          ),
                          items: kDccDocumentTypes
                              .map(
                                (t) => DropdownMenuItem(
                              value: t,
                              child: Text(t),
                            ),
                          )
                              .toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setDialogState(() => docType = value);
                            }
                          },
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: departmentController,
                          decoration: const InputDecoration(
                            labelText: 'Department',
                          ),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Required'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: candidateNameController,
                          decoration: const InputDecoration(
                            labelText: 'Candidate Name (assignee)',
                          ),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Required'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: candidateEmailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Candidate Email',
                          ),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Required'
                              : null,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: submitting
                      ? null
                      : () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: submitting ? null : submit,
                  child: submitting
                      ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                      : const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _confirmDelete(DccMasterData entry) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Master Data'),
        content: Text(
          'Remove master data for "${entry.documentNo}"? '
              'Users will no longer get auto-filled details for this document number.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await DccMasterDataService.deleteEntry(entry.documentNo);
      if (mounted) _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not delete: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text('Master Data'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF172033),
        elevation: 0,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showEntryDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Add Master Data'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Enter a document\'s details here before the New Document '
                  'process starts. When a User types this Document No while '
                  'creating a document, the rest of the fields will auto-fill.',
              style: TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search by document no or name...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _filtered.isEmpty
                  ? const Center(
                child: Text(
                  'No master data entries yet.',
                  style: TextStyle(color: Color(0xFF6B7280)),
                ),
              )
                  : ListView.separated(
                itemCount: _filtered.length,
                separatorBuilder: (_, _) =>
                const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final entry = _filtered[index];

                  return Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: const BorderSide(
                        color: Color(0xFFE4E8F0),
                      ),
                    ),
                    child: ListTile(
                      title: Text(
                        '${entry.documentNo} — ${entry.documentName}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      subtitle: Text(
                        '${entry.documentType} • ${entry.department} • '
                            'Assigned to ${entry.candidateName}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () =>
                                _showEntryDialog(existing: entry),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => _confirmDelete(entry),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
