import 'package:supabase_flutter/supabase_flutter.dart';

/// Handles the ARR module's shared login password — a separate
/// password from the admin one, gating the whole ARR area the way
/// the admin password gates /ARR/admin. Same hashed-in-Postgres
/// design as AdminAuthService: no plaintext comparison client-side,
/// no Supabase Auth, no hardcoded password.
class ArrAuthService {
  ArrAuthService._();

  static SupabaseClient get _client => Supabase.instance.client;

  static Future<bool> verifyPassword(String password) async {
    final result = await _client.rpc(
      'verify_arr_password',
      params: {'p_password': password},
    );

    return result == true;
  }

  static Future<bool> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final result = await _client.rpc(
      'set_arr_password',
      params: {
        'p_current_password': currentPassword,
        'p_new_password': newPassword,
      },
    );

    return result == true;
  }

  /// Only call this after identity has already been confirmed via
  /// the emailed-OTP "Forgot Password" flow.
  static Future<void> resetPasswordAfterOtp(String newPassword) async {
    await _client.rpc(
      'arr_reset_password_after_otp',
      params: {'p_new_password': newPassword},
    );
  }
}
