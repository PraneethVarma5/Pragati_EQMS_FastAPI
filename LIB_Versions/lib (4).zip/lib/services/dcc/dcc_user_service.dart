import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/dcc/dcc_user.dart';

class DccUserService {
  static const String tableName = 'dcc_users';

  static SupabaseClient get _client {
    return Supabase.instance.client;
  }

  static DccUser _fromRow(Map<String, dynamic> row) {
    return DccUser(
      id: row['id']?.toString() ?? '',
      name: row['name']?.toString() ?? '',
      email: row['email']?.toString() ?? '',
      role: row['role']?.toString() ?? '',
      hodName: row['hod_name']?.toString() ?? '',
      hodEmail: row['hod_email']?.toString() ?? '',
      password: row['password']?.toString() ?? '',
      active: row['active'] == true,
    );
  }

  static Map<String, dynamic> _toRow(DccUser user) {
    return {
      'id': user.id,
      'name': user.name,
      'email': user.email.trim().toLowerCase(),
      'role': user.role.trim().toUpperCase(),
      'hod_name': user.hodName,
      'hod_email': user.hodEmail.trim().toLowerCase(),
      'password': user.password,
      'active': user.active,
    };
  }

  static Future<void> addUser(DccUser user) async {
    // Password is hashed inside Postgres (pgcrypto) by the
    // dcc_upsert_user RPC — it is never stored in plaintext.
    await _client.rpc(
      'dcc_upsert_user',
      params: {
        'p_id': user.id,
        'p_name': user.name,
        'p_email': user.email,
        'p_role': user.role,
        'p_hod_name': user.hodName,
        'p_hod_email': user.hodEmail,
        'p_password': user.password,
        'p_active': user.active,
      },
    );
  }

  /// Verifies a DCC login. The password comparison happens
  /// entirely inside Postgres against the hashed password column;
  /// the hash itself is never sent to the client. Returns the
  /// matching user if the email/password are correct and the
  /// account is active, otherwise null.
  static Future<DccUser?> verifyLogin({
    required String email,
    required String password,
  }) async {
    final response = await _client.rpc(
      'verify_dcc_login',
      params: {
        'p_email': email,
        'p_password': password,
      },
    );

    final rows = List<Map<String, dynamic>>.from(response ?? []);

    if (rows.isEmpty) {
      return null;
    }

    final row = rows.first;

    return DccUser(
      id: row['id']?.toString() ?? '',
      name: row['name']?.toString() ?? '',
      email: row['email']?.toString() ?? '',
      role: row['role']?.toString() ?? '',
      hodName: row['hod_name']?.toString() ?? '',
      hodEmail: row['hod_email']?.toString() ?? '',
      password: '',
      active: row['active'] == true,
    );
  }

  /// Lets a DCC user change their own password (e.g. from the
  /// default "welcome123" set when an admin creates their
  /// account). Requires the current password to be correct;
  /// returns false without changing anything if it isn't. The
  /// comparison and hashing both happen inside Postgres.
  static Future<bool> changePassword({
    required String email,
    required String currentPassword,
    required String newPassword,
  }) async {
    final result = await _client.rpc(
      'dcc_change_password',
      params: {
        'p_email': email,
        'p_current_password': currentPassword,
        'p_new_password': newPassword,
      },
    );

    return result == true;
  }

  static Future<List<DccUser>> getUsers() async {
    final response = await _client
        .from(tableName)
        .select()
        .order('created_at', ascending: true);

    return (response as List)
        .map(
          (row) => _fromRow(
        Map<String, dynamic>.from(row),
      ),
    )
        .toList();
  }

  static Future<DccUser?> findByEmail(String email) async {
    final normalizedEmail =
    email.trim().toLowerCase();

    final response = await _client
        .from(tableName)
        .select()
        .eq('email', normalizedEmail)
        .eq('active', true)
        .maybeSingle();

    if (response == null) {
      return null;
    }

    return _fromRow(
      Map<String, dynamic>.from(response),
    );
  }

  static Future<bool> emailExists(String email) async {
    final user = await findByEmail(email);

    return user != null;
  }

  static Future<void> deleteUser(String id) async {
    await _client
        .from(tableName)
        .delete()
        .eq('id', id);
  }

  static Future<void> setUserActive(
      String id,
      bool active,
      ) async {
    await _client
        .from(tableName)
        .update({
      'active': active,
      'updated_at': DateTime.now().toIso8601String(),
    })
        .eq('id', id);
  }
}