/// Tracks whether the admin area has been unlocked with the
/// correct password for the current app session (in memory only —
/// a page reload requires the password to be entered again, which
/// is the intended behaviour for a route-level lock).
class AdminSession {
  AdminSession._();

  static bool _unlocked = false;

  static bool get isUnlocked => _unlocked;

  static void unlock() {
    _unlocked = true;
  }

  static void lock() {
    _unlocked = false;
  }
}
