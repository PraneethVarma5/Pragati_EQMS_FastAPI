/// Tracks whether the ARR module has been unlocked with the
/// correct password for the current browser session — mirrors
/// AdminSession. In-memory only, so a page reload requires the
/// password again.
class ArrSession {
  ArrSession._();

  static bool _unlocked = false;

  static bool get isUnlocked => _unlocked;

  static void unlock() {
    _unlocked = true;
  }

  static void lock() {
    _unlocked = false;
  }
}
