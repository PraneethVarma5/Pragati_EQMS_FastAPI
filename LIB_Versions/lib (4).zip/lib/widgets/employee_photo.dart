import 'package:flutter/material.dart';

import '../services/supabase_service.dart';

/// Renders an employee's photo by downloading it through the
/// authenticated Supabase client instead of Image.network. This
/// avoids two web-specific failure modes:
///   - the storage bucket being private (a public-style URL would
///     403/404 for an anonymous request)
///   - browser CORS blocking the image decode even when the file
///     itself is reachable
///
/// [photoPathOrUrl] can be a raw storage path or a full public URL
/// (see SupabaseService.downloadEmployeePhotoBytes). If it's empty,
/// the placeholder is shown immediately with no network call.
class EmployeePhoto extends StatelessWidget {
  final String photoPathOrUrl;
  final double size;
  final double iconSize;

  const EmployeePhoto({
    super.key,
    required this.photoPathOrUrl,
    this.size = 96,
    this.iconSize = 52,
  });

  @override
  Widget build(BuildContext context) {
    if (photoPathOrUrl.isEmpty) {
      return _placeholder();
    }

    return FutureBuilder(
      future:
      SupabaseService.downloadEmployeePhotoBytes(photoPathOrUrl),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          );
        }

        if (!snapshot.hasData || snapshot.hasError) {
          return _placeholder();
        }

        return Image.memory(
          snapshot.data!,
          fit: BoxFit.cover,
          width: size,
          height: size,
          errorBuilder: (context, error, stackTrace) => _placeholder(),
        );
      },
    );
  }

  Widget _placeholder() {
    return Icon(
      Icons.person_outline_rounded,
      size: iconSize,
      color: const Color(0xFF9AA1AA),
    );
  }
}
