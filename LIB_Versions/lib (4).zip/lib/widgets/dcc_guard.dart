import 'package:flutter/material.dart';

import '../services/dcc/dcc_session.dart';
import '../screens/dcc/dcc_login_screen.dart';

/// Wraps a DCC screen so it can only be reached by a logged-in DCC
/// user — and, when [requiredRole] is given, only by a user with
/// that exact role. If there's no active session (or the wrong
/// role), the DCC login screen is shown in place of the requested
/// screen instead of the screen itself. This closes the gap where
/// navigating straight to a dashboard URL (typing it, bookmarking
/// it, refreshing on it) used to skip login entirely.
///
/// DccSession is in-memory only, so a page reload always requires
/// logging in again — this mirrors AdminGuard's "ask every time"
/// behaviour for the ARR admin area.
///
/// After a successful login, DccLoginScreen's own role-based
/// redirect (Navigator.pushReplacementNamed to that role's
/// dashboard) takes over, so this guard doesn't need to remember
/// or restore the originally-requested URL.
class DccGuard extends StatelessWidget {
  final Widget child;
  final String? requiredRole;

  const DccGuard({
    super.key,
    required this.child,
    this.requiredRole,
  });

  @override
  Widget build(BuildContext context) {
    final user = DccSession.currentUser;

    final allowed = user != null &&
        (requiredRole == null || user.role == requiredRole);

    if (allowed) {
      return child;
    }

    return const DccLoginScreen();
  }
}
