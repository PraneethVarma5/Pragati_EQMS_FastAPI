-- ============================================================
-- Digital ARR / eQMS — Password hashing migration
-- ============================================================
-- Run this once in the Supabase SQL editor.
--
-- What this does:
--   1. Enables pgcrypto (needed for bcrypt-style hashing).
--   2. Adds a password_hash column to admin_profiles and seeds
--      one row with a hashed DEFAULT password so the app keeps
--      working immediately. CHANGE THIS PASSWORD after running
--      this script (use the in-app "Change Password" screen).
--   3. Adds RPC functions the Flutter app calls to verify/change
--      the admin password. The app never sees the hash, and the
--      comparison always happens inside Postgres.
--   4. Hashes any existing plaintext passwords in dcc_users, and
--      adds RPC functions for logging in / creating DCC users
--      without ever sending a plaintext password comparison
--      through the client.
--
-- Safe to re-run: steps that add columns/rows use IF NOT EXISTS
-- / ON CONFLICT guards, and the password migration only hashes
-- values that don't already look like a bcrypt hash.
-- ============================================================

-- 1. Extension needed for crypt()/gen_salt()
create extension if not exists pgcrypto;


-- ============================================================
-- ADMIN PASSWORD
-- ============================================================

alter table admin_profiles
  add column if not exists password_hash text;

-- Seed a single admin_profiles row if none exists yet, with a
-- temporary default password of "admin123" (hashed). Change it
-- immediately after this migration via the app's Change Password
-- screen.
insert into admin_profiles (user_id, full_name, role, password_hash)
select gen_random_uuid(), 'Administrator', 'admin', crypt('admin123', gen_salt('bf'))
where not exists (select 1 from admin_profiles where role = 'admin');

-- If a role='admin' row already exists but has no password yet,
-- give it the same temporary default so the app isn't locked out.
update admin_profiles
set password_hash = crypt('admin123', gen_salt('bf'))
where role = 'admin' and password_hash is null;

-- Verify a supplied password against the stored admin hash.
-- Returns true/false only — never exposes the hash to the caller.
create or replace function verify_admin_password(p_password text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from admin_profiles
    where role = 'admin'
      and password_hash is not null
      and password_hash = crypt(p_password, password_hash)
  );
$$;

-- Change the admin password. Requires the correct current
-- password. Returns true if changed, false if current password
-- was wrong.
create or replace function set_admin_password(
  p_current_password text,
  p_new_password text
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not verify_admin_password(p_current_password) then
    return false;
  end if;

  update admin_profiles
  set password_hash = crypt(p_new_password, gen_salt('bf'))
  where role = 'admin';

  return true;
end;
$$;

-- Used only by the "Forgot Password" (OTP-verified) flow, where
-- the app has already confirmed the user's identity via emailed
-- OTP before calling this. No current password is required.
create or replace function admin_reset_password_after_otp(p_new_password text)
returns void
language sql
security definer
set search_path = public
as $$
  update admin_profiles
  set password_hash = crypt(p_new_password, gen_salt('bf'))
  where role = 'admin';
$$;

-- Restrict execution to the anon/authenticated roles used by the app.
grant execute on function verify_admin_password(text) to anon, authenticated;
grant execute on function set_admin_password(text, text) to anon, authenticated;
grant execute on function admin_reset_password_after_otp(text) to anon, authenticated;


-- ============================================================
-- DCC USERS
-- ============================================================

-- Hash any existing plaintext passwords (bcrypt hashes always
-- start with $2, so this only touches rows that aren't already
-- hashed — safe to re-run).
update dcc_users
set password = crypt(password, gen_salt('bf'))
where password is not null
  and password not like '$2%';

-- Verify DCC login. Returns the matching user row only if the
-- password is correct and the account is active; returns no rows
-- otherwise. The password/hash column is never returned.
create or replace function verify_dcc_login(p_email text, p_password text)
returns table (
  id text,
  name text,
  email text,
  role text,
  hod_name text,
  hod_email text,
  active boolean
)
language sql
security definer
set search_path = public
as $$
  select u.id, u.name, u.email, u.role, u.hod_name, u.hod_email, u.active
  from dcc_users u
  where u.email = lower(trim(p_email))
    and u.active = true
    and u.password = crypt(p_password, u.password);
$$;

-- Create or update a DCC user with the password hashed server
-- side. Pass the plaintext password in p_password; it is hashed
-- before being stored.
create or replace function dcc_upsert_user(
  p_id text,
  p_name text,
  p_email text,
  p_role text,
  p_hod_name text,
  p_hod_email text,
  p_password text,
  p_active boolean
)
returns void
language sql
security definer
set search_path = public
as $$
  insert into dcc_users (id, name, email, role, hod_name, hod_email, password, active, updated_at)
  values (
    p_id,
    p_name,
    lower(trim(p_email)),
    upper(trim(p_role)),
    p_hod_name,
    lower(trim(p_hod_email)),
    crypt(p_password, gen_salt('bf')),
    p_active,
    now()
  )
  on conflict (id) do update set
    name = excluded.name,
    email = excluded.email,
    role = excluded.role,
    hod_name = excluded.hod_name,
    hod_email = excluded.hod_email,
    password = excluded.password,
    active = excluded.active,
    updated_at = now();
$$;

grant execute on function verify_dcc_login(text, text) to anon, authenticated;
grant execute on function dcc_upsert_user(text, text, text, text, text, text, text, boolean) to anon, authenticated;
